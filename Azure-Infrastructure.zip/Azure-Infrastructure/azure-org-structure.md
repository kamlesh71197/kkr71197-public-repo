# Azure Organization Structure - Complete Setup Guide

## Table of Contents
1. [Organization Hierarchy Diagram](#1-organization-hierarchy-diagram)
2. [Prerequisites](#2-prerequisites)
3. [Azure CLI Implementation](#3-azure-cli-implementation-easiest)
4. [PowerShell Implementation](#4-powershell-implementation)
5. [Terraform Implementation](#5-terraform-iac)
6. [Bicep Implementation](#6-bicep-iac)
7. [Verification & Cleanup](#7-verification--cleanup)

---

## 1. Organization Hierarchy Diagram

```
Azure Tenant (Azure AD / Entra ID)
│
├── Management Groups (optional - for enterprise governance)
│   └── Root Management Group
│       └── Custom Management Group
│
├── Service Principal (App Registration)
│   ├── App ID (Client ID)
│   ├── Client Secret / Certificate
│   └── Role Assignments (Contributor/Owner on Subscription)
│
└── Subscription
    ├── Subscription ID
    ├── Billing Info
    │
    └── Resource Group
        ├── Location (e.g., eastus)
        ├── Tags
        │
        └── Azure Data Factory (ADF)
            ├── ADF Instance
            ├── Managed Identity (System-assigned)
            ├── Pipelines
            ├── Datasets
            ├── Linked Services
            └── Triggers
```

### Detailed Flow Diagram

```
┌──────────────────────────────────────────────────────┐
│                  AZURE TENANT                         │
│              (Entra ID / Azure AD)                    │
│                                                       │
│  ┌─────────────────────────────────────────────────┐  │
│  │           SERVICE PRINCIPAL                      │  │
│  │  ┌──────────────┐  ┌─────────────────────────┐  │  │
│  │  │  App ID       │  │  Client Secret          │  │  │
│  │  │  (Client ID)  │  │  (or Certificate)       │  │  │
│  │  └──────────────┘  └─────────────────────────┘  │  │
│  │  ┌──────────────────────────────────────────┐   │  │
│  │  │  Role: Contributor on Subscription       │   │  │
│  │  └──────────────────────────────────────────┘   │  │
│  └─────────────────────────────────────────────────┘  │
│                          │                            │
│                          ▼                            │
│  ┌─────────────────────────────────────────────────┐  │
│  │              SUBSCRIPTION                        │  │
│  │         (Pay-As-You-Go / Enterprise)             │  │
│  │                                                   │  │
│  │  ┌───────────────────────────────────────────┐   │  │
│  │  │          RESOURCE GROUP                    │   │  │
│  │  │       (rg-dataplatform-dev)                │   │  │
│  │  │                                            │   │  │
│  │  │  ┌──────────────────────────────────────┐  │   │  │
│  │  │  │    AZURE DATA FACTORY                 │  │   │  │
│  │  │  │    (adf-myproject-dev)                │  │   │  │
│  │  │  │                                       │  │   │  │
│  │  │  │  • Managed Identity (System)          │  │   │  │
│  │  │  │  • Pipelines                          │  │   │  │
│  │  │  │  • Linked Services                    │  │   │  │
│  │  │  │  • Datasets                           │  │   │  │
│  │  │  │  • Triggers                           │  │   │  │
│  │  │  └──────────────────────────────────────┘  │   │  │
│  │  └───────────────────────────────────────────┘   │  │
│  └─────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────┘
```

---

## 2. Prerequisites

```bash
# Install Azure CLI
# Windows: Download from https://aka.ms/installazurecliwindows
# Or via winget:
winget install Microsoft.AzureCLI

# Install Terraform (if using IaC)
winget install HashiCorp.Terraform

# Install Azure PowerShell Module
Install-Module -Name Az -Repository PSGallery -Force

# Login to Azure
az login
```

---

## 3. Azure CLI Implementation (Easiest)

> **Recommended to start here** - simplest approach to get everything running.

### Step 1: Login & Set Variables

```bash
# Login to Azure
az login

# Set variables (modify these for your project)
SUBSCRIPTION_NAME="MyProject-Subscription"
RESOURCE_GROUP="rg-dataplatform-dev"
LOCATION="eastus"
ADF_NAME="adf-myproject-dev"
SP_NAME="sp-dataplatform-admin"
```

### Step 2: Get/Create Subscription

```bash
# List existing subscriptions
az account list --output table

# Set active subscription (use existing one)
az account set --subscription "<your-subscription-id>"

# Verify active subscription
az account show --output table
```

> **Note:** Subscriptions cannot be created via CLI for Pay-As-You-Go. 
> Create via Azure Portal → Subscriptions → Add. 
> For Enterprise Agreement, use: `az billing enrollment-account list`

### Step 3: Create Service Principal

```bash
# Create Service Principal with Contributor role on the subscription
az ad sp create-for-rbac \
  --name "$SP_NAME" \
  --role "Contributor" \
  --scopes "/subscriptions/$(az account show --query id -o tsv)" \
  --output json

# ⚠️ SAVE THE OUTPUT! You'll get:
# {
#   "appId": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",      ← Client ID
#   "displayName": "sp-dataplatform-admin",
#   "password": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",    ← Client Secret
#   "tenant": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"       ← Tenant ID
# }
```

### Step 4: Login as Service Principal

```bash
# Login using Service Principal credentials
az login --service-principal \
  --username "<appId>" \
  --password "<password>" \
  --tenant "<tenant>"
```

### Step 5: Create Resource Group

```bash
# Create Resource Group
az group create \
  --name "$RESOURCE_GROUP" \
  --location "$LOCATION" \
  --tags Environment=Dev Project=DataPlatform

# Verify
az group show --name "$RESOURCE_GROUP" --output table
```

### Step 6: Create Azure Data Factory

```bash
# Create ADF instance
az datafactory create \
  --resource-group "$RESOURCE_GROUP" \
  --factory-name "$ADF_NAME" \
  --location "$LOCATION"

# Verify ADF creation
az datafactory show \
  --resource-group "$RESOURCE_GROUP" \
  --factory-name "$ADF_NAME" \
  --output table
```

### Step 7: Grant ADF Managed Identity Access (Optional)

```bash
# Get ADF's managed identity principal ID
ADF_PRINCIPAL_ID=$(az datafactory show \
  --resource-group "$RESOURCE_GROUP" \
  --factory-name "$ADF_NAME" \
  --query identity.principalId -o tsv)

# Assign Storage Blob Data Contributor role (example)
az role assignment create \
  --assignee "$ADF_PRINCIPAL_ID" \
  --role "Storage Blob Data Contributor" \
  --scope "/subscriptions/$(az account show --query id -o tsv)"
```

---

## 4. PowerShell Implementation

### Full PowerShell Script

```powershell
# ============================================
# Azure Organization Setup - PowerShell
# ============================================

# --- Variables ---
$SubscriptionId    = "<your-subscription-id>"
$ResourceGroupName = "rg-dataplatform-dev"
$Location          = "eastus"
$AdfName           = "adf-myproject-dev"
$SpName            = "sp-dataplatform-admin"
$Tags              = @{ Environment = "Dev"; Project = "DataPlatform" }

# --- Step 1: Login ---
Connect-AzAccount

# --- Step 2: Set Subscription ---
Set-AzContext -SubscriptionId $SubscriptionId
Write-Host "Active Subscription: $(Get-AzContext | Select-Object -ExpandProperty Subscription)" -ForegroundColor Green

# --- Step 3: Create Service Principal ---
$sp = New-AzADServicePrincipal `
    -DisplayName $SpName `
    -Role "Contributor" `
    -Scope "/subscriptions/$SubscriptionId"

# Display credentials (SAVE THESE!)
Write-Host "========== SERVICE PRINCIPAL CREDENTIALS ==========" -ForegroundColor Yellow
Write-Host "App ID (Client ID) : $($sp.AppId)"
Write-Host "Display Name       : $($sp.DisplayName)"
Write-Host "Tenant ID          : $(Get-AzContext | Select-Object -ExpandProperty Tenant | Select-Object -ExpandProperty Id)"
Write-Host "===================================================" -ForegroundColor Yellow

# Note: For secret, create it explicitly
$spCredential = New-AzADSpCredential -ObjectId $sp.Id -EndDate (Get-Date).AddYears(1)
Write-Host "Client Secret      : $($spCredential.SecretText)" -ForegroundColor Red
Write-Host "Secret Expires     : $($spCredential.EndDateTime)"

# --- Step 4: Create Resource Group ---
New-AzResourceGroup `
    -Name $ResourceGroupName `
    -Location $Location `
    -Tag $Tags

Write-Host "Resource Group '$ResourceGroupName' created in '$Location'" -ForegroundColor Green

# --- Step 5: Create Azure Data Factory ---
# Install ADF module if not present
# Install-Module -Name Az.DataFactory -Force

$adf = Set-AzDataFactoryV2 `
    -ResourceGroupName $ResourceGroupName `
    -Name $AdfName `
    -Location $Location

Write-Host "Azure Data Factory '$AdfName' created successfully!" -ForegroundColor Green
Write-Host "ADF Resource ID: $($adf.DataFactoryId)"

# --- Step 6: Verify All Resources ---
Write-Host "`n========== VERIFICATION ==========" -ForegroundColor Cyan
Write-Host "Subscription:" -ForegroundColor White
Get-AzContext | Format-Table Name, Subscription, Tenant

Write-Host "Service Principal:" -ForegroundColor White
Get-AzADServicePrincipal -DisplayName $SpName | Format-Table DisplayName, AppId, Id

Write-Host "Resource Group:" -ForegroundColor White
Get-AzResourceGroup -Name $ResourceGroupName | Format-Table ResourceGroupName, Location, ProvisioningState

Write-Host "Data Factory:" -ForegroundColor White
Get-AzDataFactoryV2 -ResourceGroupName $ResourceGroupName -Name $AdfName | Format-Table DataFactoryName, Location, ProvisioningState
```

---

## 5. Terraform (IaC)

### File Structure

```
terraform/
├── main.tf           # Main configuration
├── variables.tf      # Variable definitions
├── outputs.tf        # Output values
├── providers.tf      # Provider configuration
└── terraform.tfvars  # Variable values (DO NOT commit to git)
```

### providers.tf

```hcl
terraform {
  required_version = ">= 1.5.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.80"
    }
    azuread = {
      source  = "hashicorp/azuread"
      version = "~> 2.45"
    }
  }
}

provider "azurerm" {
  features {}
  subscription_id = var.subscription_id
}

provider "azuread" {}
```

### variables.tf

```hcl
variable "subscription_id" {
  description = "Azure Subscription ID"
  type        = string
}

variable "resource_group_name" {
  description = "Name of the Resource Group"
  type        = string
  default     = "rg-dataplatform-dev"
}

variable "location" {
  description = "Azure Region"
  type        = string
  default     = "eastus"
}

variable "adf_name" {
  description = "Azure Data Factory name"
  type        = string
  default     = "adf-myproject-dev"
}

variable "sp_name" {
  description = "Service Principal display name"
  type        = string
  default     = "sp-dataplatform-admin"
}

variable "tags" {
  description = "Tags for all resources"
  type        = map(string)
  default = {
    Environment = "Dev"
    Project     = "DataPlatform"
    ManagedBy   = "Terraform"
  }
}
```

### main.tf

```hcl
# =============================================
# Data Sources
# =============================================

data "azurerm_subscription" "current" {}

data "azuread_client_config" "current" {}

# =============================================
# Service Principal
# =============================================

resource "azuread_application" "sp_app" {
  display_name = var.sp_name
  owners       = [data.azuread_client_config.current.object_id]
}

resource "azuread_service_principal" "sp" {
  client_id = azuread_application.sp_app.client_id
  owners    = [data.azuread_client_config.current.object_id]
}

resource "azuread_service_principal_password" "sp_secret" {
  service_principal_id = azuread_service_principal.sp.id
  end_date_relative    = "8760h" # 1 year
}

# Assign Contributor role to SP on Subscription
resource "azurerm_role_assignment" "sp_contributor" {
  scope                = data.azurerm_subscription.current.id
  role_definition_name = "Contributor"
  principal_id         = azuread_service_principal.sp.object_id
}

# =============================================
# Resource Group
# =============================================

resource "azurerm_resource_group" "rg" {
  name     = var.resource_group_name
  location = var.location
  tags     = var.tags
}

# =============================================
# Azure Data Factory
# =============================================

resource "azurerm_data_factory" "adf" {
  name                = var.adf_name
  location            = azurerm_resource_group.rg.location
  resource_group_name = azurerm_resource_group.rg.name
  tags                = var.tags

  identity {
    type = "SystemAssigned"
  }
}
```

### outputs.tf

```hcl
output "subscription_id" {
  value = data.azurerm_subscription.current.subscription_id
}

output "service_principal_app_id" {
  value = azuread_application.sp_app.client_id
}

output "service_principal_secret" {
  value     = azuread_service_principal_password.sp_secret.value
  sensitive = true
}

output "tenant_id" {
  value = data.azuread_client_config.current.tenant_id
}

output "resource_group_name" {
  value = azurerm_resource_group.rg.name
}

output "resource_group_id" {
  value = azurerm_resource_group.rg.id
}

output "data_factory_name" {
  value = azurerm_data_factory.adf.name
}

output "data_factory_id" {
  value = azurerm_data_factory.adf.id
}

output "data_factory_identity_principal_id" {
  value = azurerm_data_factory.adf.identity[0].principal_id
}
```

### terraform.tfvars

```hcl
# ⚠️ DO NOT commit this file to version control!
subscription_id     = "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
resource_group_name = "rg-dataplatform-dev"
location            = "eastus"
adf_name            = "adf-myproject-dev"
sp_name             = "sp-dataplatform-admin"
```

### Terraform Commands

```bash
cd terraform/

# Initialize
terraform init

# Preview changes
terraform plan

# Apply
terraform apply

# Show outputs
terraform output

# Show SP secret (sensitive)
terraform output -raw service_principal_secret

# Destroy everything
terraform destroy
```

---

## 6. Bicep (IaC)

### File Structure

```
bicep/
├── main.bicep          # Main deployment
└── parameters.json     # Parameter values
```

### main.bicep

```bicep
// =============================================
// Parameters
// =============================================

@description('Azure region for all resources')
param location string = resourceGroup().location

@description('Azure Data Factory name')
param adfName string = 'adf-myproject-dev'

@description('Environment tag')
@allowed(['Dev', 'Staging', 'Prod'])
param environment string = 'Dev'

@description('Project name tag')
param project string = 'DataPlatform'

// =============================================
// Variables
// =============================================

var tags = {
  Environment: environment
  Project: project
  ManagedBy: 'Bicep'
}

// =============================================
// Azure Data Factory
// =============================================

resource dataFactory 'Microsoft.DataFactory/factories@2018-06-01' = {
  name: adfName
  location: location
  tags: tags
  identity: {
    type: 'SystemAssigned'
  }
  properties: {}
}

// =============================================
// Outputs
// =============================================

output dataFactoryName string = dataFactory.name
output dataFactoryId string = dataFactory.id
output dataFactoryPrincipalId string = dataFactory.identity.principalId
```

### parameters.json

```json
{
  "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentParameters.json#",
  "contentVersion": "1.0.0.0",
  "parameters": {
    "adfName": { "value": "adf-myproject-dev" },
    "environment": { "value": "Dev" },
    "project": { "value": "DataPlatform" }
  }
}
```

### Bicep Deployment Commands

```bash
# Step 1: Create Resource Group first (Bicep deploys INTO a resource group)
az group create --name "rg-dataplatform-dev" --location "eastus"

# Step 2: Deploy Bicep template
az deployment group create \
  --resource-group "rg-dataplatform-dev" \
  --template-file main.bicep \
  --parameters @parameters.json

# Step 3: Verify deployment
az deployment group show \
  --resource-group "rg-dataplatform-dev" \
  --name main \
  --output table
```

> **Note:** Service Principal creation is NOT supported in Bicep (it's an ARM/Entra ID operation). 
> Use Azure CLI (Step 3 from Section 3) to create the SP separately.

---

## 7. Verification & Cleanup

### Verify Everything Exists

```bash
# Check Subscription
az account show --output table

# Check Service Principal
az ad sp list --display-name "sp-dataplatform-admin" --output table

# Check Resource Group
az group show --name "rg-dataplatform-dev" --output table

# Check ADF
az datafactory show \
  --resource-group "rg-dataplatform-dev" \
  --factory-name "adf-myproject-dev" \
  --output table
```

### Cleanup (Delete Everything)

```bash
# Delete ADF
az datafactory delete --resource-group "rg-dataplatform-dev" --factory-name "adf-myproject-dev" --yes

# Delete Resource Group (deletes all resources inside)
az group delete --name "rg-dataplatform-dev" --yes --no-wait

# Delete Service Principal
SP_ID=$(az ad sp list --display-name "sp-dataplatform-admin" --query "[0].id" -o tsv)
az ad sp delete --id "$SP_ID"
```

---

## Quick Reference - Execution Order

| Step | Action | Tool |
|------|--------|------|
| 1 | Login to Azure | `az login` |
| 2 | Set Subscription | `az account set` |
| 3 | Create Service Principal | `az ad sp create-for-rbac` |
| 4 | Login as SP | `az login --service-principal` |
| 5 | Create Resource Group | `az group create` |
| 6 | Create ADF | `az datafactory create` |
| 7 | Verify | `az datafactory show` |

---

> **Recommendation:** Start with **Azure CLI (Section 3)** for quick setup, then move to **Terraform (Section 5)** for repeatable, version-controlled infrastructure.
