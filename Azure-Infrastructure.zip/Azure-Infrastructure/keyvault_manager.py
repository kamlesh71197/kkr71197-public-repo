"""
Azure Key Vault Secret Manager
===============================
Manages secrets in Azure Key Vault programmatically.
Operations: Create, Read, Update, Delete, List, Recover, Purge
Added: Explicit user confirmation before every operation.
Added: Smart checks to see if a secret exists before creating/updating.

Prerequisites:
    pip install azure-identity azure-keyvault-secrets azure-core python-dotenv

Usage:
    python keyvault_manager.py --action create --name "my-secret" --value "my-value"
    python keyvault_manager.py --action list
    python keyvault_manager.py --action get --name "my-secret"
    python keyvault_manager.py --action delete --name "my-secret"
    python keyvault_manager.py --action init-sp-secrets
"""

import argparse
import os
import sys

try:
    from azure.identity import ClientSecretCredential, DefaultAzureCredential
    from azure.keyvault.secrets import SecretClient
    from azure.core.exceptions import ResourceNotFoundError
except ImportError:
    print("ERROR: Required packages not installed.")
    print("Run: pip install azure-identity azure-keyvault-secrets azure-core python-dotenv")
    sys.exit(1)

# Try to load .env file if python-dotenv is available
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass


# ============================================================
# Configuration - Set via environment variables or .env file
# ============================================================
VAULT_URL = os.environ.get("AZURE_VAULT_URL", "https://kv-dataplatform-dev.vault.azure.net/")
TENANT_ID = os.environ.get("AZURE_TENANT_ID", "")
CLIENT_ID = os.environ.get("AZURE_CLIENT_ID", "")
CLIENT_SECRET = os.environ.get("AZURE_CLIENT_SECRET", "")


def confirm_action(message):
    """
    Utility Function:
    Prompts the user for confirmation (yes/no) before proceeding with any action.
    This prevents accidental overwrites or deletions.
    """
    response = input(f"\n⚠️  CONFIRM: {message} (yes/no): ").strip().lower()
    if response not in ['yes', 'y']:
        print("  ❌ Action cancelled by user.")
        sys.exit(0)


def get_secret_client():
    """
    Authentication Function:
    Connects to Azure Key Vault using either Service Principal credentials from .env
    or falls back to the DefaultAzureCredential (useful if you ran 'az login').
    """
    confirm_action(f"Connect to Azure Key Vault at {VAULT_URL}?")
    
    if TENANT_ID and CLIENT_ID and CLIENT_SECRET:
        credential = ClientSecretCredential(
            tenant_id=TENANT_ID,
            client_id=CLIENT_ID,
            client_secret=CLIENT_SECRET,
        )
        print(f"[AUTH] Using Service Principal: {CLIENT_ID[:8]}...")
    else:
        credential = DefaultAzureCredential()
        print("[AUTH] Using DefaultAzureCredential (az login / managed identity)")

    client = SecretClient(vault_url=VAULT_URL, credential=credential)
    print(f"[VAULT] Connected to: {VAULT_URL}")
    return client


# ============================================================
# CRUD Operations
# ============================================================

def upsert_secret(client, name, value, content_type="text/plain", tags=None):
    """
    Smart Create/Update Function:
    First checks if the secret already exists in Key Vault.
    If it exists, asks permission to UPDATE it (creating a new version).
    If it does not exist, asks permission to CREATE it.
    """
    exists = False
    try:
        # Check if it exists
        client.get_secret(name)
        exists = True
    except ResourceNotFoundError:
        # It does not exist, we will create it
        pass
    except Exception as e:
        print(f"  ❌ Error checking if secret exists: {e}")
        return None

    if exists:
        confirm_action(f"Secret '{name}' ALREADY EXISTS. Do you want to UPDATE it with a new version?")
        action_word = "UPDATE"
    else:
        confirm_action(f"Secret '{name}' DOES NOT EXIST. Do you want to CREATE it?")
        action_word = "CREATE"

    print(f"\n[{action_word}] Processing secret: '{name}'")
    secret = client.set_secret(
        name=name,
        value=value,
        content_type=content_type,
        tags=tags or {},
    )
    print(f"  ✅ Secret '{name}' {action_word.lower()}d successfully")
    print(f"  Version: {secret.properties.version}")
    return secret


def get_secret(client, name):
    """
    Read Function:
    Fetches a specific secret and its metadata from Key Vault.
    """
    confirm_action(f"Fetch secret '{name}' from Azure Key Vault?")
    print(f"\n[GET] Reading secret: '{name}'")
    try:
        secret = client.get_secret(name)
        print(f"  ✅ Secret '{name}' found")
        print(f"  Value:   {secret.value}")
        print(f"  Version: {secret.properties.version}")
        print(f"  Enabled: {secret.properties.enabled}")
        return secret
    except ResourceNotFoundError:
        print(f"  ❌ Secret '{name}' not found.")
    except Exception as e:
        print(f"  ❌ Error: {e}")


def list_secrets(client):
    """
    List Function:
    Fetches the names and metadata of ALL active secrets in the Key Vault.
    """
    confirm_action("Fetch a list of all secrets from Azure Key Vault?")
    print(f"\n[LIST] All secrets in vault:")
    print(f"  {'Name':<25} {'Enabled':<10} {'Content Type':<15}")
    print(f"  {'-'*25} {'-'*10} {'-'*15}")

    count = 0
    for secret_properties in client.list_properties_of_secrets():
        print(
            f"  {secret_properties.name:<25} "
            f"{str(secret_properties.enabled):<10} "
            f"{(secret_properties.content_type or 'N/A'):<15}"
        )
        count += 1

    print(f"\n  Total: {count} secret(s)")


def delete_secret(client, name):
    """
    Soft-Delete Function:
    Deletes a secret, moving it to a recoverable state for 90 days.
    """
    confirm_action(f"Soft-delete secret '{name}'? (Can be recovered for 90 days)")
    print(f"\n[DELETE] Deleting secret: '{name}'")
    try:
        poller = client.begin_delete_secret(name)
        poller.wait()
        print(f"  ✅ Secret '{name}' deleted (soft-delete)")
    except ResourceNotFoundError:
        print(f"  ❌ Secret '{name}' not found.")


def recover_secret(client, name):
    """
    Recover Function:
    Restores a soft-deleted secret back to active status.
    """
    confirm_action(f"Recover soft-deleted secret '{name}'?")
    print(f"\n[RECOVER] Recovering deleted secret: '{name}'")
    poller = client.begin_recover_deleted_secret(name)
    poller.wait()
    print(f"  ✅ Secret '{name}' recovered successfully")


def purge_secret(client, name):
    """
    Purge Function:
    PERMANENTLY destroys a soft-deleted secret. Cannot be undone!
    """
    confirm_action(f"PERMANENTLY PURGE deleted secret '{name}'? This CANNOT BE UNDONE!")
    print(f"\n[PURGE] ⚠️  PERMANENTLY purging secret: '{name}'")
    client.purge_deleted_secret(name)
    print(f"  ✅ Secret '{name}' permanently purged")


def list_deleted_secrets(client):
    """
    List Deleted Function:
    Shows all secrets currently in the soft-deleted state.
    """
    confirm_action("Fetch a list of all soft-deleted secrets?")
    print(f"\n[DELETED] Soft-deleted secrets:")
    for secret in client.list_deleted_secrets():
        print(f"  - {secret.name} (deleted: {secret.deleted_date})")


# ============================================================
# Batch Operations
# ============================================================

def init_sp_secrets(client):
    """
    Batch Initialization:
    Reads 4 Service Principal credentials from .env and processes them.
    It will check each one to see if it exists, and prompt you to create or update.
    """
    print("\n" + "=" * 60)
    print("  INITIALIZE SERVICE PRINCIPAL SECRETS IN KEY VAULT")
    print("=" * 60)

    secrets_to_process = {
        "sp-client-id": os.environ.get("SP_CLIENT_ID", ""),
        "sp-client-secret": os.environ.get("SP_CLIENT_SECRET_VALUE", ""),
        "sp-tenant-id": os.environ.get("SP_TENANT_ID", ""),
        "sp-subscription-id": os.environ.get("SP_SUBSCRIPTION_ID", ""),
    }

    # Prompt for any missing values locally before touching Azure
    for name, value in secrets_to_process.items():
        if not value:
            secrets_to_process[name] = input(f"  Enter value for '{name}': ").strip()

    print(f"\n  Checking {len(secrets_to_process)} secrets...\n")
    
    # Process each secret one by one
    for name, value in secrets_to_process.items():
        if value:
            upsert_secret(
                client,
                name=name,
                value=value,
                content_type="text/plain",
                tags={"managed-by": "keyvault_manager.py", "purpose": "service-principal"},
            )
        else:
            print(f"  ⏭️  Skipping '{name}' (no value provided)")

    print(f"\n{'=' * 60}")
    print("  ✅ Batch processing complete!")
    print(f"{'=' * 60}")


def rotate_sp_secret(client):
    """
    Rotation Function:
    Specifically updates the 'sp-client-secret' when your old password expires.
    """
    print("\n" + "=" * 60)
    print("  ROTATE SERVICE PRINCIPAL CLIENT SECRET")
    print("=" * 60)
    print("\n  Before running this, generate a new secret in Azure Portal.")
    print()

    new_secret = input("  Paste the NEW client secret value: ").strip()
    if not new_secret:
        print("  ❌ No value provided. Rotation cancelled.")
        return

    # Use our smart upsert function, which will check and prompt for update
    upsert_secret(client, "sp-client-secret", new_secret)

    print(f"\n{'=' * 60}")
    print("  ✅ Secret rotated in Key Vault!")
    print("  Next: Delete the OLD secret from App Registration (Portal)")
    print(f"{'=' * 60}")


# ============================================================
# Main
# ============================================================

def main():
    parser = argparse.ArgumentParser(
        description="Azure Key Vault Secret Manager",
    )

    parser.add_argument(
        "--action",
        required=True,
        choices=[
            "create", "get", "update", "list",
            "delete", "recover", "purge", "list-deleted",
            "init-sp-secrets", "rotate-sp-secret",
        ],
        help="Action to perform",
    )
    parser.add_argument("--name", help="Secret name")
    parser.add_argument("--value", help="Secret value")
    
    args = parser.parse_args()

    # We treat 'create' and 'update' identically now via the smart upsert_secret
    if args.action in ["create", "update"] and (not args.name or not args.value):
        parser.error(f"--name and --value are required for action '{args.action}'")

    if args.action in ["get", "delete", "recover", "purge"] and not args.name:
        parser.error(f"--name is required for action '{args.action}'")

    # Connect - confirmation prompt is inside this function
    client = get_secret_client()

    # Execute action
    action_map = {
        "create": lambda: upsert_secret(client, args.name, args.value),
        "update": lambda: upsert_secret(client, args.name, args.value),
        "get": lambda: get_secret(client, args.name),
        "list": lambda: list_secrets(client),
        "delete": lambda: delete_secret(client, args.name),
        "recover": lambda: recover_secret(client, args.name),
        "purge": lambda: purge_secret(client, args.name),
        "list-deleted": lambda: list_deleted_secrets(client),
        "init-sp-secrets": lambda: init_sp_secrets(client),
        "rotate-sp-secret": lambda: rotate_sp_secret(client),
    }

    try:
        action_map[args.action]()
    except Exception as e:
        print(f"\n  ❌ Unhandled Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
