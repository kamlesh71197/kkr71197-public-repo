"""
Airflow DAG: Trigger Azure Data Factory Pipeline securely using Azure Key Vault
================================================================================

This DAG demonstrates the architecture of retrieving the Service Principal 
client secret securely from Azure Key Vault at runtime instead of storing 
it in plain text within Airflow.

Prerequisites (Airflow environment):
    pip install azure-identity azure-keyvault-secrets apache-airflow-providers-microsoft-azure

Airflow Variables Required (in Airflow UI -> Admin -> Variables):
    - azure_key_vault_url: https://kv-dataplatform-dev.vault.azure.net/
    - azure_tenant_id: 1de55ba4-8454-4681-b678-72d5a61c6898
    - azure_client_id: e6535389-5fa8-4f7f-b27b-f55d08f6177c
    - azure_subscription_id: 6c41666d-d4b8-4bbe-928b-b4bd44ee5a8b
    - azure_resource_group: rg-dataplatform-dev
    - azure_adf_name: adf-myproject-dev

Key Vault Secrets Required (in Azure Key Vault):
    - sp-client-secret (The secret value for the Service Principal)
"""

from airflow import DAG
from airflow.models import Variable
from airflow.operators.python import PythonOperator
from datetime import datetime, timedelta
import logging

try:
    from azure.identity import ClientSecretCredential, DefaultAzureCredential
    from azure.keyvault.secrets import SecretClient
    from azure.mgmt.datafactory import DataFactoryManagementClient
except ImportError:
    logging.warning("Azure SDKs not installed. DAG will fail at runtime. " 
                    "Please run: pip install azure-identity azure-keyvault-secrets azure-mgmt-datafactory")

# DAG Default Arguments
default_args = {
    'owner': 'data-engineering-team',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

def get_secret_from_keyvault(vault_url: str, tenant_id: str, client_id: str, secret_name: str) -> str:
    """
    Fetch a secret from Azure Key Vault.
    
    In a production scenario where Airflow runs on Azure (VM, AKS), 
    DefaultAzureCredential() would automatically pick up the Managed Identity 
    of the Airflow worker without needing any bootstrap credentials!
    
    If running locally, we need bootstrap credentials.
    """
    logging.info(f"Connecting to Key Vault: {vault_url}")
    
    # ---------------------------------------------------------
    # Option A (Recommended for Azure-hosted Airflow):
    # credential = DefaultAzureCredential()
    # ---------------------------------------------------------
    
    # Option B (For local dev / outside Azure):
    # We still need a way to authenticate TO the Key Vault. 
    # Usually, we store this single bootstrap secret in Airflow connection 
    # or as an OS Environment variable.
    import os
    bootstrap_secret = os.environ.get("AZURE_CLIENT_SECRET")
    
    if bootstrap_secret:
        logging.info("Using ClientSecretCredential for Key Vault auth")
        credential = ClientSecretCredential(
            tenant_id=tenant_id,
            client_id=client_id,
            client_secret=bootstrap_secret
        )
    else:
        logging.info("Falling back to DefaultAzureCredential (Managed Identity / Azure CLI)")
        credential = DefaultAzureCredential()

    secret_client = SecretClient(vault_url=vault_url, credential=credential)
    secret = secret_client.get_secret(secret_name)
    logging.info(f"Successfully retrieved secret '{secret_name}' from Key Vault.")
    
    return secret.value

def trigger_adf_pipeline(**context):
    """
    Main task: Fetch SP secret from Key Vault and trigger the ADF pipeline.
    """
    # 1. Fetch configuration from Airflow Variables
    vault_url = Variable.get("azure_key_vault_url", default_var="https://kv-dataplatform-dev.vault.azure.net/")
    tenant_id = Variable.get("azure_tenant_id", default_var="1de55ba4-8454-4681-b678-72d5a61c6898")
    client_id = Variable.get("azure_client_id", default_var="e6535389-5fa8-4f7f-b27b-f55d08f6177c")
    subscription_id = Variable.get("azure_subscription_id", default_var="6c41666d-d4b8-4bbe-928b-b4bd44ee5a8b")
    resource_group = Variable.get("azure_resource_group", default_var="rg-dataplatform-dev")
    adf_name = Variable.get("azure_adf_name", default_var="adf-myproject-dev")
    
    # The name of your actual pipeline inside ADF
    pipeline_name = context.get('pipeline_name', "my-data-pipeline") 
    
    # 2. Securely fetch the Service Principal password from Key Vault
    logging.info("Fetching SP Client Secret from Azure Key Vault...")
    sp_client_secret = get_secret_from_keyvault(
        vault_url=vault_url,
        tenant_id=tenant_id,
        client_id=client_id,
        secret_name="sp-client-secret"  # We created this in keyvault_manager.py
    )
    
    # 3. Authenticate using the fetched secret
    logging.info("Authenticating Data Factory Client...")
    credential = ClientSecretCredential(
        tenant_id=tenant_id,
        client_id=client_id,
        client_secret=sp_client_secret
    )
    
    adf_client = DataFactoryManagementClient(credential, subscription_id)
    
    # 4. Trigger the ADF Pipeline
    logging.info(f"Triggering ADF Pipeline '{pipeline_name}' in '{adf_name}'...")
    
    # Add any parameters your pipeline expects here
    pipeline_parameters = {} 
    
    run_response = adf_client.pipelines.create_run(
        resource_group_name=resource_group,
        factory_name=adf_name,
        pipeline_name=pipeline_name,
        parameters=pipeline_parameters
    )
    
    logging.info(f"✅ Pipeline triggered successfully!")
    logging.info(f"Run ID: {run_response.run_id}")
    
    # Pushing the run_id to XCom in case downstream tasks need it to poll for status
    context['ti'].xcom_push(key='adf_run_id', value=run_response.run_id)
    
    return run_response.run_id

# Define the DAG
with DAG(
    dag_id="trigger_azure_data_factory",
    default_args=default_args,
    description="Trigger ADF pipeline using Key Vault secrets",
    schedule_interval="@daily",
    start_date=datetime(2026, 1, 1),
    catchup=False,
    tags=["azure", "adf", "keyvault", "data-platform"],
) as dag:

    # Task to trigger the pipeline
    trigger_pipeline_task = PythonOperator(
        task_id="trigger_adf_pipeline",
        python_callable=trigger_adf_pipeline,
        op_kwargs={'pipeline_name': 'my-data-pipeline'}, # Replace with your actual ADF pipeline name
        provide_context=True,
    )
    
    # You can add a polling task here later if you want Airflow to wait for ADF to finish
    # poll_pipeline_task = PythonOperator(...)
    
    trigger_pipeline_task
