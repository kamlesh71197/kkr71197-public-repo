"""
Service Principal Secret Rotation Script
========================================
This script demonstrates the end-to-end flow of rotating an Azure Service Principal
client secret and updating it in Azure Key Vault.

Phase 1: Hardcoded Configuration
"""

import sys
import requests
from datetime import datetime

try:
    from azure.identity import ClientSecretCredential
    from azure.keyvault.secrets import SecretClient
except ImportError:
    print("ERROR: Missing dependencies.")
    print("Run: pip install azure-identity azure-keyvault-secrets requests")
    sys.exit(1)


# ============================================================
# HARDCODED CONFIGURATION (As requested for Phase 1)
# ============================================================
TENANT_ID = "1de55ba4-8454-4681-b678-72d5a61c6898"
CLIENT_ID = "e6535389-5fa8-4f7f-b27b-f55d08f6177c"

# The CURRENT secret used to authenticate and perform the rotation
CURRENT_CLIENT_SECRET = "QLc8Q~iodeUwbGrQQ1Oktk3xhaBCwyQUp-hONbmG"

# To modify the App Registration via Graph API, we need its Object ID
OBJECT_ID = "63116369-2583-4620-ae5e-1711fe824808" 
VAULT_URL = "https://kv-dataplatform-dev.vault.azure.net/"


def confirm_step(message):
    """Prompt the user for confirmation before proceeding to the next step."""
    response = input(f"\n⚠️  CONFIRM: {message} (yes/no): ").strip().lower()
    if response not in ['yes', 'y']:
        print("  ❌ Execution cancelled by user.")
        sys.exit(0)


def print_flow_overview():
    """Prints the execution flow of the script."""
    print("================================================================")
    print("          SERVICE PRINCIPAL SECRET ROTATION FLOW                ")
    print("================================================================")
    print("  Step 1: Authenticate to Azure using Explicit Credentials")
    print("  Step 2: Generate an access token for Microsoft Graph API")
    print("  Step 3: Call Graph API to create a NEW secret for the SP")
    print("  Step 4: Authenticate to Azure Key Vault")
    print("  Step 5: Store the NEW secret in Key Vault (as a new version)")
    print("================================================================\n")


def authenticate_azure():
    """Step 1: Get Azure Credentials using explicit ClientSecretCredential."""
    confirm_step("Step 1: Initialize Azure Authentication with hardcoded credentials?")
    print("  -> Initializing ClientSecretCredential...")
    
    # We must explicitly pass the credentials (not DefaultAzureCredential)
    credential = ClientSecretCredential(
        tenant_id=TENANT_ID,
        client_id=CLIENT_ID,
        client_secret=CURRENT_CLIENT_SECRET
    )
    print("  ✅ Authentication initialized.")
    return credential


def generate_new_sp_secret(credential, object_id):
    """Step 2 & 3: Use MS Graph API to add a new password to the Service Principal."""
    confirm_step("Step 2 & 3: Call MS Graph API to generate a NEW secret?")
    
    print("  -> Fetching access token for Microsoft Graph...")
    # Fetch token specifically for MS Graph API
    token = credential.get_token("https://graph.microsoft.com/.default")
    
    headers = {
        "Authorization": f"Bearer {token.token}",
        "Content-Type": "application/json"
    }
    
    # Payload for the new secret
    payload = {
        "passwordCredential": {
            "displayName": f"Rotated via Script - {datetime.now().strftime('%Y-%m-%d')}"
        }
    }
    
    print(f"  -> Sending request to Graph API to add password to App Object ID: {object_id}...")
    url = f"https://graph.microsoft.com/v1.0/applications/{object_id}/addPassword"
    
    response = requests.post(url, headers=headers, json=payload)
    
    if response.status_code in [200, 201]:
        data = response.json()
        new_secret_value = data["secretText"]
        key_id = data["keyId"]
        print("  ✅ New secret successfully generated in Azure AD!")
        print(f"  -> New Key ID: {key_id}")
        print(f"  -> New Secret begins with: {new_secret_value[:5]}********")
        return new_secret_value
    else:
        print(f"  ❌ Failed to generate secret. Status Code: {response.status_code}")
        print(f"  ❌ Response: {response.text}")
        sys.exit(1)


def update_key_vault(credential, vault_url, secret_name, new_secret_value):
    """Step 4 & 5: Save the new secret value into Key Vault."""
    confirm_step(f"Step 4 & 5: Push the NEW secret to Key Vault '{vault_url}'?")
    
    print(f"  -> Connecting to Key Vault: {vault_url}...")
    secret_client = SecretClient(vault_url=vault_url, credential=credential)
    
    print(f"  -> Updating secret '{secret_name}' with new version...")
    secret = secret_client.set_secret(secret_name, new_secret_value)
    
    print("  ✅ Key Vault successfully updated!")
    print(f"  -> Secret Name: {secret.name}")
    print(f"  -> New Version ID: {secret.properties.version}")


def main():
    print_flow_overview()
    
    # Ask permission to start
    confirm_step("Are you ready to begin the rotation process?")
    
    # Execute Steps
    credential = authenticate_azure()
    
    new_secret_value = generate_new_sp_secret(credential, OBJECT_ID)
    
    # 'sp-client-secret' is the name stored in Key Vault
    update_key_vault(credential, VAULT_URL, "sp-client-secret", new_secret_value)
    
    print("\n================================================================")
    print(" 🎉 ROTATION COMPLETE! ")
    print("================================================================")
    print("  The Service Principal has a new password in Azure AD.")
    print("  The new password has been safely stored in Azure Key Vault.")
    print("  Downstream systems (like Airflow) will automatically pull the new version.")


if __name__ == "__main__":
    main()
