# Azure Manual Setup Guide - Step by Step (Azure Portal)

> **Your Current Status:** You've already created Subscription, Resource Group (`rg-dataplatform-dev`), and ADF (`adf-myproject-dev`). This guide documents what you did + remaining steps.

---

## Execution Checklist

| # | Step | Status |
|---|------|--------|
| 1 | Create Azure Account & Tenant | ✅ Done |
| 2 | Create Subscription | ✅ Done |
| 3 | Create Resource Group | ✅ Done |
| 4 | Create Azure Data Factory | ✅ Done |
| 5 | Create App Registration (Service Principal) | ⬜ Pending |
| 6 | Create Client Secret for SP | ⬜ Pending |
| 7 | Assign Least-Privilege Role (Data Factory Contributor) | ⬜ Pending |
| 8 | Test SP Login via CLI | ⬜ Pending |
| 9 | Create Azure Key Vault & Store Secrets | ⬜ Pending |
| 10 | Grant ADF/SP Access to Key Vault | ⬜ Pending |
| 11 | Configure Airflow Variables via Key Vault | ⬜ Pending |

---

## Step 1: Azure Account & Tenant (✅ Already Done)

This was created when you signed up for Azure.

**How to verify:**
1. Go to [Azure Portal](https://portal.azure.com)
2. Click your profile icon (top-right) → **Switch directory**
3. You'll see your **Tenant Name** and **Tenant ID**

**Save this value:**
```
Tenant ID: ______________________________
```

---

## Step 2: Create Subscription (✅ Already Done)

**How to verify:**
1. Go to [Azure Portal](https://portal.azure.com)
2. Search **"Subscriptions"** in the top search bar
3. You should see your subscription listed

**Save this value:**
```
Subscription Name: ______________________________
Subscription ID:   ______________________________
```

> **For reference - How you would create a new subscription:**
> 1. Portal → Search **"Subscriptions"**
> 2. Click **"+ Add"**
> 3. Select plan type (Pay-As-You-Go / Free Trial / Enterprise)
> 4. Fill billing details → **Create**

---

## Step 3: Create Resource Group (✅ Already Done)

**How to verify:**
1. Portal → Search **"Resource groups"**
2. You should see `rg-dataplatform-dev`
3. Click on it to see its properties

**Save these values:**
```
Resource Group Name: rg-dataplatform-dev
Location:            ______________________________
```

> **For reference - How you created it:**
> 1. Portal → Search **"Resource groups"** → Click **"+ Create"**
> 2. Select your **Subscription**
> 3. Resource group name: `rg-dataplatform-dev`
> 4. Region: Select your preferred region (e.g., East US)
> 5. Click **"Review + create"** → **"Create"**

---

## Step 4: Create Azure Data Factory (✅ Already Done)

**How to verify:**
1. Portal → Search **"Data factories"**
2. You should see `adf-myproject-dev`
3. Click on it → Note the **Resource ID** and **Managed Identity**

**Save these values:**
```
ADF Name:              adf-myproject-dev
ADF Resource ID:       ______________________________
Managed Identity ID:   ______________________________  (check under Properties → Identity)
```

> **For reference - How you created it:**
> 1. Portal → Search **"Data factories"** → Click **"+ Create"**
> 2. Subscription: Your subscription
> 3. Resource Group: `rg-dataplatform-dev`
> 4. Name: `adf-myproject-dev`
> 5. Region: Same as resource group
> 6. Click **"Review + create"** → **"Create"**

---

## Step 5: Create App Registration / Service Principal (⬜ DO THIS NOW)

The Service Principal is the **identity** that will programmatically manage your Azure resources (instead of using your personal login).

### What is a Service Principal?
```
Think of it like a "robot account" for your applications:
- Your personal login    → You (human) accessing Azure Portal
- Service Principal      → Your app/script accessing Azure APIs
```

### Steps:

1. Go to [Azure Portal](https://portal.azure.com)
2. Search **"App registrations"** in the top search bar → Click it
3. Click **"+ New registration"**

4. Fill in the form:
   ```
   Name:                sp-dataplatform-admin
   Supported account types: "Accounts in this organizational directory only" (Single tenant)
   Redirect URI:        Leave blank (we don't need it for service-to-service)
   ```

5. Click **"Register"**

6. You'll land on the **Overview** page. **SAVE THESE VALUES:**
   ```
   Application (client) ID:  ______________________________
   Directory (tenant) ID:    ______________________________
   Object ID:                ______________________________
   ```

### Screenshot Reference - What You Should See:
```
┌─────────────────────────────────────────────────────────┐
│  sp-dataplatform-admin | Overview                        │
│                                                          │
│  Display name:              sp-dataplatform-admin        │
│  Application (client) ID:   xxxxxxxx-xxxx-xxxx-xxxx     │
│  Directory (tenant) ID:     xxxxxxxx-xxxx-xxxx-xxxx     │
│  Object ID:                 xxxxxxxx-xxxx-xxxx-xxxx     │
│                                                          │
│  [Endpoints] [Redirect URIs] [Certificates & secrets]   │
└─────────────────────────────────────────────────────────┘
```

---

## Step 6: Create Client Secret for Service Principal (⬜ DO THIS NOW)

The Client Secret is like a **password** for your Service Principal.

### Steps:

1. You should still be on the **App Registration** page for `sp-dataplatform-admin`
2. In the left sidebar, click **"Certificates & secrets"**
3. Click the **"Client secrets"** tab
4. Click **"+ New client secret"**

5. Fill in:
   ```
   Description:  sp-dataplatform-secret
   Expires:      12 months (recommended) or Custom
   ```

6. Click **"Add"**

7. ⚠️ **IMMEDIATELY COPY THE SECRET VALUE!** It will only be shown once!

   ```
   Secret ID:     ______________________________
   Value:         ______________________________  ← THIS IS YOUR CLIENT SECRET (copy NOW!)
   Expires:       ______________________________
   ```

> **⚠️ CRITICAL WARNING:** The secret **Value** is shown only once. If you navigate away without copying it, you'll need to create a new secret. The Secret ID is NOT the secret itself.

### After This Step You Should Have:
```
┌─────────────────────────────────────────────────────────┐
│  YOUR CREDENTIALS (Save securely - do NOT share!)       │
│                                                          │
│  Tenant ID:       xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx  │
│  Client ID:       xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx  │
│  Client Secret:   xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx      │
│  Subscription ID: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx  │
└─────────────────────────────────────────────────────────┘
```

---

## Step 7: Assign Least-Privilege Role to Service Principal (⬜ DO THIS NOW)

We follow **least privilege** — the SP only gets **Data Factory Contributor** (not full Contributor).

### Why Least Privilege?
```
❌ Contributor         → Can manage ALL resources (Storage, VMs, DBs, everything)
✅ Data Factory Contributor → Can ONLY manage Data Factories (nothing else)
```

### Steps:

1. Go to Portal → Search **"Resource groups"** → Click `rg-dataplatform-dev`
2. In the left sidebar, click **"Access control (IAM)"**
3. Click **"+ Add"** → **"Add role assignment"**

4. **Role tab:**
   - Search for **"Data Factory Contributor"**
   - Select **"Data Factory Contributor"**
   - Click **"Next"**

5. **Members tab:**
   - "Assign access to": Select **"User, group, or service principal"**
   - Click **"+ Select members"**
   - Search for **"sp-dataplatform-admin"**
   - Select it → Click **"Select"**
   - Click **"Next"**

6. **Review + assign tab:**
   - Review the details
   - Click **"Review + assign"**

> **⚠️ IMPORTANT:** We assign the role at the **Resource Group** level (not Subscription). This means the SP can only manage ADF inside `rg-dataplatform-dev`, not other resource groups.

### Verify Role Assignment:
1. Stay on **Access control (IAM)** page
2. Click **"Role assignments"** tab
3. Search for `sp-dataplatform-admin`
4. You should see:

```
┌───────────────────────────────────────────────────────────────────────┐
│ Role Assignments                                                      │
│                                                                       │
│ Name                      Role                       Scope            │
│ sp-dataplatform-admin     Data Factory Contributor    rg-dataplatform  │
└───────────────────────────────────────────────────────────────────────┘
```

### Least Privilege Role Reference:
| Role | Scope | Use Case |
|------|-------|----------|
| **Data Factory Contributor** | Resource Group | Manage ADF only (✅ recommended) |
| **Contributor** | Subscription | Manage everything (❌ too broad) |
| **Owner** | Subscription | Full access + permissions (❌ dangerous) |
| **Key Vault Secrets User** | Key Vault | Read secrets only (used in Step 10) |

---

## Step 8: Test Service Principal Login via CLI (⬜ DO THIS NOW)

Now verify that your Service Principal can authenticate and access resources.

### Prerequisites:
- Install [Azure CLI](https://aka.ms/installazurecliwindows) if not already installed
- Open **PowerShell** or **Command Prompt**

### Steps:

```bash
# Step 8a: First, logout from any existing session
az logout

# Step 8b: Login using Service Principal
az login --service-principal \
  --username "YOUR_CLIENT_ID" \
  --password "YOUR_CLIENT_SECRET" \
  --tenant "YOUR_TENANT_ID"

# Step 8c: Verify you can see the subscription
az account show --output table

# Step 8d: Verify you can see the resource group
az group show --name "rg-dataplatform-dev" --output table

# Step 8e: Verify you can see ADF
az datafactory show \
  --resource-group "rg-dataplatform-dev" \
  --factory-name "adf-myproject-dev" \
  --output table
```

### Windows PowerShell Version (no backslash line breaks):
```powershell
# Logout first
az logout

# Login as Service Principal
az login --service-principal --username "YOUR_CLIENT_ID" --password "YOUR_CLIENT_SECRET" --tenant "YOUR_TENANT_ID"

# Verify
az account show --output table
az group show --name "rg-dataplatform-dev" --output table
az datafactory show --resource-group "rg-dataplatform-dev" --factory-name "adf-myproject-dev" --output table
```

### Expected Output:
```
EnvironmentName    IsDefault    Name                 State    TenantId
-----------------  ----------  -------------------  -------  ------------------------------------
AzureCloud         True        MyProject-Sub        Enabled  xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
```

### If It Fails:
| Error | Cause | Fix |
|-------|-------|-----|
| `AADSTS7000215` | Wrong Client Secret | Recreate secret (Step 6) |
| `AADSTS700016` | Wrong Client ID | Check App Registration overview |
| `AADSTS90002` | Wrong Tenant ID | Check Azure AD → Properties |
| `AuthorizationFailed` | No role assigned | Redo Step 7 |

---

## Step 9: Create Azure Key Vault & Store Secrets (⬜ DO THIS NOW)

Instead of storing secrets in plain text, we store them in **Azure Key Vault** and retrieve them via API.

### Why Key Vault?
```
❌ Plain text secrets    → In code, env files, Airflow UI (INSECURE)
✅ Azure Key Vault       → Centralized, encrypted, access-controlled, audited
```

### Flow:
```
SP Client Secret ──stored in──▶ Azure Key Vault
                                      │
                   Airflow DAG calls Key Vault API
                                      │
                              ◀── returns secret ──▶ used to authenticate SP
                                                          │
                                                    SP triggers ADF Pipeline
```

### Step 9a: Create Key Vault (Portal)

1. Go to Portal → Search **"Key vaults"** → Click **"+ Create"**
2. Fill in:
   ```
   Subscription:       Your subscription
   Resource Group:     rg-dataplatform-dev
   Key Vault Name:     kv-dataplatform-dev    (must be globally unique)
   Region:             Same as your resource group
   Pricing tier:       Standard
   ```
3. Click **"Review + create"** → **"Create"**

**Save this value:**
```
Key Vault Name:  kv-dataplatform-dev
Key Vault URI:   https://kv-dataplatform-dev.vault.azure.net/
```

### Step 9b: Install Python Packages

```powershell
pip install azure-identity azure-keyvault-secrets python-dotenv
```

### Step 9c: Configure Environment Variables

1. Copy `.env.example` to `.env` in the `Azure-Infrastructure` folder
2. Fill in your actual values:

```env
# Key Vault URL
AZURE_VAULT_URL=https://kv-dataplatform-dev.vault.azure.net/

# SP credentials (to authenticate TO Key Vault)
AZURE_TENANT_ID=<your-tenant-id>
AZURE_CLIENT_ID=<your-client-id>
AZURE_CLIENT_SECRET=<your-client-secret>

# Values to store AS secrets in Key Vault
SP_CLIENT_ID=<your-client-id>
SP_CLIENT_SECRET_VALUE=<your-client-secret>
SP_TENANT_ID=<your-tenant-id>
SP_SUBSCRIPTION_ID=<your-subscription-id>
```

> **⚠️ NEVER commit `.env` to Git!** Add it to `.gitignore`.

### Step 9d: Create All SP Secrets at Once (Python Script)

```powershell
# Initialize all 4 SP secrets in Key Vault in one command
python keyvault_manager.py --action init-sp-secrets
```

This creates these secrets in Key Vault automatically:
| Secret Name | Source |
|-------------|--------|
| `sp-client-id` | From `SP_CLIENT_ID` env var (or prompts you) |
| `sp-client-secret` | From `SP_CLIENT_SECRET_VALUE` env var (or prompts you) |
| `sp-tenant-id` | From `SP_TENANT_ID` env var (or prompts you) |
| `sp-subscription-id` | From `SP_SUBSCRIPTION_ID` env var (or prompts you) |

### Step 9e: Verify Secrets Were Created

```powershell
# List all secrets in vault
python keyvault_manager.py --action list

# Read a specific secret
python keyvault_manager.py --action get --name "sp-client-id"
```

### Step 9f: Key Vault Operations via Python Script

All operations use `keyvault_manager.py`:

**Create a new secret:**
```powershell
python keyvault_manager.py --action create --name "my-secret" --value "my-value"
```

**Read/view a secret:**
```powershell
python keyvault_manager.py --action get --name "sp-client-id"
```

**Update a secret (creates new version):**
```powershell
python keyvault_manager.py --action update --name "sp-client-secret" --value "new-secret-value"
```

**Disable a secret (temporary block):**
```powershell
python keyvault_manager.py --action disable --name "sp-client-secret"
```

**Re-enable a disabled secret:**
```powershell
python keyvault_manager.py --action enable --name "sp-client-secret"
```

**Delete a secret (soft-delete, recoverable 90 days):**
```powershell
python keyvault_manager.py --action delete --name "sp-client-secret"
```

**Recover a deleted secret:**
```powershell
python keyvault_manager.py --action recover --name "sp-client-secret"
```

**Permanently purge a secret (IRREVERSIBLE!):**
```powershell
python keyvault_manager.py --action purge --name "sp-client-secret"
```

**List soft-deleted secrets:**
```powershell
python keyvault_manager.py --action list-deleted
```

### Step 9g: Rotate SP Client Secret (When It Expires)

```powershell
# Interactive rotation — prompts you for the new secret value
python keyvault_manager.py --action rotate-sp-secret
```

**Full rotation workflow:**
```
Step 1: Portal → App Registrations → sp-dataplatform-admin
Step 2: Certificates & secrets → + New client secret → Copy value
Step 3: Run: python keyvault_manager.py --action rotate-sp-secret
Step 4: Paste the new value when prompted
Step 5: Delete OLD secret from App Registration (Portal)
```

### Key Vault Operations Quick Reference

| Action | Command |
|--------|---------|
| **Init all SP secrets** | `python keyvault_manager.py --action init-sp-secrets` |
| **List all** | `python keyvault_manager.py --action list` |
| **View one** | `python keyvault_manager.py --action get --name "NAME"` |
| **Create** | `python keyvault_manager.py --action create --name "NAME" --value "VALUE"` |
| **Update** | `python keyvault_manager.py --action update --name "NAME" --value "NEW_VALUE"` |
| **Disable** | `python keyvault_manager.py --action disable --name "NAME"` |
| **Enable** | `python keyvault_manager.py --action enable --name "NAME"` |
| **Delete** | `python keyvault_manager.py --action delete --name "NAME"` |
| **Recover** | `python keyvault_manager.py --action recover --name "NAME"` |
| **Purge** | `python keyvault_manager.py --action purge --name "NAME"` |
| **Rotate SP secret** | `python keyvault_manager.py --action rotate-sp-secret` |

---

## Step 10: Grant ADF & SP Access to Key Vault (⬜ DO THIS NOW)

Both the **ADF Managed Identity** and the **Service Principal** need permission to read secrets from Key Vault.

### Step 10a: Enable RBAC on Key Vault

1. Go to your Key Vault → Left sidebar → **"Access configuration"**
2. Under **Permission model**, select **"Azure role-based access control (RBAC)"**
3. Click **"Apply"**

### Step 10b: Grant ADF Managed Identity Access

1. Go to your Key Vault → Left sidebar → **"Access control (IAM)"**
2. Click **"+ Add"** → **"Add role assignment"**
3. **Role:** Search and select **"Key Vault Secrets User"**
4. **Members:** Search for **"adf-myproject-dev"** (ADF's managed identity)
5. Click **"Review + assign"**

### Step 10c: Grant SP Access to Key Vault

1. Still on Key Vault → **"Access control (IAM)"**
2. Click **"+ Add"** → **"Add role assignment"**
3. **Role:** Search and select **"Key Vault Secrets User"**
4. **Members:** Search for **"sp-dataplatform-admin"**
5. Click **"Review + assign"**

### Verify Access (Key Vault IAM should show):
```
┌─────────────────────────────────────────────────────────────────┐
│ Key Vault Role Assignments                                       │
│                                                                   │
│ Name                      Role                      Type          │
│ adf-myproject-dev         Key Vault Secrets User    Managed ID    │
│ sp-dataplatform-admin     Key Vault Secrets User    App/SP        │
└─────────────────────────────────────────────────────────────────┘
```

### Test Secret Retrieval via CLI:
```powershell
# Login as SP first (Step 8)
az login --service-principal --username "YOUR_CLIENT_ID" --password "YOUR_CLIENT_SECRET" --tenant "YOUR_TENANT_ID"

# Read a secret from Key Vault
az keyvault secret show --vault-name "kv-dataplatform-dev" --name "sp-client-id" --query value -o tsv
```

If this returns your Client ID value, access is working!

---

## Step 11: Configure Airflow Variables via Key Vault (⬜ DO THIS NOW)

Now set up Airflow to **fetch secrets from Key Vault** instead of storing them in plain text.

### Architecture:
```
Airflow DAG
    │
    ├── Airflow Variable: "azure_key_vault_url" = "https://kv-dataplatform-dev.vault.azure.net/"
    ├── Airflow Variable: "azure_tenant_id"     = "<your-tenant-id>"
    ├── Airflow Variable: "azure_client_id"     = "<your-client-id>"
    │
    └── At runtime: DAG calls Key Vault API → gets sp-client-secret → authenticates SP → triggers ADF
```

### Step 11a: Set Airflow Variables (Airflow UI)

1. Open Airflow UI → **Admin** → **Variables**
2. Add these variables:

| Key | Value | Description |
|-----|-------|-------------|
| `azure_key_vault_url` | `https://kv-dataplatform-dev.vault.azure.net/` | Key Vault endpoint |
| `azure_tenant_id` | `<your-tenant-id>` | For SP authentication |
| `azure_client_id` | `<your-client-id>` | SP App ID |
| `azure_subscription_id` | `<your-subscription-id>` | Subscription |
| `azure_resource_group` | `rg-dataplatform-dev` | Resource Group |
| `azure_adf_name` | `adf-myproject-dev` | ADF instance name |

> **Note:** The **Client Secret is NOT stored in Airflow** — it's fetched from Key Vault at runtime!

### Step 11b: Install Required Python Packages

```bash
pip install azure-identity azure-keyvault-secrets apache-airflow-providers-microsoft-azure
```

### Step 11c: Example DAG — Fetch Secret from Key Vault & Trigger ADF

```python
from airflow import DAG
from airflow.models import Variable
from datetime import datetime
from azure.identity import ClientSecretCredential
from azure.keyvault.secrets import SecretClient
from azure.mgmt.datafactory import DataFactoryManagementClient

def get_secret_from_keyvault(vault_url, tenant_id, client_id, secret_name):
    """
    Fetch a secret from Azure Key Vault.
    The client_secret itself is retrieved from Key Vault using 
    a bootstrap secret (or Managed Identity if running on Azure).
    """
    # Option 1: If Airflow runs on Azure (VM/AKS), use Managed Identity
    # from azure.identity import ManagedIdentityCredential
    # credential = ManagedIdentityCredential()

    # Option 2: If Airflow runs outside Azure, use SP credentials
    # For bootstrap, you need the client_secret stored as env var or Airflow connection
    import os
    client_secret = os.environ.get("AZURE_CLIENT_SECRET")  # Set as env var on Airflow server
    
    credential = ClientSecretCredential(
        tenant_id=tenant_id,
        client_id=client_id,
        client_secret=client_secret
    )
    
    secret_client = SecretClient(vault_url=vault_url, credential=credential)
    secret = secret_client.get_secret(secret_name)
    return secret.value


def trigger_adf_pipeline(**context):
    """Fetch secrets from Key Vault and trigger ADF pipeline."""
    
    # Get Airflow Variables
    vault_url = Variable.get("azure_key_vault_url")
    tenant_id = Variable.get("azure_tenant_id")
    client_id = Variable.get("azure_client_id")
    subscription_id = Variable.get("azure_subscription_id")
    resource_group = Variable.get("azure_resource_group")
    adf_name = Variable.get("azure_adf_name")
    
    # Fetch client secret from Key Vault (NOT from Airflow!)
    client_secret = get_secret_from_keyvault(
        vault_url=vault_url,
        tenant_id=tenant_id,
        client_id=client_id,
        secret_name="sp-client-secret"
    )
    
    # Authenticate using the fetched secret
    credential = ClientSecretCredential(
        tenant_id=tenant_id,
        client_id=client_id,
        client_secret=client_secret
    )
    
    # Trigger ADF Pipeline
    adf_client = DataFactoryManagementClient(credential, subscription_id)
    run = adf_client.pipelines.create_run(
        resource_group_name=resource_group,
        factory_name=adf_name,
        pipeline_name="your-pipeline-name",  # Change this
        parameters={}  # Add pipeline parameters if needed
    )
    
    print(f"ADF Pipeline triggered! Run ID: {run.run_id}")
    return run.run_id


# DAG Definition
with DAG(
    dag_id="trigger_adf_via_keyvault",
    start_date=datetime(2026, 1, 1),
    schedule_interval="@daily",
    catchup=False,
    tags=["azure", "adf", "keyvault"],
) as dag:
    
    from airflow.operators.python import PythonOperator
    
    trigger_task = PythonOperator(
        task_id="trigger_adf_pipeline",
        python_callable=trigger_adf_pipeline,
    )
```

### Step 11d: Alternative — Use Airflow Azure Key Vault Backend (Recommended)

Instead of manually calling Key Vault in each DAG, configure Airflow to **automatically** pull secrets from Key Vault:

Add to your `airflow.cfg` or environment variables:
```ini
[secrets]
backend = airflow.providers.microsoft.azure.secrets.key_vault.AzureKeyVaultBackend
backend_kwargs = {
    "connections_prefix": "airflow-conn",
    "variables_prefix": "airflow-var",
    "vault_url": "https://kv-dataplatform-dev.vault.azure.net/"
}
```

Then in Key Vault, store secrets with the prefix:
| Key Vault Secret Name | Airflow Sees It As |
|----------------------|-------------------|
| `airflow-var-azure-client-id` | Variable: `azure_client_id` |
| `airflow-var-azure-tenant-id` | Variable: `azure_tenant_id` |
| `airflow-conn-azure-default` | Connection: `azure_default` |

This way Airflow **auto-fetches** variables from Key Vault — zero secrets in Airflow DB!

---

## Summary: Your Complete Architecture

```
┌──────────────────────────────────────────────────────────────────┐
│                        AZURE TENANT                               │
│                                                                    │
│  ┌──────────────────┐     ┌──────────────────────────────────┐    │
│  │ Service Principal │     │ Azure Key Vault                  │    │
│  │ (Data Factory     │◄────│ kv-dataplatform-dev              │    │
│  │  Contributor)     │     │                                   │    │
│  └────────┬─────────┘     │  • sp-client-id                  │    │
│           │                │  • sp-client-secret              │    │
│           ▼                │  • sp-tenant-id                  │    │
│  ┌─────────────────┐      │  • sp-subscription-id            │    │
│  │  Subscription    │      └──────────────┬───────────────────┘    │
│  │                  │                     │                        │
│  │  ┌────────────┐  │                     │ (fetches secret)       │
│  │  │  Resource   │  │                     │                        │
│  │  │  Group      │  │      ┌──────────────┴───────────────┐       │
│  │  │             │  │      │         AIRFLOW               │       │
│  │  │  ┌────────┐ │  │      │  Variables:                   │       │
│  │  │  │  ADF   │ │  │◄─────│  • azure_key_vault_url       │       │
│  │  │  │        │ │  │      │  • azure_tenant_id            │       │
│  │  │  └────────┘ │  │      │  • azure_client_id            │       │
│  │  └────────────┘  │      └────────────────────────────────┘       │
│  └─────────────────┘                                               │
└──────────────────────────────────────────────────────────────────┘
```

### Credentials Storage:
```
╔══════════════════════════════════════════════════════════════════╗
║  SECRET STORAGE STRATEGY (Least Privilege)                       ║
╠══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  Key Vault Name:   kv-dataplatform-dev                           ║
║  Key Vault URI:    https://kv-dataplatform-dev.vault.azure.net/  ║
║                                                                   ║
║  Secrets Stored:                                                  ║
║    • sp-client-id         → SP Application ID                    ║
║    • sp-client-secret     → SP Password (NEVER in Airflow!)      ║
║    • sp-tenant-id         → Azure Tenant ID                      ║
║    • sp-subscription-id   → Subscription ID                      ║
║                                                                   ║
║  Resource Group:   rg-dataplatform-dev                            ║
║  ADF Name:         adf-myproject-dev                              ║
║                                                                   ║
╠══════════════════════════════════════════════════════════════════╣
║  ⚠️  Client Secret lives ONLY in Key Vault                      ║
║  ⚠️  Airflow fetches it at runtime via Key Vault API             ║
║  ⚠️  SP has Data Factory Contributor ONLY (not Contributor)      ║
╚══════════════════════════════════════════════════════════════════╝
```

---

## What's Next?

Once you've completed all manual steps:

1. **→ Move to Terraform** — Automate this entire setup (Key Vault + SP + ADF + roles) using IaC
   See: `azure-org-structure.md` → Section 5

2. **→ Create ADF Pipelines** — Start building data pipelines in ADF Studio
   Portal → Data Factories → `adf-myproject-dev` → **Launch Studio**

3. **→ Set up CI/CD** — Connect ADF to Git (Azure DevOps / GitHub) for version control

4. **→ Build Airflow DAGs** — Create production DAGs that trigger ADF pipelines via Key Vault
