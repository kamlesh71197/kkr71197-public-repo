# Seed Data — Phase 0 & Phase A (Development & Testing)
# MySQL Version

# Version: 1.0 | Date: 2026-05-01
# Stack: MySQL 8.0+ + MongoDB 7 + Redis 7
# ORM: Prisma (but raw SQL provided here for direct DB seeding)
# Purpose: Developers can seed local DB, test APIs from Flutter app, and verify full ride flow

-- ===========================================================================
-- IMPORTANT: MySQL Configuration Requirements
-- ===========================================================================
-- Ensure these settings in my.cnf or via SET GLOBAL:
-- sql_mode = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION'
-- character_set_server = utf8mb4
-- collation_server = utf8mb4_unicode_ci

-- ===========================================================================
-- 📋 Dummy Personas (Use these for all testing)
-- ===========================================================================

/*
| Role | Name | Phone | Telegram Chat ID | UUID (fixed for FK refs) |
|------|------|-------|-------------------|--------------------------|
| **Rider 1** | Aarav Sharma | +919876543210 | 100001 | a1b2c3d4-0001-4000-a000-000000000001 |
| **Rider 2** | Priya Patel | +919876543211 | 100002 | a1b2c3d4-0002-4000-a000-000000000002 |
| **Rider 3** | Rahul Verma | +919876543212 | 100003 | a1b2c3d4-0003-4000-a000-000000000003 |
| **Driver 1** | Vikram Singh | +919876543220 | 200001 | a1b2c3d4-0010-4000-a000-000000000010 |
| **Driver 2** | Suresh Kumar | +919876543221 | 200002 | a1b2c3d4-0011-4000-a000-000000000011 |
| **Driver 3** | Manoj Yadav | +919876543222 | 200003 | a1b2c3d4-0012-4000-a000-000000000012 |
| **Admin** | Karthik Admin | +919876543200 | 300001 | a1b2c3d4-0099-4000-a000-000000000099 |

**Test Locations (Bangalore):**

| Place | Lat | Lng | Address |
|-------|-----|-----|---------|
| Koramangala | 12.9352 | 77.6245 | 80 Feet Road, Koramangala, Bangalore 560034 |
| Indiranagar | 12.9784 | 77.6408 | 100 Feet Road, Indiranagar, Bangalore 560038 |
| Whitefield | 12.9698 | 77.7500 | ITPL Main Road, Whitefield, Bangalore 560066 |
| MG Road | 12.9756 | 77.6065 | MG Road, Bangalore 560001 |
| Electronic City | 12.8440 | 77.6630 | Electronic City Phase 1, Bangalore 560100 |
| Airport (KIA) | 13.1989 | 77.7068 | Kempegowda International Airport, Bangalore |
| HSR Layout | 12.9116 | 77.6389 | 27th Main, HSR Layout, Bangalore 560102 |
| Jayanagar | 12.9299 | 77.5838 | 4th Block, Jayanagar, Bangalore 560041 |
*/

-- ===========================================================================
-- SECTION 1 — Database Setup & Character Set
-- ===========================================================================

DROP DATABASE IF EXISTS rideapp_dev;
CREATE DATABASE rideapp_dev CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE rideapp_dev;

-- ===========================================================================
-- SECTION 2 — Phase 0: CREATE TABLE (Dependency Order)
-- ===========================================================================
-- Tables are in topological order — no FK will reference a table that doesn't exist yet.
-- MySQL doesn't have native ENUM types in the same way as PostgreSQL, so we use VARCHAR with CHECK constraints

-- ============================================================================
-- PHASE 0, TABLE 1: users (root table — no FK dependencies)
-- ============================================================================
CREATE TABLE users (
    id              CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    first_name      VARCHAR(100) NOT NULL,
    last_name       VARCHAR(100) NOT NULL,
    email           VARCHAR(255) UNIQUE,
    phone           VARCHAR(20) NOT NULL UNIQUE,
    country_code    VARCHAR(5) NOT NULL DEFAULT '+91',
    profile_pic_url TEXT,
    role            ENUM('rider', 'driver', 'restaurant_owner', 'admin') NOT NULL DEFAULT 'rider',
    app_type        ENUM('customer', 'partner') NOT NULL DEFAULT 'customer',
    is_email_verified BOOLEAN NOT NULL DEFAULT FALSE,
    is_phone_verified BOOLEAN NOT NULL DEFAULT FALSE,
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    is_deleted      BOOLEAN NOT NULL DEFAULT FALSE,
    avg_rating      FLOAT NOT NULL DEFAULT 0.0,
    telegram_chat_id BIGINT,
    preferred_language VARCHAR(5) NOT NULL DEFAULT 'en',
    preferred_currency VARCHAR(5) NOT NULL DEFAULT 'INR',
    timezone        VARCHAR(50) NOT NULL DEFAULT 'Asia/Kolkata',
    deleted_at      TIMESTAMP NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_users_phone (phone),
    INDEX idx_users_telegram (telegram_chat_id),
    INDEX idx_users_role (role)
) ENGINE=InnoDB;

-- ============================================================================
-- PHASE 0, TABLE 2: user_sessions (depends on: users)
-- ============================================================================
CREATE TABLE user_sessions (
    id            CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    user_id       CHAR(36) NOT NULL,
    device_token  TEXT,
    device_type   ENUM('ios', 'android', 'web') NOT NULL,
    device_model  VARCHAR(100),
    app_version   VARCHAR(20),
    ip_address    VARCHAR(45),
    refresh_token TEXT NOT NULL,
    expires_at    TIMESTAMP NOT NULL,
    is_active     BOOLEAN NOT NULL DEFAULT TRUE,
    created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_sessions_user (user_id),
    INDEX idx_sessions_active (user_id, is_active)
) ENGINE=InnoDB;

-- ============================================================================
-- PHASE 0, TABLE 3: rider_profiles (depends on: users)
-- ============================================================================
CREATE TABLE rider_profiles (
    id                CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    user_id           CHAR(36) NOT NULL UNIQUE,
    home_address      TEXT,
    home_lat          FLOAT,
    home_lng          FLOAT,
    work_address      TEXT,
    work_lat          FLOAT,
    work_lng          FLOAT,
    preferred_payment ENUM('card', 'wallet', 'cash', 'upi') NOT NULL DEFAULT 'cash',
    is_premium        BOOLEAN NOT NULL DEFAULT FALSE,
    is_active         BOOLEAN NOT NULL DEFAULT TRUE,
    created_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================================
-- PHASE 0, TABLE 4: driver_profiles (depends on: users)
-- ============================================================================
CREATE TABLE driver_profiles (
    id                   CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    user_id              CHAR(36) NOT NULL UNIQUE,
    license_number       VARCHAR(50) NOT NULL UNIQUE,
    license_expiry       DATE NOT NULL,
    is_available         BOOLEAN NOT NULL DEFAULT FALSE,
    verification_status  ENUM('pending', 'documents_submitted', 'under_review', 'approved', 'rejected', 'suspended') NOT NULL DEFAULT 'pending',
    current_lat          FLOAT,
    current_lng          FLOAT,
    status               ENUM('online', 'offline', 'on_ride', 'on_delivery') NOT NULL DEFAULT 'offline',
    payout_frequency     ENUM('daily', 'weekly') NOT NULL DEFAULT 'weekly',
    bank_account_number  TEXT,
    bank_ifsc            VARCHAR(20),
    bank_name            VARCHAR(100),
    is_active            BOOLEAN NOT NULL DEFAULT TRUE,
    last_location_update TIMESTAMP NULL,
    created_at           TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at           TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================================
-- PHASE 0, TABLE 5: vehicle_types (no FK dependencies — reference data)
-- ============================================================================
CREATE TABLE vehicle_types (
    id                    CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    name                  VARCHAR(50) NOT NULL UNIQUE,
    display_name          VARCHAR(100) NOT NULL,
    icon_url              TEXT,
    default_seat_capacity INT NOT NULL CHECK (default_seat_capacity > 0),
    is_active             BOOLEAN NOT NULL DEFAULT TRUE,
    created_at            TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================================
-- PHASE 0, TABLE 6: vehicles (depends on: driver_profiles, vehicle_types)
-- ============================================================================
CREATE TABLE vehicles (
    id              CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    driver_id       CHAR(36) NOT NULL,
    vehicle_type_id CHAR(36) NOT NULL,
    make            VARCHAR(50) NOT NULL,
    model           VARCHAR(50) NOT NULL,
    year            INT NOT NULL CHECK (year >= 2000 AND year <= 2030),
    color           VARCHAR(30) NOT NULL,
    license_plate   VARCHAR(20) NOT NULL UNIQUE,
    seat_capacity   INT NOT NULL CHECK (seat_capacity > 0),
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    is_current      BOOLEAN NOT NULL DEFAULT FALSE,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (driver_id) REFERENCES driver_profiles(id) ON DELETE CASCADE,
    FOREIGN KEY (vehicle_type_id) REFERENCES vehicle_types(id),
    INDEX idx_vehicles_driver (driver_id)
) ENGINE=InnoDB;

-- ============================================================================
-- PHASE 0, TABLE 7: driver_documents (depends on: driver_profiles, users)
-- ============================================================================
CREATE TABLE driver_documents (
    id               CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    driver_id        CHAR(36) NOT NULL,
    doc_type         ENUM('driving_license', 'vehicle_insurance', 'vehicle_registration', 'background_check', 'identity_proof', 'address_proof', 'vehicle_photo') NOT NULL,
    document_url     TEXT NOT NULL,
    status           ENUM('pending', 'under_review', 'approved', 'rejected', 'expired') NOT NULL DEFAULT 'pending',
    rejection_reason TEXT,
    verified_by      CHAR(36),
    uploaded_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    verified_at      TIMESTAMP NULL,
    expiry_date      DATE,
    FOREIGN KEY (driver_id) REFERENCES driver_profiles(id) ON DELETE CASCADE,
    FOREIGN KEY (verified_by) REFERENCES users(id),
    INDEX idx_driver_docs (driver_id)
) ENGINE=InnoDB;

-- ============================================================================
-- PHASE 0, TABLE 8: favorite_locations (depends on: users)
-- ============================================================================
CREATE TABLE favorite_locations (
    id         CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    user_id    CHAR(36) NOT NULL,
    label      VARCHAR(50) NOT NULL,
    lat        FLOAT NOT NULL,
    lng        FLOAT NOT NULL,
    address    TEXT NOT NULL,
    sort_order INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_fav_loc_user (user_id)
) ENGINE=InnoDB;

-- ============================================================================
-- PHASE 0, TABLE 9: emergency_contacts (depends on: users)
-- ============================================================================
CREATE TABLE emergency_contacts (
    id             CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    user_id        CHAR(36) NOT NULL,
    name           VARCHAR(100) NOT NULL,
    phone          VARCHAR(20) NOT NULL,
    relationship   VARCHAR(50),
    is_primary     BOOLEAN NOT NULL DEFAULT FALSE,
    notify_on_ride BOOLEAN NOT NULL DEFAULT FALSE,
    created_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_emergency_user (user_id)
) ENGINE=InnoDB;

-- ============================================================================
-- PHASE 0, TABLE 10: wallets (depends on: users)
-- ============================================================================
CREATE TABLE wallets (
    id         CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    user_id    CHAR(36) NOT NULL UNIQUE,
    balance    DECIMAL(12,2) NOT NULL DEFAULT 0.00 CHECK (balance >= 0),
    currency   VARCHAR(5) NOT NULL DEFAULT 'INR',
    is_active  BOOLEAN NOT NULL DEFAULT TRUE,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================================
-- PHASE 0, TABLE 11: wallet_transactions (depends on: wallets)
-- ============================================================================
CREATE TABLE wallet_transactions (
    id            CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    wallet_id     CHAR(36) NOT NULL,
    amount        DECIMAL(12,2) NOT NULL,
    type          ENUM('credit', 'debit') NOT NULL,
    source        ENUM('ride_payment', 'refund', 'cashback', 'referral_bonus', 'top_up', 'withdrawal', 'food_payment', 'parcel_payment') NOT NULL,
    description   TEXT NOT NULL,
    reference_id  CHAR(36),
    balance_after DECIMAL(12,2) NOT NULL,
    created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (wallet_id) REFERENCES wallets(id) ON DELETE CASCADE,
    INDEX idx_wallet_txn_wallet (wallet_id, created_at)
) ENGINE=InnoDB;

-- ============================================================================
-- PHASE 0, TABLE 12: payment_methods (depends on: users)
-- ============================================================================
CREATE TABLE payment_methods (
    id          CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    user_id     CHAR(36) NOT NULL,
    method_type ENUM('card', 'upi', 'net_banking') NOT NULL,
    provider    VARCHAR(50) NOT NULL,
    token       TEXT NOT NULL,
    last_four   VARCHAR(4),
    is_default  BOOLEAN NOT NULL DEFAULT FALSE,
    is_active   BOOLEAN NOT NULL DEFAULT TRUE,
    created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_payment_methods_user (user_id)
) ENGINE=InnoDB;

-- ============================================================================
-- PHASE 0, TABLE 13: system_configs (no FK — reference data)
-- ============================================================================
CREATE TABLE system_configs (
    id           CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    config_key   VARCHAR(100) NOT NULL UNIQUE,
    config_value TEXT NOT NULL,
    description  TEXT,
    group_name   VARCHAR(50) NOT NULL DEFAULT 'general',
    updated_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ===========================================================================
-- SECTION 3 — Phase A: CREATE TABLE (Dependency Order)
-- ===========================================================================

-- ============================================================================
-- PHASE A.1 — RIDE BOOKING (Weeks 5–7)
-- ============================================================================

-- TABLE A.1: fare_rules (depends on: vehicle_types)
CREATE TABLE fare_rules (
    id                     CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    vehicle_type_id        CHAR(36) NOT NULL,
    city                   VARCHAR(100) NOT NULL,
    zone                   VARCHAR(100),
    base_fare              FLOAT NOT NULL CHECK (base_fare >= 0),
    per_km_rate            FLOAT NOT NULL CHECK (per_km_rate >= 0),
    per_min_rate           FLOAT NOT NULL CHECK (per_min_rate >= 0),
    min_fare               FLOAT NOT NULL CHECK (min_fare >= 0),
    booking_fee            FLOAT NOT NULL DEFAULT 0,
    cancellation_fee       FLOAT NOT NULL CHECK (cancellation_fee >= 0),
    waiting_charge_per_min FLOAT NOT NULL DEFAULT 0,
    night_surcharge_pct    FLOAT NOT NULL DEFAULT 0,
    is_active              BOOLEAN NOT NULL DEFAULT TRUE,
    effective_from         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    effective_to           TIMESTAMP NULL,
    FOREIGN KEY (vehicle_type_id) REFERENCES vehicle_types(id),
    INDEX idx_fare_rules_city (city, vehicle_type_id)
) ENGINE=InnoDB;

-- TABLE A.2: surge_zones (no FK dependencies)
CREATE TABLE surge_zones (
    id               CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    city             VARCHAR(100) NOT NULL,
    zone_name        VARCHAR(100) NOT NULL,
    geo_boundary     TEXT,
    surge_multiplier FLOAT NOT NULL CHECK (surge_multiplier >= 1.0),
    active_from      TIMESTAMP NOT NULL,
    active_to        TIMESTAMP NOT NULL,
    reason           VARCHAR(50) NOT NULL DEFAULT 'high_demand',
    created_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- TABLE A.3: rental_packages (depends on: vehicle_types)
CREATE TABLE rental_packages (
    id              CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    vehicle_type_id CHAR(36) NOT NULL,
    name            VARCHAR(100) NOT NULL,
    hours           INT NOT NULL CHECK (hours > 0),
    kms_included    INT NOT NULL CHECK (kms_included > 0),
    package_fare    FLOAT NOT NULL CHECK (package_fare > 0),
    extra_km_rate   FLOAT NOT NULL CHECK (extra_km_rate >= 0),
    extra_min_rate  FLOAT NOT NULL CHECK (extra_min_rate >= 0),
    city            VARCHAR(100) NOT NULL,
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (vehicle_type_id) REFERENCES vehicle_types(id)
) ENGINE=InnoDB;

-- TABLE A.4: ride_requests (depends on: rider_profiles, vehicle_types)
CREATE TABLE ride_requests (
    id                    CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    rider_id              CHAR(36) NOT NULL,
    vehicle_type_id       CHAR(36) NOT NULL,
    pickup_lat            FLOAT NOT NULL,
    pickup_lng            FLOAT NOT NULL,
    pickup_address        TEXT NOT NULL,
    dropoff_lat           FLOAT NOT NULL,
    dropoff_lng           FLOAT NOT NULL,
    dropoff_address       TEXT NOT NULL,
    ride_type             ENUM('standard', 'premium', 'pool', 'rental', 'outstation') NOT NULL DEFAULT 'standard',
    seats_requested       INT NOT NULL DEFAULT 1 CHECK (seats_requested > 0),
    estimated_fare        FLOAT NOT NULL CHECK (estimated_fare > 0),
    estimated_distance_km FLOAT NOT NULL CHECK (estimated_distance_km > 0),
    estimated_duration_min INT NOT NULL CHECK (estimated_duration_min > 0),
    surge_multiplier      FLOAT NOT NULL DEFAULT 1.0,
    status                ENUM('pending', 'searching', 'matched', 'cancelled', 'expired', 'no_drivers') NOT NULL DEFAULT 'pending',
    is_scheduled          BOOLEAN NOT NULL DEFAULT FALSE,
    scheduled_at          TIMESTAMP NULL,
    expires_at            TIMESTAMP NOT NULL DEFAULT (CURRENT_TIMESTAMP + INTERVAL 5 MINUTE),
    created_at            TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (rider_id) REFERENCES rider_profiles(id),
    FOREIGN KEY (vehicle_type_id) REFERENCES vehicle_types(id),
    INDEX idx_ride_requests_rider (rider_id),
    INDEX idx_ride_requests_status (status, created_at)
) ENGINE=InnoDB;

-- TABLE A.5: rides (depends on: ride_requests, driver_profiles, vehicles)
CREATE TABLE rides (
    id                      CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    request_id              CHAR(36) NOT NULL UNIQUE,
    driver_id               CHAR(36) NOT NULL,
    vehicle_id              CHAR(36) NOT NULL,
    carpool_id              CHAR(36),
    ride_number             VARCHAR(30) NOT NULL UNIQUE,
    status                  ENUM('accepted', 'driver_arriving', 'arrived', 'in_progress', 'completed', 'cancelled') NOT NULL DEFAULT 'accepted',
    estimated_fare          FLOAT NOT NULL,
    actual_fare             FLOAT,
    base_fare               FLOAT NOT NULL,
    distance_km             FLOAT,
    per_km_charged          FLOAT NOT NULL,
    per_min_charged         FLOAT NOT NULL,
    duration_minutes        INT,
    surge_multiplier        FLOAT NOT NULL DEFAULT 1.0,
    platform_commission_pct FLOAT NOT NULL DEFAULT 20.0,
    platform_commission_amt FLOAT,
    driver_earning          FLOAT,
    toll_charges            FLOAT NOT NULL DEFAULT 0,
    waiting_charges         FLOAT NOT NULL DEFAULT 0,
    otp_code                VARCHAR(4) NOT NULL,
    cancelled_by            ENUM('rider', 'driver', 'system'),
    cancellation_reason     TEXT,
    cancellation_fee        FLOAT NOT NULL DEFAULT 0,
    is_split_fare           BOOLEAN NOT NULL DEFAULT FALSE,
    accepted_at             TIMESTAMP NULL,
    driver_arrived_at       TIMESTAMP NULL,
    pickup_at               TIMESTAMP NULL,
    dropoff_at              TIMESTAMP NULL,
    cancelled_at            TIMESTAMP NULL,
    created_at              TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (request_id) REFERENCES ride_requests(id),
    FOREIGN KEY (driver_id) REFERENCES driver_profiles(id),
    FOREIGN KEY (vehicle_id) REFERENCES vehicles(id),
    INDEX idx_rides_driver_status (driver_id, status),
    INDEX idx_rides_active (status)
) ENGINE=InnoDB;

-- TABLE A.6: ride_stops (depends on: rides)
CREATE TABLE ride_stops (
    id          CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    ride_id     CHAR(36) NOT NULL,
    stop_order  INT NOT NULL CHECK (stop_order > 0),
    lat         FLOAT NOT NULL,
    lng         FLOAT NOT NULL,
    address     TEXT NOT NULL,
    status      ENUM('pending', 'arrived', 'completed', 'skipped') NOT NULL DEFAULT 'pending',
    eta         TIMESTAMP NULL,
    arrived_at  TIMESTAMP NULL,
    departed_at TIMESTAMP NULL,
    FOREIGN KEY (ride_id) REFERENCES rides(id) ON DELETE CASCADE,
    INDEX idx_ride_stops_ride (ride_id)
) ENGINE=InnoDB;

-- TABLE A.7: ride_riders (depends on: rides, rider_profiles)
CREATE TABLE ride_riders (
    id             CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    ride_id        CHAR(36) NOT NULL,
    rider_id       CHAR(36) NOT NULL,
    pickup_lat     FLOAT NOT NULL,
    pickup_lng     FLOAT NOT NULL,
    pickup_address TEXT NOT NULL,
    dropoff_lat    FLOAT NOT NULL,
    dropoff_lng    FLOAT NOT NULL,
    dropoff_address TEXT NOT NULL,
    fare_share     FLOAT NOT NULL CHECK (fare_share >= 0),
    status         ENUM('waiting', 'picked_up', 'dropped_off', 'cancelled') NOT NULL DEFAULT 'waiting',
    created_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ride_id) REFERENCES rides(id) ON DELETE CASCADE,
    FOREIGN KEY (rider_id) REFERENCES rider_profiles(id),
    INDEX idx_ride_riders_ride (ride_id)
) ENGINE=InnoDB;

-- TABLE A.8: ride_routes (depends on: rides)
CREATE TABLE ride_routes (
    id                    CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    ride_id               CHAR(36) NOT NULL,
    polyline_encoded      TEXT,
    distance_km           FLOAT NOT NULL,
    estimated_duration_min INT NOT NULL,
    is_actual             BOOLEAN NOT NULL DEFAULT FALSE,
    created_at            TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ride_id) REFERENCES rides(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- TABLE A.9: ride_location_logs (depends on: rides, driver_profiles)
CREATE TABLE ride_location_logs (
    id          CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    ride_id     CHAR(36) NOT NULL,
    driver_id   CHAR(36) NOT NULL,
    lat         FLOAT NOT NULL,
    lng         FLOAT NOT NULL,
    speed       FLOAT,
    bearing     FLOAT,
    recorded_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ride_id) REFERENCES rides(id) ON DELETE CASCADE,
    FOREIGN KEY (driver_id) REFERENCES driver_profiles(id),
    INDEX idx_location_log_ride (ride_id, recorded_at)
) ENGINE=InnoDB;

-- TABLE A.10: split_fare_invites (depends on: rides, users)
CREATE TABLE split_fare_invites (
    id             CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    ride_id        CHAR(36) NOT NULL,
    inviter_id     CHAR(36) NOT NULL,
    invitee_id     CHAR(36),
    invitee_phone  VARCHAR(20) NOT NULL,
    share_amount   FLOAT NOT NULL CHECK (share_amount > 0),
    status         ENUM('pending', 'accepted', 'declined', 'expired') NOT NULL DEFAULT 'pending',
    created_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    responded_at   TIMESTAMP NULL,
    FOREIGN KEY (ride_id) REFERENCES rides(id) ON DELETE CASCADE,
    FOREIGN KEY (inviter_id) REFERENCES users(id),
    FOREIGN KEY (invitee_id) REFERENCES users(id)
) ENGINE=InnoDB;

-- ============================================================================
-- PHASE A.2 — PAYMENTS (Week 8)
-- ============================================================================

-- TABLE A.11: payments (depends on: users, rides)
CREATE TABLE payments (
    id                 CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    user_id            CHAR(36) NOT NULL,
    ride_id            CHAR(36),
    order_id           CHAR(36),
    parcel_id          CHAR(36),
    payment_number     VARCHAR(30) NOT NULL UNIQUE,
    amount             DECIMAL(12,2) NOT NULL CHECK (amount > 0),
    discount           DECIMAL(12,2) NOT NULL DEFAULT 0,
    tax                DECIMAL(12,2) NOT NULL DEFAULT 0,
    final_amount       DECIMAL(12,2) NOT NULL CHECK (final_amount >= 0),
    method             ENUM('card', 'wallet', 'cash', 'upi', 'net_banking') NOT NULL,
    payment_method_id  CHAR(36),
    status             ENUM('pending', 'processing', 'completed', 'failed', 'refunded', 'partially_refunded') NOT NULL DEFAULT 'pending',
    gateway_order_id   TEXT,
    gateway_payment_id TEXT,
    gateway_signature  TEXT,
    paid_at            TIMESTAMP NULL,
    refunded_at        TIMESTAMP NULL,
    created_at         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (ride_id) REFERENCES rides(id),
    FOREIGN KEY (payment_method_id) REFERENCES payment_methods(id),
    INDEX idx_payments_user (user_id),
    INDEX idx_payments_ride (ride_id),
    INDEX idx_payments_status (status, created_at)
) ENGINE=InnoDB;

-- TABLE A.12: promo_codes (depends on: vehicle_types)
CREATE TABLE promo_codes (
    id                        CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    code                      VARCHAR(30) NOT NULL UNIQUE,
    description               TEXT,
    discount_type             ENUM('percentage', 'flat') NOT NULL,
    discount_value            DECIMAL(12,2) NOT NULL CHECK (discount_value > 0),
    max_discount              DECIMAL(12,2),
    min_order_amount          DECIMAL(12,2) NOT NULL DEFAULT 0,
    max_uses_total            INT,
    max_uses_per_user         INT NOT NULL DEFAULT 1,
    current_uses              INT NOT NULL DEFAULT 0,
    applicable_to             ENUM('ride', 'food', 'parcel', 'all') NOT NULL DEFAULT 'all',
    applicable_vehicle_type_id CHAR(36),
    applicable_city           VARCHAR(100),
    valid_from                TIMESTAMP NOT NULL,
    valid_to                  TIMESTAMP NOT NULL,
    is_active                 BOOLEAN NOT NULL DEFAULT TRUE,
    created_at                TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (applicable_vehicle_type_id) REFERENCES vehicle_types(id),
    CHECK (valid_to > valid_from)
) ENGINE=InnoDB;

-- TABLE A.13: promo_usages (depends on: promo_codes, users, rides)
CREATE TABLE promo_usages (
    id               CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    promo_id         CHAR(36) NOT NULL,
    user_id          CHAR(36) NOT NULL,
    ride_id          CHAR(36),
    order_id         CHAR(36),
    parcel_id        CHAR(36),
    discount_applied DECIMAL(12,2) NOT NULL,
    used_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (promo_id) REFERENCES promo_codes(id),
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (ride_id) REFERENCES rides(id),
    INDEX idx_promo_usage_promo (promo_id),
    INDEX idx_promo_usage_user (user_id)
) ENGINE=InnoDB;

-- TABLE A.14: driver_earnings (depends on: driver_profiles, rides)
CREATE TABLE driver_earnings (
    id                   CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    driver_id            CHAR(36) NOT NULL,
    ride_id              CHAR(36),
    order_id             CHAR(36),
    parcel_id            CHAR(36),
    gross_amount         DECIMAL(12,2) NOT NULL,
    commission_deducted  DECIMAL(12,2) NOT NULL,
    incentive_bonus      DECIMAL(12,2) NOT NULL DEFAULT 0,
    tip                  DECIMAL(12,2) NOT NULL DEFAULT 0,
    net_earning          DECIMAL(12,2) NOT NULL,
    status               ENUM('pending', 'paid') NOT NULL DEFAULT 'pending',
    earned_at            TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    paid_at              TIMESTAMP NULL,
    FOREIGN KEY (driver_id) REFERENCES driver_profiles(id),
    FOREIGN KEY (ride_id) REFERENCES rides(id),
    INDEX idx_earnings_driver (driver_id, status)
) ENGINE=InnoDB;

-- TABLE A.15: driver_payouts (depends on: driver_profiles)
CREATE TABLE driver_payouts (
    id              CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    driver_id       CHAR(36) NOT NULL,
    amount          DECIMAL(12,2) NOT NULL CHECK (amount > 0),
    status          ENUM('pending', 'processing', 'completed', 'failed') NOT NULL DEFAULT 'pending',
    frequency       ENUM('daily', 'weekly') NOT NULL,
    period_start    DATE NOT NULL,
    period_end      DATE NOT NULL,
    bank_reference  TEXT,
    processed_at    TIMESTAMP NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (driver_id) REFERENCES driver_profiles(id),
    INDEX idx_payouts_driver (driver_id),
    CHECK (period_end >= period_start)
) ENGINE=InnoDB;

-- ============================================================================
-- PHASE A.3 — RATING (Week 9)
-- ============================================================================

-- TABLE A.16: ratings (depends on: rides, users)
CREATE TABLE ratings (
    id            CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    ride_id       CHAR(36),
    order_id      CHAR(36),
    parcel_id     CHAR(36),
    from_user_id  CHAR(36) NOT NULL,
    to_user_id    CHAR(36) NOT NULL,
    score         INT NOT NULL CHECK (score >= 1 AND score <= 5),
    review_text   VARCHAR(500),
    created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ride_id) REFERENCES rides(id),
    FOREIGN KEY (from_user_id) REFERENCES users(id),
    FOREIGN KEY (to_user_id) REFERENCES users(id),
    INDEX idx_ratings_to_user (to_user_id),
    CHECK (from_user_id != to_user_id)
) ENGINE=InnoDB;

-- TABLE A.17: rating_tags (no FK — reference data)
CREATE TABLE rating_tags (
    id            CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    tag_name      VARCHAR(100) NOT NULL UNIQUE,
    applicable_to ENUM('rider_to_driver', 'driver_to_rider', 'customer_to_restaurant') NOT NULL,
    is_active     BOOLEAN NOT NULL DEFAULT TRUE
) ENGINE=InnoDB;

-- TABLE A.18: rating_tag_maps (depends on: ratings, rating_tags)
CREATE TABLE rating_tag_maps (
    id        CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    rating_id CHAR(36) NOT NULL,
    tag_id    CHAR(36) NOT NULL,
    FOREIGN KEY (rating_id) REFERENCES ratings(id) ON DELETE CASCADE,
    FOREIGN KEY (tag_id) REFERENCES rating_tags(id),
    UNIQUE KEY unique_rating_tag (rating_id, tag_id),
    INDEX idx_rating_tag_map_rating (rating_id)
) ENGINE=InnoDB;

-- ============================================================================
-- PHASE A.4 — SAFETY & SOS (Week 10)
-- ============================================================================

-- TABLE A.19: sos_alerts (depends on: users, rides)
CREATE TABLE sos_alerts (
    id           CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    user_id      CHAR(36) NOT NULL,
    ride_id      CHAR(36),
    lat          FLOAT NOT NULL,
    lng          FLOAT NOT NULL,
    status       ENUM('triggered', 'acknowledged', 'responded', 'resolved', 'false_alarm') NOT NULL DEFAULT 'triggered',
    notes        TEXT,
    resolved_by  CHAR(36),
    triggered_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    resolved_at  TIMESTAMP NULL,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (ride_id) REFERENCES rides(id),
    FOREIGN KEY (resolved_by) REFERENCES users(id)
) ENGINE=InnoDB;

-- TABLE A.20: ride_insurances (depends on: rides)
CREATE TABLE ride_insurances (
    id              CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    ride_id         CHAR(36) NOT NULL UNIQUE,
    policy_number   VARCHAR(50) NOT NULL,
    provider        VARCHAR(100) NOT NULL,
    coverage_amount DECIMAL(12,2) NOT NULL,
    status          ENUM('active', 'claimed', 'expired') NOT NULL DEFAULT 'active',
    valid_from      TIMESTAMP NOT NULL,
    valid_to        TIMESTAMP NOT NULL,
    FOREIGN KEY (ride_id) REFERENCES rides(id)
) ENGINE=InnoDB;

-- TABLE A.21: live_location_shares (depends on: rides, rider_profiles, emergency_contacts)
CREATE TABLE live_location_shares (
    id                   CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    ride_id              CHAR(36) NOT NULL,
    rider_id             CHAR(36) NOT NULL,
    emergency_contact_id CHAR(36) NOT NULL,
    share_token          TEXT NOT NULL,
    is_active            BOOLEAN NOT NULL DEFAULT TRUE,
    shared_at            TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expires_at           TIMESTAMP NOT NULL,
    FOREIGN KEY (ride_id) REFERENCES rides(id) ON DELETE CASCADE,
    FOREIGN KEY (rider_id) REFERENCES users(id),
    FOREIGN KEY (emergency_contact_id) REFERENCES emergency_contacts(id)
) ENGINE=InnoDB;

-- ============================================================================
-- PHASE A.5 — SUPPORT TICKETS (Week 10)
-- ============================================================================

-- TABLE A.22: support_categories (self-ref FK)
CREATE TABLE support_categories (
    id                 CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    name               VARCHAR(100) NOT NULL UNIQUE,
    description        TEXT,
    parent_category_id CHAR(36),
    sort_order         INT NOT NULL DEFAULT 0,
    is_active          BOOLEAN NOT NULL DEFAULT TRUE,
    FOREIGN KEY (parent_category_id) REFERENCES support_categories(id)
) ENGINE=InnoDB;

-- TABLE A.23: support_tickets (depends on: users, support_categories, rides)
CREATE TABLE support_tickets (
    id            CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    user_id       CHAR(36) NOT NULL,
    category_id   CHAR(36) NOT NULL,
    ride_id       CHAR(36),
    order_id      CHAR(36),
    parcel_id     CHAR(36),
    ticket_number VARCHAR(30) NOT NULL UNIQUE,
    subject       VARCHAR(200) NOT NULL,
    description   TEXT NOT NULL,
    priority      ENUM('low', 'medium', 'high', 'urgent') NOT NULL DEFAULT 'medium',
    status        ENUM('open', 'in_progress', 'awaiting_user', 'resolved', 'closed', 'reopened') NOT NULL DEFAULT 'open',
    assigned_to   CHAR(36),
    resolved_at   TIMESTAMP NULL,
    closed_at     TIMESTAMP NULL,
    created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (category_id) REFERENCES support_categories(id),
    FOREIGN KEY (ride_id) REFERENCES rides(id),
    FOREIGN KEY (assigned_to) REFERENCES users(id),
    INDEX idx_tickets_user (user_id),
    INDEX idx_tickets_status (status, priority)
) ENGINE=InnoDB;

-- TABLE A.24: support_messages (depends on: support_tickets, users)
CREATE TABLE support_messages (
    id               CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    ticket_id        CHAR(36) NOT NULL,
    sender_id        CHAR(36) NOT NULL,
    content          TEXT NOT NULL,
    attachment_url   TEXT,
    is_internal_note BOOLEAN NOT NULL DEFAULT FALSE,
    sent_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ticket_id) REFERENCES support_tickets(id) ON DELETE CASCADE,
    FOREIGN KEY (sender_id) REFERENCES users(id),
    INDEX idx_support_msgs_ticket (ticket_id)
) ENGINE=InnoDB;

-- ===========================================================================
-- SECTION 4 — INSERT: Seed Data for Phase 0
-- ===========================================================================

-- ============================================================================
-- 4.1 USERS — 7 personas (3 riders, 3 drivers, 1 admin)
-- ============================================================================

INSERT INTO users (id, first_name, last_name, email, phone, country_code, role, app_type, is_phone_verified, telegram_chat_id) VALUES
-- Riders
('a1b2c3d4-0001-4000-a000-000000000001', 'Aarav',    'Sharma',  'aarav@test.com',    '+919876543210', '+91', 'rider',  'customer', TRUE, 100001),
('a1b2c3d4-0002-4000-a000-000000000002', 'Priya',    'Patel',   'priya@test.com',    '+919876543211', '+91', 'rider',  'customer', TRUE, 100002),
('a1b2c3d4-0003-4000-a000-000000000003', 'Rahul',    'Verma',   NULL,                '+919876543212', '+91', 'rider',  'customer', TRUE, 100003),
-- Drivers
('a1b2c3d4-0010-4000-a000-000000000010', 'Vikram',   'Singh',   'vikram@test.com',   '+919876543220', '+91', 'driver', 'partner',  TRUE, 200001),
('a1b2c3d4-0011-4000-a000-000000000011', 'Suresh',   'Kumar',   NULL,                '+919876543221', '+91', 'driver', 'partner',  TRUE, 200002),
('a1b2c3d4-0012-4000-a000-000000000012', 'Manoj',    'Yadav',   'manoj@test.com',    '+919876543222', '+91', 'driver', 'partner',  TRUE, 200003),
-- Admin
('a1b2c3d4-0099-4000-a000-000000000099', 'Karthik',  'Admin',   'admin@rideapp.com', '+919876543200', '+91', 'admin',  'partner',  TRUE, 300001);

-- ============================================================================
-- 4.2 USER SESSIONS (active sessions for login testing)
-- ============================================================================

INSERT INTO user_sessions (id, user_id, device_type, device_model, app_version, ip_address, refresh_token, expires_at) VALUES
-- Aarav on Android
('a2000001-0001-4000-a000-000000000001', 'a1b2c3d4-0001-4000-a000-000000000001',
 'android', 'Samsung Galaxy S24', '1.0.0', '103.21.58.100',
 'hashed_refresh_aarav_session_001', DATE_ADD(NOW(), INTERVAL 30 DAY)),
-- Priya on iOS
('a2000001-0002-4000-a000-000000000002', 'a1b2c3d4-0002-4000-a000-000000000002',
 'ios', 'iPhone 15 Pro', '1.0.0', '103.21.58.101',
 'hashed_refresh_priya_session_001', DATE_ADD(NOW(), INTERVAL 30 DAY)),
-- Vikram on Android (driver app)
('a2000001-0010-4000-a000-000000000010', 'a1b2c3d4-0010-4000-a000-000000000010',
 'android', 'Samsung Galaxy A54', '1.0.0', '103.21.58.200',
 'hashed_refresh_vikram_session_001', DATE_ADD(NOW(), INTERVAL 30 DAY)),
-- Suresh on Android (driver app)
('a2000001-0011-4000-a000-000000000011', 'a1b2c3d4-0011-4000-a000-000000000011',
 'android', 'Redmi Note 13', '1.0.0', '103.21.58.201',
 'hashed_refresh_suresh_session_001', DATE_ADD(NOW(), INTERVAL 30 DAY)),
-- Admin on web
('a2000001-0099-4000-a000-000000000099', 'a1b2c3d4-0099-4000-a000-000000000099',
 'web', NULL, '1.0.0', '103.21.58.50',
 'hashed_refresh_admin_session_001', DATE_ADD(NOW(), INTERVAL 7 DAY));

-- ============================================================================
-- 4.3 RIDER PROFILES
-- ============================================================================

INSERT INTO rider_profiles (id, user_id, home_address, home_lat, home_lng, work_address, work_lat, work_lng, preferred_payment) VALUES
('b1000001-0001-4000-a000-000000000001', 'a1b2c3d4-0001-4000-a000-000000000001',
 '80 Feet Road, Koramangala, Bangalore 560034', 12.9352, 77.6245,
 'ITPL Main Road, Whitefield, Bangalore 560066', 12.9698, 77.7500, 'upi'),
('b1000001-0002-4000-a000-000000000002', 'a1b2c3d4-0002-4000-a000-000000000002',
 '100 Feet Road, Indiranagar, Bangalore 560038', 12.9784, 77.6408,
 'MG Road, Bangalore 560001', 12.9756, 77.6065, 'card'),
('b1000001-0003-4000-a000-000000000003', 'a1b2c3d4-0003-4000-a000-000000000003',
 '27th Main, HSR Layout, Bangalore 560102', 12.9116, 77.6389,
 'Electronic City Phase 1, Bangalore 560100', 12.8440, 77.6630, 'cash');

-- ============================================================================
-- 4.4 DRIVER PROFILES
-- ============================================================================

INSERT INTO driver_profiles (id, user_id, license_number, license_expiry, is_available, verification_status, status, current_lat, current_lng, payout_frequency, bank_account_number, bank_ifsc, bank_name) VALUES
('c1000001-0010-4000-a000-000000000010', 'a1b2c3d4-0010-4000-a000-000000000010',
 'KA01-2020-0012345', '2028-12-31', TRUE, 'approved', 'online',
 12.9400, 77.6200, 'weekly', 'XXXX1234', 'SBIN0001234', 'SBI'),
('c1000001-0011-4000-a000-000000000011', 'a1b2c3d4-0011-4000-a000-000000000011',
 'KA02-2021-0067890', '2029-06-30', TRUE, 'approved', 'online',
 12.9750, 77.6400, 'daily', 'XXXX5678', 'HDFC0002345', 'HDFC Bank'),
('c1000001-0012-4000-a000-000000000012', 'a1b2c3d4-0012-4000-a000-000000000012',
 'KA03-2019-0099999', '2027-03-15', FALSE, 'pending', 'offline',
 NULL, NULL, 'weekly', NULL, NULL, NULL);

-- ============================================================================
-- 4.5 VEHICLE TYPES (reference data — 6 types for Bangalore)
-- ============================================================================

INSERT INTO vehicle_types (id, name, display_name, default_seat_capacity) VALUES
('d1000001-0001-4000-a000-000000000001', 'auto',      'Auto Rickshaw',  3),
('d1000001-0002-4000-a000-000000000002', 'hatchback', 'Mini (Hatchback)', 4),
('d1000001-0003-4000-a000-000000000003', 'sedan',     'Sedan',         4),
('d1000001-0004-4000-a000-000000000004', 'suv',       'SUV / XL',      6),
('d1000001-0005-4000-a000-000000000005', 'bike',      'Bike',          1),
('d1000001-0006-4000-a000-000000000006', 'luxury',    'Luxury / Premium', 4);

-- ============================================================================
-- 4.6 VEHICLES (Vikram=Sedan, Suresh=Hatchback, Manoj=Auto pending)
-- ============================================================================

INSERT INTO vehicles (id, driver_id, vehicle_type_id, make, model, year, color, license_plate, seat_capacity, is_current) VALUES
-- Vikram's Sedan (approved driver, current vehicle)
('e1000001-0010-4000-a000-000000000010', 'c1000001-0010-4000-a000-000000000010',
 'd1000001-0003-4000-a000-000000000003', 'Maruti', 'Dzire', 2023, 'White', 'KA01AB1234', 4, TRUE),
-- Suresh's Hatchback (approved driver, current vehicle)
('e1000001-0011-4000-a000-000000000011', 'c1000001-0011-4000-a000-000000000011',
 'd1000001-0002-4000-a000-000000000002', 'Maruti', 'Swift', 2022, 'Red', 'KA02CD5678', 4, TRUE),
-- Manoj's Auto (pending driver)
('e1000001-0012-4000-a000-000000000012', 'c1000001-0012-4000-a000-000000000012',
 'd1000001-0001-4000-a000-000000000001', 'Bajaj', 'RE Compact', 2021, 'Green', 'KA03EF9999', 3, TRUE);

-- ============================================================================
-- 4.7 DRIVER DOCUMENTS (Vikram=all approved, Suresh=approved, Manoj=pending)
-- ============================================================================

INSERT INTO driver_documents (driver_id, doc_type, document_url, status, verified_by, uploaded_at, verified_at) VALUES
-- Vikram (fully approved)
('c1000001-0010-4000-a000-000000000010', 'driving_license',
 'https://r2.rideapp.dev/docs/vikram_dl.pdf', 'approved',
 'a1b2c3d4-0099-4000-a000-000000000099', DATE_SUB(NOW(), INTERVAL 30 DAY), DATE_SUB(NOW(), INTERVAL 29 DAY)),
('c1000001-0010-4000-a000-000000000010', 'vehicle_registration',
 'https://r2.rideapp.dev/docs/vikram_rc.pdf', 'approved',
 'a1b2c3d4-0099-4000-a000-000000000099', DATE_SUB(NOW(), INTERVAL 30 DAY), DATE_SUB(NOW(), INTERVAL 29 DAY)),
('c1000001-0010-4000-a000-000000000010', 'vehicle_insurance',
 'https://r2.rideapp.dev/docs/vikram_ins.pdf', 'approved',
 'a1b2c3d4-0099-4000-a000-000000000099', DATE_SUB(NOW(), INTERVAL 30 DAY), DATE_SUB(NOW(), INTERVAL 29 DAY)),
-- Suresh (approved)
('c1000001-0011-4000-a000-000000000011', 'driving_license',
 'https://r2.rideapp.dev/docs/suresh_dl.pdf', 'approved',
 'a1b2c3d4-0099-4000-a000-000000000099', DATE_SUB(NOW(), INTERVAL 20 DAY), DATE_SUB(NOW(), INTERVAL 19 DAY)),
('c1000001-0011-4000-a000-000000000011', 'vehicle_registration',
 'https://r2.rideapp.dev/docs/suresh_rc.pdf', 'approved',
 'a1b2c3d4-0099-4000-a000-000000000099', DATE_SUB(NOW(), INTERVAL 20 DAY), DATE_SUB(NOW(), INTERVAL 19 DAY)),
-- Manoj (still pending)
('c1000001-0012-4000-a000-000000000012', 'driving_license',
 'https://r2.rideapp.dev/docs/manoj_dl.pdf', 'pending',
 NULL, DATE_SUB(NOW(), INTERVAL 2 DAY), NULL),
('c1000001-0012-4000-a000-000000000012', 'identity_proof',
 'https://r2.rideapp.dev/docs/manoj_aadhaar.pdf', 'pending',
 NULL, DATE_SUB(NOW(), INTERVAL 2 DAY), NULL);

-- ============================================================================
-- 4.8 WALLETS (auto-created for all 7 users)
-- ============================================================================

INSERT INTO wallets (id, user_id, balance) VALUES
('f1000001-0001-4000-a000-000000000001', 'a1b2c3d4-0001-4000-a000-000000000001', 500.00),
('f1000001-0002-4000-a000-000000000002', 'a1b2c3d4-0002-4000-a000-000000000002', 1200.00),
('f1000001-0003-4000-a000-000000000003', 'a1b2c3d4-0003-4000-a000-000000000003', 0.00),
('f1000001-0010-4000-a000-000000000010', 'a1b2c3d4-0010-4000-a000-000000000010', 3500.00),
('f1000001-0011-4000-a000-000000000011', 'a1b2c3d4-0011-4000-a000-000000000011', 2100.00),
('f1000001-0012-4000-a000-000000000012', 'a1b2c3d4-0012-4000-a000-000000000012', 0.00),
('f1000001-0099-4000-a000-000000000099', 'a1b2c3d4-0099-4000-a000-000000000099', 0.00);

-- ============================================================================
-- 4.9 WALLET TRANSACTIONS (history for Aarav & Priya)
-- ============================================================================

INSERT INTO wallet_transactions (wallet_id, amount, type, source, description, balance_after, created_at) VALUES
-- Aarav
('f1000001-0001-4000-a000-000000000001', 1000.00, 'credit', 'top_up', 'Wallet top-up via UPI', 1000.00, DATE_SUB(NOW(), INTERVAL 10 DAY)),
('f1000001-0001-4000-a000-000000000001', 500.00, 'debit', 'ride_payment', 'Ride payment #RD-20260420-ABCD', 500.00, DATE_SUB(NOW(), INTERVAL 5 DAY)),
-- Priya
('f1000001-0002-4000-a000-000000000002', 2000.00, 'credit', 'top_up', 'Wallet top-up via card', 2000.00, DATE_SUB(NOW(), INTERVAL 15 DAY)),
('f1000001-0002-4000-a000-000000000002', 200.00, 'credit', 'cashback', 'First ride cashback', 2200.00, DATE_SUB(NOW(), INTERVAL 14 DAY)),
('f1000001-0002-4000-a000-000000000002', 1000.00, 'debit', 'ride_payment', 'Ride payment', 1200.00, DATE_SUB(NOW(), INTERVAL 7 DAY));

-- ============================================================================
-- 4.10 PAYMENT METHODS (saved cards/UPI for riders)
-- ============================================================================

INSERT INTO payment_methods (id, user_id, method_type, provider, token, last_four, is_default) VALUES
('g1000001-0001-4000-a000-000000000001', 'a1b2c3d4-0001-4000-a000-000000000001',
 'upi', 'gpay', 'rzp_tok_test_aarav_gpay_001', NULL, TRUE),
('g1000001-0002-4000-a000-000000000002', 'a1b2c3d4-0002-4000-a000-000000000002',
 'card', 'visa', 'rzp_tok_test_priya_visa_001', '4242', TRUE),
('g1000001-0002-4000-a000-000000000003', 'a1b2c3d4-0002-4000-a000-000000000002',
 'upi', 'phonepe', 'rzp_tok_test_priya_ppe_001', NULL, FALSE);

-- ============================================================================
-- 4.11 FAVORITE LOCATIONS
-- ============================================================================

INSERT INTO favorite_locations (user_id, label, lat, lng, address) VALUES
('a1b2c3d4-0001-4000-a000-000000000001', 'home', 12.9352, 77.6245, '80 Feet Road, Koramangala, Bangalore 560034'),
('a1b2c3d4-0001-4000-a000-000000000001', 'work', 12.9698, 77.7500, 'ITPL Main Road, Whitefield, Bangalore 560066'),
('a1b2c3d4-0001-4000-a000-000000000001', 'gym', 12.9299, 77.5838, 'Cult Fitness, 4th Block, Jayanagar'),
('a1b2c3d4-0002-4000-a000-000000000002', 'home', 12.9784, 77.6408, '100 Feet Road, Indiranagar, Bangalore 560038'),
('a1b2c3d4-0002-4000-a000-000000000002', 'work', 12.9756, 77.6065, 'WeWork MG Road, Bangalore 560001');

-- ============================================================================
-- 4.12 EMERGENCY CONTACTS
-- ============================================================================

INSERT INTO emergency_contacts (user_id, name, phone, relationship, is_primary, notify_on_ride) VALUES
('a1b2c3d4-0001-4000-a000-000000000001', 'Sunita Sharma', '+919876543250', 'Mother', TRUE, TRUE),
('a1b2c3d4-0001-4000-a000-000000000001', 'Rohit Sharma', '+919876543251', 'Brother', FALSE, FALSE),
('a1b2c3d4-0002-4000-a000-000000000002', 'Amit Patel', '+919876543260', 'Father', TRUE, TRUE),
('a1b2c3d4-0003-4000-a000-000000000003', 'Neha Verma', '+919876543270', 'Wife', TRUE, TRUE);

-- ============================================================================
-- 4.13 SYSTEM CONFIG
-- ============================================================================

INSERT INTO system_configs (config_key, config_value, description, group_name) VALUES
('ride_timeout_seconds', '300', 'Time before unmatched ride request expires', 'ride'),
('max_surge_multiplier', '3.0', 'Maximum allowed surge multiplier', 'ride'),
('platform_commission_pct', '20', 'Default platform commission percentage', 'payment'),
('min_wallet_topup', '100', 'Minimum wallet top-up amount in INR', 'payment'),
('max_wallet_balance', '50000', 'Maximum wallet balance in INR', 'payment'),
('driver_matching_radius_km', '5', 'Search radius for nearby drivers (km)', 'ride'),
('driver_ping_timeout_sec', '15', 'Seconds to wait for driver to accept', 'ride'),
('max_ride_stops', '3', 'Maximum intermediate stops per ride', 'ride'),
('cancellation_fee_rider', '50', 'Default rider cancellation fee in INR', 'ride'),
('cancellation_fee_driver', '100', 'Default driver cancellation fee in INR', 'ride'),
('sos_auto_alert_contacts', 'true', 'Auto-notify emergency contacts on SOS', 'safety'),
('referral_bonus_referrer', '100', 'Referral bonus for referrer in INR', 'general'),
('referral_bonus_referee', '50', 'Referral bonus for new user in INR', 'general'),
('otp_expiry_seconds', '300', 'OTP expiry time', 'general'),
('max_otp_attempts', '5', 'Max OTP verification attempts', 'general'),
('support_auto_assign', 'false', 'Auto-assign tickets to available agents', 'general');

-- ===========================================================================
-- SECTION 5 — INSERT: Seed Data for Phase A (Complete Ride Flow)
-- ===========================================================================

-- ============================================================================
-- 5.1 FARE RULES (Bangalore pricing for each vehicle type)
-- ============================================================================

INSERT INTO fare_rules (id, vehicle_type_id, city, base_fare, per_km_rate, per_min_rate, min_fare, booking_fee, cancellation_fee, waiting_charge_per_min, night_surcharge_pct) VALUES
-- Auto
('h1000001-0001-4000-a000-000000000001', 'd1000001-0001-4000-a000-000000000001',
 'Bangalore', 30, 12, 1.5, 50, 5, 25, 1.0, 10),
-- Hatchback / Mini
('h1000001-0002-4000-a000-000000000002', 'd1000001-0002-4000-a000-000000000002',
 'Bangalore', 50, 14, 2.0, 80, 10, 50, 1.5, 15),
-- Sedan
('h1000001-0003-4000-a000-000000000003', 'd1000001-0003-4000-a000-000000000003',
 'Bangalore', 70, 16, 2.5, 100, 10, 50, 2.0, 15),
-- SUV
('h1000001-0004-4000-a000-000000000004', 'd1000001-0004-4000-a000-000000000004',
 'Bangalore', 100, 20, 3.0, 150, 15, 75, 2.5, 15),
-- Bike
('h1000001-0005-4000-a000-000000000005', 'd1000001-0005-4000-a000-000000000005',
 'Bangalore', 20, 8, 1.0, 30, 0, 15, 0.5, 5),
-- Luxury
('h1000001-0006-4000-a000-000000000006', 'd1000001-0006-4000-a000-000000000006',
 'Bangalore', 150, 25, 4.0, 250, 20, 100, 3.0, 20);

-- ============================================================================
-- 5.2 SURGE ZONES
-- ============================================================================

INSERT INTO surge_zones (id, city, zone_name, surge_multiplier, active_from, active_to, reason) VALUES
('i1000001-0001-4000-a000-000000000001', 'Bangalore', 'Koramangala',
 1.3, NOW(), DATE_ADD(NOW(), INTERVAL 2 HOUR), 'high_demand'),
('i1000001-0002-4000-a000-000000000002', 'Bangalore', 'MG Road / CBD',
 1.5, DATE_ADD(NOW(), INTERVAL 17 HOUR), DATE_ADD(NOW(), INTERVAL 21 HOUR), 'event');

-- ============================================================================
-- 5.3 RENTAL PACKAGES
-- ============================================================================

INSERT INTO rental_packages (vehicle_type_id, name, hours, kms_included, package_fare, extra_km_rate, extra_min_rate, city) VALUES
('d1000001-0003-4000-a000-000000000003', '2hr / 20km', 2, 20, 500, 14, 2, 'Bangalore'),
('d1000001-0003-4000-a000-000000000003', '4hr / 40km', 4, 40, 900, 14, 2, 'Bangalore'),
('d1000001-0003-4000-a000-000000000003', '8hr / 80km', 8, 80, 1600, 14, 2, 'Bangalore'),
('d1000001-0004-4000-a000-000000000004', '4hr / 40km', 4, 40, 1200, 18, 3, 'Bangalore'),
('d1000001-0004-4000-a000-000000000004', '8hr / 80km', 8, 80, 2200, 18, 3, 'Bangalore');

-- ============================================================================
-- 5.4 PROMO CODES
-- ============================================================================

INSERT INTO promo_codes (id, code, description, discount_type, discount_value, max_discount, min_order_amount, max_uses_total, max_uses_per_user, applicable_to, valid_from, valid_to) VALUES
('j1000001-0001-4000-a000-000000000001', 'WELCOME50', 'Welcome 50% off first ride (max ₹100)',
 'percentage', 50, 100, 0, NULL, 1, 'ride', DATE_SUB(NOW(), INTERVAL 30 DAY), DATE_ADD(NOW(), INTERVAL 90 DAY)),
('j1000001-0002-4000-a000-000000000002', 'FLAT30', 'Flat ₹30 off any ride',
 'flat', 30, NULL, 100, 1000, 3, 'ride', DATE_SUB(NOW(), INTERVAL 7 DAY), DATE_ADD(NOW(), INTERVAL 30 DAY)),
('j1000001-0003-4000-a000-000000000003', 'TESTALL100', 'Dev testing: ₹100 off everything',
 'flat', 100, NULL, 0, NULL, 999, 'all', DATE_SUB(NOW(), INTERVAL 1 DAY), DATE_ADD(NOW(), INTERVAL 365 DAY));

-- ============================================================================
-- 5.5 COMPLETE RIDE FLOW — Aarav books a Sedan from Koramangala → Whitefield
-- ============================================================================

INSERT INTO ride_requests (id, rider_id, vehicle_type_id, pickup_lat, pickup_lng, pickup_address, dropoff_lat, dropoff_lng, dropoff_address, ride_type, estimated_fare, estimated_distance_km, estimated_duration_min, surge_multiplier, status) VALUES
('r1000001-0001-4000-a000-000000000001',
 'b1000001-0001-4000-a000-000000000001',
 'd1000001-0003-4000-a000-000000000003',
 12.9352, 77.6245, '80 Feet Road, Koramangala, Bangalore 560034',
 12.9698, 77.7500, 'ITPL Main Road, Whitefield, Bangalore 560066',
 'standard', 378.00, 18.5, 42, 1.3, 'matched');

INSERT INTO rides (id, request_id, driver_id, vehicle_id, ride_number, status, estimated_fare, actual_fare, base_fare, distance_km, per_km_charged, per_min_charged, duration_minutes, surge_multiplier, platform_commission_pct, platform_commission_amt, driver_earning, otp_code, accepted_at, driver_arrived_at, pickup_at, dropoff_at, created_at) VALUES
('s1000001-0001-4000-a000-000000000001',
 'r1000001-0001-4000-a000-000000000001',
 'c1000001-0010-4000-a000-000000000010',
 'e1000001-0010-4000-a000-000000000010',
 'RD-20260501-ABCD', 'completed',
 378.00, 390.50, 70.00, 19.2, 16.0, 2.5, 45, 1.3,
 20.0, 78.10, 312.40, '4829',
 DATE_SUB(NOW(), INTERVAL 2 HOUR),
 DATE_SUB(NOW(), INTERVAL 110 MINUTE),
 DATE_SUB(NOW(), INTERVAL 108 MINUTE),
 DATE_SUB(NOW(), INTERVAL 63 MINUTE),
 DATE_SUB(NOW(), INTERVAL 2 HOUR));

INSERT INTO ride_stops (ride_id, stop_order, lat, lng, address, status, arrived_at, departed_at) VALUES
('s1000001-0001-4000-a000-000000000001', 1, 12.9352, 77.6245,
 '80 Feet Road, Koramangala', 'completed',
 DATE_SUB(NOW(), INTERVAL 110 MINUTE), DATE_SUB(NOW(), INTERVAL 108 MINUTE)),
('s1000001-0001-4000-a000-000000000001', 2, 12.9698, 77.7500,
 'ITPL Main Road, Whitefield', 'completed',
 DATE_SUB(NOW(), INTERVAL 63 MINUTE), DATE_SUB(NOW(), INTERVAL 63 MINUTE));

INSERT INTO ride_riders (ride_id, rider_id, pickup_lat, pickup_lng, pickup_address, dropoff_lat, dropoff_lng, dropoff_address, fare_share, status) VALUES
('s1000001-0001-4000-a000-000000000001',
 'b1000001-0001-4000-a000-000000000001',
 12.9352, 77.6245, '80 Feet Road, Koramangala',
 12.9698, 77.7500, 'ITPL Main Road, Whitefield',
 390.50, 'dropped_off');

INSERT INTO ride_routes (ride_id, polyline_encoded, distance_km, estimated_duration_min, is_actual) VALUES
('s1000001-0001-4000-a000-000000000001',
 'mfnmAxqjsM...encoded_estimated...', 18.5, 42, FALSE),
('s1000001-0001-4000-a000-000000000001',
 'mfnmAxqjsM...encoded_actual...', 19.2, 45, TRUE);

INSERT INTO ride_location_logs (ride_id, driver_id, lat, lng, speed, bearing, recorded_at) VALUES
('s1000001-0001-4000-a000-000000000001', 'c1000001-0010-4000-a000-000000000010',
 12.9352, 77.6245, 0, 90, DATE_SUB(NOW(), INTERVAL 108 MINUTE)),
('s1000001-0001-4000-a000-000000000001', 'c1000001-0010-4000-a000-000000000010',
 12.9400, 77.6350, 35.5, 85, DATE_SUB(NOW(), INTERVAL 100 MINUTE)),
('s1000001-0001-4000-a000-000000000001', 'c1000001-0010-4000-a000-000000000010',
 12.9500, 77.6600, 42.0, 80, DATE_SUB(NOW(), INTERVAL 90 MINUTE)),
('s1000001-0001-4000-a000-000000000001', 'c1000001-0010-4000-a000-000000000010',
 12.9600, 77.7000, 48.0, 78, DATE_SUB(NOW(), INTERVAL 75 MINUTE)),
('s1000001-0001-4000-a000-000000000001', 'c1000001-0010-4000-a000-000000000010',
 12.9698, 77.7500, 0, 0, DATE_SUB(NOW(), INTERVAL 63 MINUTE));

-- ============================================================================
-- 5.6 PAYMENT for the ride
-- ============================================================================

INSERT INTO payments (id, user_id, ride_id, payment_number, amount, discount, tax, final_amount, method, payment_method_id, status, gateway_order_id, gateway_payment_id, paid_at) VALUES
('k1000001-0001-4000-a000-000000000001',
 'a1b2c3d4-0001-4000-a000-000000000001',
 's1000001-0001-4000-a000-000000000001',
 'PAY-20260501-0001', 390.50, 0, 0, 390.50, 'upi',
 'g1000001-0001-4000-a000-000000000001',
 'completed',
 'order_RzpTest0001', 'pay_RzpTest0001',
 DATE_SUB(NOW(), INTERVAL 62 MINUTE));

-- ============================================================================
-- 5.7 DRIVER EARNING
-- ============================================================================

INSERT INTO driver_earnings (driver_id, ride_id, gross_amount, commission_deducted, net_earning, earned_at) VALUES
('c1000001-0010-4000-a000-000000000010',
 's1000001-0001-4000-a000-000000000001',
 390.50, 78.10, 312.40, DATE_SUB(NOW(), INTERVAL 62 MINUTE));

-- Continue with remaining inserts in same pattern...
-- Due to length limits, I'm showing the pattern. The rest follows similarly.

-- ============================================================================
-- 5.8 PROMO USAGE (Priya's ride with WELCOME50)
-- ============================================================================

INSERT INTO ride_requests (id, rider_id, vehicle_type_id, pickup_lat, pickup_lng, pickup_address, dropoff_lat, dropoff_lng, dropoff_address, ride_type, estimated_fare, estimated_distance_km, estimated_duration_min, status) VALUES
('r1000001-0002-4000-a000-000000000002',
 'b1000001-0002-4000-a000-000000000002',
 'd1000001-0002-4000-a000-000000000002',
 12.9784, 77.6408, '100 Feet Road, Indiranagar',
 12.9756, 77.6065, 'MG Road, Bangalore',
 'standard', 120.00, 4.2, 18, 'matched');

INSERT INTO rides (id, request_id, driver_id, vehicle_id, ride_number, status, estimated_fare, actual_fare, base_fare, distance_km, per_km_charged, per_min_charged, duration_minutes, platform_commission_pct, platform_commission_amt, driver_earning, otp_code, accepted_at, driver_arrived_at, pickup_at, dropoff_at, created_at) VALUES
('s1000001-0002-4000-a000-000000000002',
 'r1000001-0002-4000-a000-000000000002',
 'c1000001-0011-4000-a000-000000000011',
 'e1000001-0011-4000-a000-000000000011',
 'RD-20260501-EFGH', 'completed',
 120.00, 115.00, 50.00, 4.0, 14.0, 2.0, 16, 20.0, 23.00, 92.00, '7713',
 DATE_SUB(NOW(), INTERVAL 4 HOUR),
 DATE_SUB(NOW(), INTERVAL 232 MINUTE),
 DATE_SUB(NOW(), INTERVAL 230 MINUTE),
 DATE_SUB(NOW(), INTERVAL 214 MINUTE),
 DATE_SUB(NOW(), INTERVAL 4 HOUR));

INSERT INTO ride_stops (ride_id, stop_order, lat, lng, address, status, arrived_at, departed_at) VALUES
('s1000001-0002-4000-a000-000000000002', 1, 12.9784, 77.6408,
 '100 Feet Road, Indiranagar', 'completed',
 DATE_SUB(NOW(), INTERVAL 232 MINUTE), DATE_SUB(NOW(), INTERVAL 230 MINUTE)),
('s1000001-0002-4000-a000-000000000002', 2, 12.9756, 77.6065,
 'MG Road, Bangalore', 'completed',
 DATE_SUB(NOW(), INTERVAL 214 MINUTE), DATE_SUB(NOW(), INTERVAL 214 MINUTE));

INSERT INTO ride_riders (ride_id, rider_id, pickup_lat, pickup_lng, pickup_address, dropoff_lat, dropoff_lng, dropoff_address, fare_share, status) VALUES
('s1000001-0002-4000-a000-000000000002',
 'b1000001-0002-4000-a000-000000000002',
 12.9784, 77.6408, '100 Feet Road, Indiranagar',
 12.9756, 77.6065, 'MG Road, Bangalore',
 115.00, 'dropped_off');

INSERT INTO ride_routes (ride_id, polyline_encoded, distance_km, estimated_duration_min, is_actual) VALUES
('s1000001-0002-4000-a000-000000000002',
 'indiranagar_to_mg_estimated...', 4.2, 18, FALSE),
('s1000001-0002-4000-a000-000000000002',
 'indiranagar_to_mg_actual...', 4.0, 16, TRUE);

INSERT INTO promo_usages (promo_id, user_id, ride_id, discount_applied) VALUES
('j1000001-0001-4000-a000-000000000001',
 'a1b2c3d4-0002-4000-a000-000000000002',
 's1000001-0002-4000-a000-000000000002',
 57.50);

INSERT INTO payments (user_id, ride_id, payment_number, amount, discount, tax, final_amount, method, payment_method_id, status, gateway_order_id, gateway_payment_id, paid_at) VALUES
('a1b2c3d4-0002-4000-a000-000000000002',
 's1000001-0002-4000-a000-000000000002',
 'PAY-20260501-0002', 115.00, 57.50, 0, 57.50, 'card',
 'g1000001-0002-4000-a000-000000000002',
 'completed', 'order_RzpTest0002', 'pay_RzpTest0002',
 DATE_SUB(NOW(), INTERVAL 213 MINUTE));

INSERT INTO driver_earnings (driver_id, ride_id, gross_amount, commission_deducted, net_earning, earned_at) VALUES
('c1000001-0011-4000-a000-000000000011',
 's1000001-0002-4000-a000-000000000002',
 115.00, 23.00, 92.00, DATE_SUB(NOW(), INTERVAL 213 MINUTE));

-- ============================================================================
-- 5.9 RATINGS
-- ============================================================================

INSERT INTO rating_tags (id, tag_name, applicable_to) VALUES
('t1000001-0001-4000-a000-000000000001', 'clean_car', 'rider_to_driver'),
('t1000001-0002-4000-a000-000000000002', 'polite', 'rider_to_driver'),
('t1000001-0003-4000-a000-000000000003', 'skilled_driver', 'rider_to_driver'),
('t1000001-0004-4000-a000-000000000004', 'fast_pickup', 'rider_to_driver'),
('t1000001-0005-4000-a000-000000000005', 'rash_driving', 'rider_to_driver'),
('t1000001-0006-4000-a000-000000000006', 'bad_route', 'rider_to_driver'),
('t1000001-0007-4000-a000-000000000007', 'polite_rider', 'driver_to_rider'),
('t1000001-0008-4000-a000-000000000008', 'messy_rider', 'driver_to_rider'),
('t1000001-0009-4000-a000-000000000009', 'late_pickup', 'driver_to_rider');

INSERT INTO ratings (id, ride_id, from_user_id, to_user_id, score, review_text) VALUES
('u1000001-0001-4000-a000-000000000001',
 's1000001-0001-4000-a000-000000000001',
 'a1b2c3d4-0001-4000-a000-000000000001',
 'a1b2c3d4-0010-4000-a000-000000000010',
 5, 'Excellent ride! Very smooth driving.');

INSERT INTO rating_tag_maps (rating_id, tag_id) VALUES
('u1000001-0001-4000-a000-000000000001', 't1000001-0001-4000-a000-000000000001'),
('u1000001-0001-4000-a000-000000000001', 't1000001-0002-4000-a000-000000000002');

INSERT INTO ratings (id, ride_id, from_user_id, to_user_id, score, review_text) VALUES
('u1000001-0002-4000-a000-000000000002',
 's1000001-0001-4000-a000-000000000001',
 'a1b2c3d4-0010-4000-a000-000000000010',
 'a1b2c3d4-0001-4000-a000-000000000001',
 4, NULL);

INSERT INTO rating_tag_maps (rating_id, tag_id) VALUES
('u1000001-0002-4000-a000-000000000002', 't1000001-0007-4000-a000-000000000007');

INSERT INTO ratings (id, ride_id, from_user_id, to_user_id, score) VALUES
('u1000001-0003-4000-a000-000000000003',
 's1000001-0002-4000-a000-000000000002',
 'a1b2c3d4-0002-4000-a000-000000000002',
 'a1b2c3d4-0011-4000-a000-000000000011',
 4);

UPDATE users SET avg_rating = 5.0 WHERE id = 'a1b2c3d4-0010-4000-a000-000000000010';
UPDATE users SET avg_rating = 4.0 WHERE id = 'a1b2c3d4-0011-4000-a000-000000000011';
UPDATE users SET avg_rating = 4.0 WHERE id = 'a1b2c3d4-0001-4000-a000-000000000001';

-- ============================================================================
-- 5.10 SUPPORT
-- ============================================================================

INSERT INTO support_categories (id, name, description, sort_order) VALUES
('v1000001-0001-4000-a000-000000000001', 'fare_dispute', 'Issues with ride fare, toll charges, surge pricing', 1),
('v1000001-0002-4000-a000-000000000002', 'safety', 'Safety concerns, SOS follow-up', 2),
('v1000001-0003-4000-a000-000000000003', 'lost_item', 'Items left in vehicle', 3),
('v1000001-0004-4000-a000-000000000004', 'driver_behavior', 'Rude behavior, rash driving', 4),
('v1000001-0005-4000-a000-000000000005', 'payment_issue', 'Failed payment, refund request', 5),
('v1000001-0006-4000-a000-000000000006', 'app_issue', 'App crashes, bugs, feature requests', 6);

INSERT INTO support_tickets (id, user_id, category_id, ride_id, ticket_number, subject, description, priority, status) VALUES
('w1000001-0001-4000-a000-000000000001',
 'a1b2c3d4-0001-4000-a000-000000000001',
 'v1000001-0001-4000-a000-000000000001',
 's1000001-0001-4000-a000-000000000001',
 'TKT-20260501-0001',
 'Toll charges not reflected correctly',
 'I was charged ₹390.50 but the toll of ₹35 on Outer Ring Road was not added. Please check.',
 'medium', 'open');

INSERT INTO support_messages (ticket_id, sender_id, content) VALUES
('w1000001-0001-4000-a000-000000000001',
 'a1b2c3d4-0001-4000-a000-000000000001',
 'Hi, I noticed the toll at ORR junction was not included in my fare. Can you please check?'),
('w1000001-0001-4000-a000-000000000001',
 'a1b2c3d4-0099-4000-a000-000000000099',
 'Hi Aarav, we are looking into this. Toll charges will be adjusted within 24 hours. Thank you for your patience.');

-- ============================================================================
-- 5.11 CANCELLED RIDE
-- ============================================================================

INSERT INTO ride_requests (id, rider_id, vehicle_type_id, pickup_lat, pickup_lng, pickup_address, dropoff_lat, dropoff_lng, dropoff_address, ride_type, estimated_fare, estimated_distance_km, estimated_duration_min, status) VALUES
('r1000001-0003-4000-a000-000000000003',
 'b1000001-0003-4000-a000-000000000003',
 'd1000001-0001-4000-a000-000000000001',
 12.9116, 77.6389, '27th Main, HSR Layout',
 12.8440, 77.6630, 'Electronic City Phase 1',
 'standard', 145.00, 9.5, 28, 'cancelled');

-- ============================================================================
-- 5.12 ACTIVE RIDE
-- ============================================================================

INSERT INTO ride_requests (id, rider_id, vehicle_type_id, pickup_lat, pickup_lng, pickup_address, dropoff_lat, dropoff_lng, dropoff_address, ride_type, estimated_fare, estimated_distance_km, estimated_duration_min, status) VALUES
('r1000001-0004-4000-a000-000000000004',
 'b1000001-0002-4000-a000-000000000002',
 'd1000001-0003-4000-a000-000000000003',
 12.9784, 77.6408, '100 Feet Road, Indiranagar',
 13.1989, 77.7068, 'Kempegowda International Airport',
 'standard', 850.00, 38.0, 65, 'matched');

INSERT INTO rides (id, request_id, driver_id, vehicle_id, ride_number, status, estimated_fare, base_fare, per_km_charged, per_min_charged, surge_multiplier, platform_commission_pct, otp_code, accepted_at, driver_arrived_at, pickup_at, created_at) VALUES
('s1000001-0003-4000-a000-000000000003',
 'r1000001-0004-4000-a000-000000000004',
 'c1000001-0010-4000-a000-000000000010',
 'e1000001-0010-4000-a000-000000000010',
 'RD-20260501-IJKL', 'in_progress',
 850.00, 70.00, 16.0, 2.5, 1.0, 20.0, '3156',
 DATE_SUB(NOW(), INTERVAL 20 MINUTE),
 DATE_SUB(NOW(), INTERVAL 12 MINUTE),
 DATE_SUB(NOW(), INTERVAL 10 MINUTE),
 DATE_SUB(NOW(), INTERVAL 20 MINUTE));

INSERT INTO ride_stops (ride_id, stop_order, lat, lng, address, status) VALUES
('s1000001-0003-4000-a000-000000000003', 1, 12.9784, 77.6408, '100 Feet Road, Indiranagar', 'completed'),
('s1000001-0003-4000-a000-000000000003', 2, 13.1989, 77.7068, 'Kempegowda International Airport', 'pending');

INSERT INTO ride_riders (ride_id, rider_id, pickup_lat, pickup_lng, pickup_address, dropoff_lat, dropoff_lng, dropoff_address, fare_share, status) VALUES
('s1000001-0003-4000-a000-000000000003',
 'b1000001-0002-4000-a000-000000000002',
 12.9784, 77.6408, '100 Feet Road, Indiranagar',
 13.1989, 77.7068, 'Kempegowda International Airport',
 850.00, 'picked_up');

INSERT INTO live_location_shares (ride_id, rider_id, emergency_contact_id, share_token, expires_at) VALUES
('s1000001-0003-4000-a000-000000000003',
 'a1b2c3d4-0002-4000-a000-000000000002',
 (SELECT id FROM emergency_contacts WHERE user_id = 'a1b2c3d4-0002-4000-a000-000000000002' LIMIT 1),
 'trk_priya_airport_20260501',
 DATE_ADD(NOW(), INTERVAL 2 HOUR));

-- ============================================================================
-- 5.13 POST-SEED: Update Vikram's status
-- ============================================================================

UPDATE driver_profiles
SET status = 'on_ride', is_available = FALSE
WHERE id = 'c1000001-0010-4000-a000-000000000010';

-- ===========================================================================
-- SECTION 9 — Quick Verification Queries
-- ===========================================================================

-- Total users by role
SELECT role, COUNT(*) FROM users GROUP BY role;

-- Active rides
SELECT r.ride_number, r.status, 
       u_rider.first_name AS rider, 
       u_driver.first_name AS driver
FROM rides r
JOIN ride_requests rr ON r.request_id = rr.id
JOIN rider_profiles rp ON rr.rider_id = rp.id
JOIN users u_rider ON rp.user_id = u_rider.id
JOIN driver_profiles dp ON r.driver_id = dp.id
JOIN users u_driver ON dp.user_id = u_driver.id
WHERE r.status IN ('accepted', 'driver_arriving', 'arrived', 'in_progress');

-- Driver earnings summary
SELECT u.first_name, SUM(de.net_earning) AS total_earned, COUNT(*) AS rides
FROM driver_earnings de
JOIN driver_profiles dp ON de.driver_id = dp.id
JOIN users u ON dp.user_id = u.id
GROUP BY u.first_name;

-- Wallet balances
SELECT u.first_name, u.role, w.balance
FROM wallets w 
JOIN users u ON w.user_id = u.id
ORDER BY w.balance DESC;

-- Pending driver approvals
SELECT u.first_name, dp.verification_status, COUNT(dd.id) AS docs_uploaded
FROM driver_profiles dp
JOIN users u ON dp.user_id = u.id
LEFT JOIN driver_documents dd ON dp.id = dd.driver_id
WHERE dp.verification_status != 'approved'
GROUP BY u.first_name, dp.verification_status;