-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 01, 2026 at 10:22 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rideapp_dev`
--

-- --------------------------------------------------------

--
-- Table structure for table `driver_documents`
--

CREATE TABLE `driver_documents` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `driver_id` char(36) NOT NULL,
  `doc_type` enum('driving_license','vehicle_insurance','vehicle_registration','background_check','identity_proof','address_proof','vehicle_photo') NOT NULL,
  `document_url` text NOT NULL,
  `status` enum('pending','under_review','approved','rejected','expired') NOT NULL DEFAULT 'pending',
  `rejection_reason` text DEFAULT NULL,
  `verified_by` char(36) DEFAULT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `verified_at` timestamp NULL DEFAULT NULL,
  `expiry_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `driver_documents`
--

INSERT INTO `driver_documents` (`id`, `driver_id`, `doc_type`, `document_url`, `status`, `rejection_reason`, `verified_by`, `uploaded_at`, `verified_at`, `expiry_date`) VALUES
('5955d11a-459b-11f1-9547-e09d31f6397e', 'c1000001-0010-4000-a000-000000000010', 'driving_license', 'https://r2.rideapp.dev/docs/vikram_dl.pdf', 'approved', NULL, 'a1b2c3d4-0099-4000-a000-000000000099', '2026-04-01 20:21:34', '2026-04-02 20:21:34', NULL),
('595603c6-459b-11f1-9547-e09d31f6397e', 'c1000001-0010-4000-a000-000000000010', 'vehicle_registration', 'https://r2.rideapp.dev/docs/vikram_rc.pdf', 'approved', NULL, 'a1b2c3d4-0099-4000-a000-000000000099', '2026-04-01 20:21:34', '2026-04-02 20:21:34', NULL),
('59560522-459b-11f1-9547-e09d31f6397e', 'c1000001-0010-4000-a000-000000000010', 'vehicle_insurance', 'https://r2.rideapp.dev/docs/vikram_ins.pdf', 'approved', NULL, 'a1b2c3d4-0099-4000-a000-000000000099', '2026-04-01 20:21:34', '2026-04-02 20:21:34', NULL),
('595606a8-459b-11f1-9547-e09d31f6397e', 'c1000001-0011-4000-a000-000000000011', 'driving_license', 'https://r2.rideapp.dev/docs/suresh_dl.pdf', 'approved', NULL, 'a1b2c3d4-0099-4000-a000-000000000099', '2026-04-11 20:21:34', '2026-04-12 20:21:34', NULL),
('5956084b-459b-11f1-9547-e09d31f6397e', 'c1000001-0011-4000-a000-000000000011', 'vehicle_registration', 'https://r2.rideapp.dev/docs/suresh_rc.pdf', 'approved', NULL, 'a1b2c3d4-0099-4000-a000-000000000099', '2026-04-11 20:21:34', '2026-04-12 20:21:34', NULL),
('5956092a-459b-11f1-9547-e09d31f6397e', 'c1000001-0012-4000-a000-000000000012', 'driving_license', 'https://r2.rideapp.dev/docs/manoj_dl.pdf', 'pending', NULL, NULL, '2026-04-29 20:21:34', NULL, NULL),
('595609b9-459b-11f1-9547-e09d31f6397e', 'c1000001-0012-4000-a000-000000000012', 'identity_proof', 'https://r2.rideapp.dev/docs/manoj_aadhaar.pdf', 'pending', NULL, NULL, '2026-04-29 20:21:34', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `driver_earnings`
--

CREATE TABLE `driver_earnings` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `driver_id` char(36) NOT NULL,
  `ride_id` char(36) DEFAULT NULL,
  `order_id` char(36) DEFAULT NULL,
  `parcel_id` char(36) DEFAULT NULL,
  `gross_amount` decimal(12,2) NOT NULL,
  `commission_deducted` decimal(12,2) NOT NULL,
  `incentive_bonus` decimal(12,2) NOT NULL DEFAULT 0.00,
  `tip` decimal(12,2) NOT NULL DEFAULT 0.00,
  `net_earning` decimal(12,2) NOT NULL,
  `status` enum('pending','paid') NOT NULL DEFAULT 'pending',
  `earned_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `paid_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `driver_earnings`
--

INSERT INTO `driver_earnings` (`id`, `driver_id`, `ride_id`, `order_id`, `parcel_id`, `gross_amount`, `commission_deducted`, `incentive_bonus`, `tip`, `net_earning`, `status`, `earned_at`, `paid_at`) VALUES
('597b5596-459b-11f1-9547-e09d31f6397e', 'c1000001-0010-4000-a000-000000000010', 's1000001-0001-4000-a000-000000000001', NULL, NULL, 390.50, 78.10, 0.00, 0.00, 312.40, 'pending', '2026-05-01 19:19:34', NULL),
('59884cd9-459b-11f1-9547-e09d31f6397e', 'c1000001-0011-4000-a000-000000000011', 's1000001-0002-4000-a000-000000000002', NULL, NULL, 115.00, 23.00, 0.00, 0.00, 92.00, 'pending', '2026-05-01 16:48:34', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `driver_payouts`
--

CREATE TABLE `driver_payouts` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `driver_id` char(36) NOT NULL,
  `amount` decimal(12,2) NOT NULL CHECK (`amount` > 0),
  `status` enum('pending','processing','completed','failed') NOT NULL DEFAULT 'pending',
  `frequency` enum('daily','weekly') NOT NULL,
  `period_start` date NOT NULL,
  `period_end` date NOT NULL,
  `bank_reference` text DEFAULT NULL,
  `processed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `driver_profiles`
--

CREATE TABLE `driver_profiles` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `user_id` char(36) NOT NULL,
  `license_number` varchar(50) NOT NULL,
  `license_expiry` date NOT NULL,
  `is_available` tinyint(1) NOT NULL DEFAULT 0,
  `verification_status` enum('pending','documents_submitted','under_review','approved','rejected','suspended') NOT NULL DEFAULT 'pending',
  `current_lat` float DEFAULT NULL,
  `current_lng` float DEFAULT NULL,
  `status` enum('online','offline','on_ride','on_delivery') NOT NULL DEFAULT 'offline',
  `payout_frequency` enum('daily','weekly') NOT NULL DEFAULT 'weekly',
  `bank_account_number` text DEFAULT NULL,
  `bank_ifsc` varchar(20) DEFAULT NULL,
  `bank_name` varchar(100) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `last_location_update` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `driver_profiles`
--

INSERT INTO `driver_profiles` (`id`, `user_id`, `license_number`, `license_expiry`, `is_available`, `verification_status`, `current_lat`, `current_lng`, `status`, `payout_frequency`, `bank_account_number`, `bank_ifsc`, `bank_name`, `is_active`, `last_location_update`, `created_at`, `updated_at`) VALUES
('c1000001-0010-4000-a000-000000000010', 'a1b2c3d4-0010-4000-a000-000000000010', 'KA01-2020-0012345', '2028-12-31', 0, 'approved', 12.94, 77.62, 'on_ride', 'weekly', 'XXXX1234', 'SBIN0001234', 'SBI', 1, NULL, '2026-05-01 20:21:34', '2026-05-01 20:21:35'),
('c1000001-0011-4000-a000-000000000011', 'a1b2c3d4-0011-4000-a000-000000000011', 'KA02-2021-0067890', '2029-06-30', 1, 'approved', 12.975, 77.64, 'online', 'daily', 'XXXX5678', 'HDFC0002345', 'HDFC Bank', 1, NULL, '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('c1000001-0012-4000-a000-000000000012', 'a1b2c3d4-0012-4000-a000-000000000012', 'KA03-2019-0099999', '2027-03-15', 0, 'pending', NULL, NULL, 'offline', 'weekly', NULL, NULL, NULL, 1, NULL, '2026-05-01 20:21:34', '2026-05-01 20:21:34');

-- --------------------------------------------------------

--
-- Table structure for table `emergency_contacts`
--

CREATE TABLE `emergency_contacts` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `user_id` char(36) NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `relationship` varchar(50) DEFAULT NULL,
  `is_primary` tinyint(1) NOT NULL DEFAULT 0,
  `notify_on_ride` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `emergency_contacts`
--

INSERT INTO `emergency_contacts` (`id`, `user_id`, `name`, `phone`, `relationship`, `is_primary`, `notify_on_ride`, `created_at`) VALUES
('595f2913-459b-11f1-9547-e09d31f6397e', 'a1b2c3d4-0001-4000-a000-000000000001', 'Sunita Sharma', '+919876543250', 'Mother', 1, 1, '2026-05-01 20:21:34'),
('595f4fd4-459b-11f1-9547-e09d31f6397e', 'a1b2c3d4-0001-4000-a000-000000000001', 'Rohit Sharma', '+919876543251', 'Brother', 0, 0, '2026-05-01 20:21:34'),
('595f50da-459b-11f1-9547-e09d31f6397e', 'a1b2c3d4-0002-4000-a000-000000000002', 'Amit Patel', '+919876543260', 'Father', 1, 1, '2026-05-01 20:21:34'),
('595f5152-459b-11f1-9547-e09d31f6397e', 'a1b2c3d4-0003-4000-a000-000000000003', 'Neha Verma', '+919876543270', 'Wife', 1, 1, '2026-05-01 20:21:34');

-- --------------------------------------------------------

--
-- Table structure for table `fare_rules`
--

CREATE TABLE `fare_rules` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `vehicle_type_id` char(36) NOT NULL,
  `city` varchar(100) NOT NULL,
  `zone` varchar(100) DEFAULT NULL,
  `base_fare` float NOT NULL CHECK (`base_fare` >= 0),
  `per_km_rate` float NOT NULL CHECK (`per_km_rate` >= 0),
  `per_min_rate` float NOT NULL CHECK (`per_min_rate` >= 0),
  `min_fare` float NOT NULL CHECK (`min_fare` >= 0),
  `booking_fee` float NOT NULL DEFAULT 0,
  `cancellation_fee` float NOT NULL CHECK (`cancellation_fee` >= 0),
  `waiting_charge_per_min` float NOT NULL DEFAULT 0,
  `night_surcharge_pct` float NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `effective_from` timestamp NOT NULL DEFAULT current_timestamp(),
  `effective_to` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `fare_rules`
--

INSERT INTO `fare_rules` (`id`, `vehicle_type_id`, `city`, `zone`, `base_fare`, `per_km_rate`, `per_min_rate`, `min_fare`, `booking_fee`, `cancellation_fee`, `waiting_charge_per_min`, `night_surcharge_pct`, `is_active`, `effective_from`, `effective_to`) VALUES
('h1000001-0001-4000-a000-000000000001', 'd1000001-0001-4000-a000-000000000001', 'Bangalore', NULL, 30, 12, 1.5, 50, 5, 25, 1, 10, 1, '2026-05-01 20:21:34', NULL),
('h1000001-0002-4000-a000-000000000002', 'd1000001-0002-4000-a000-000000000002', 'Bangalore', NULL, 50, 14, 2, 80, 10, 50, 1.5, 15, 1, '2026-05-01 20:21:34', NULL),
('h1000001-0003-4000-a000-000000000003', 'd1000001-0003-4000-a000-000000000003', 'Bangalore', NULL, 70, 16, 2.5, 100, 10, 50, 2, 15, 1, '2026-05-01 20:21:34', NULL),
('h1000001-0004-4000-a000-000000000004', 'd1000001-0004-4000-a000-000000000004', 'Bangalore', NULL, 100, 20, 3, 150, 15, 75, 2.5, 15, 1, '2026-05-01 20:21:34', NULL),
('h1000001-0005-4000-a000-000000000005', 'd1000001-0005-4000-a000-000000000005', 'Bangalore', NULL, 20, 8, 1, 30, 0, 15, 0.5, 5, 1, '2026-05-01 20:21:34', NULL),
('h1000001-0006-4000-a000-000000000006', 'd1000001-0006-4000-a000-000000000006', 'Bangalore', NULL, 150, 25, 4, 250, 20, 100, 3, 20, 1, '2026-05-01 20:21:34', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `favorite_locations`
--

CREATE TABLE `favorite_locations` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `user_id` char(36) NOT NULL,
  `label` varchar(50) NOT NULL,
  `lat` float NOT NULL,
  `lng` float NOT NULL,
  `address` text NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `favorite_locations`
--

INSERT INTO `favorite_locations` (`id`, `user_id`, `label`, `lat`, `lng`, `address`, `sort_order`, `created_at`) VALUES
('595d8823-459b-11f1-9547-e09d31f6397e', 'a1b2c3d4-0001-4000-a000-000000000001', 'home', 12.9352, 77.6245, '80 Feet Road, Koramangala, Bangalore 560034', 0, '2026-05-01 20:21:34'),
('595db01c-459b-11f1-9547-e09d31f6397e', 'a1b2c3d4-0001-4000-a000-000000000001', 'work', 12.9698, 77.75, 'ITPL Main Road, Whitefield, Bangalore 560066', 0, '2026-05-01 20:21:34'),
('595db173-459b-11f1-9547-e09d31f6397e', 'a1b2c3d4-0001-4000-a000-000000000001', 'gym', 12.9299, 77.5838, 'Cult Fitness, 4th Block, Jayanagar', 0, '2026-05-01 20:21:34'),
('595db231-459b-11f1-9547-e09d31f6397e', 'a1b2c3d4-0002-4000-a000-000000000002', 'home', 12.9784, 77.6408, '100 Feet Road, Indiranagar, Bangalore 560038', 0, '2026-05-01 20:21:34'),
('595db2d8-459b-11f1-9547-e09d31f6397e', 'a1b2c3d4-0002-4000-a000-000000000002', 'work', 12.9756, 77.6065, 'WeWork MG Road, Bangalore 560001', 0, '2026-05-01 20:21:34');

-- --------------------------------------------------------

--
-- Table structure for table `live_location_shares`
--

CREATE TABLE `live_location_shares` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `ride_id` char(36) NOT NULL,
  `rider_id` char(36) NOT NULL,
  `emergency_contact_id` char(36) NOT NULL,
  `share_token` text NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `shared_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `live_location_shares`
--

INSERT INTO `live_location_shares` (`id`, `ride_id`, `rider_id`, `emergency_contact_id`, `share_token`, `is_active`, `shared_at`, `expires_at`) VALUES
('59a0a2e4-459b-11f1-9547-e09d31f6397e', 's1000001-0003-4000-a000-000000000003', 'a1b2c3d4-0002-4000-a000-000000000002', '595f50da-459b-11f1-9547-e09d31f6397e', 'trk_priya_airport_20260501', 1, '2026-05-01 20:21:35', '2026-05-01 22:21:35');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `user_id` char(36) NOT NULL,
  `ride_id` char(36) DEFAULT NULL,
  `order_id` char(36) DEFAULT NULL,
  `parcel_id` char(36) DEFAULT NULL,
  `payment_number` varchar(30) NOT NULL,
  `amount` decimal(12,2) NOT NULL CHECK (`amount` > 0),
  `discount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `tax` decimal(12,2) NOT NULL DEFAULT 0.00,
  `final_amount` decimal(12,2) NOT NULL CHECK (`final_amount` >= 0),
  `method` enum('card','wallet','cash','upi','net_banking') NOT NULL,
  `payment_method_id` char(36) DEFAULT NULL,
  `status` enum('pending','processing','completed','failed','refunded','partially_refunded') NOT NULL DEFAULT 'pending',
  `gateway_order_id` text DEFAULT NULL,
  `gateway_payment_id` text DEFAULT NULL,
  `gateway_signature` text DEFAULT NULL,
  `paid_at` timestamp NULL DEFAULT NULL,
  `refunded_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `user_id`, `ride_id`, `order_id`, `parcel_id`, `payment_number`, `amount`, `discount`, `tax`, `final_amount`, `method`, `payment_method_id`, `status`, `gateway_order_id`, `gateway_payment_id`, `gateway_signature`, `paid_at`, `refunded_at`, `created_at`) VALUES
('5986e305-459b-11f1-9547-e09d31f6397e', 'a1b2c3d4-0002-4000-a000-000000000002', 's1000001-0002-4000-a000-000000000002', NULL, NULL, 'PAY-20260501-0002', 115.00, 57.50, 0.00, 57.50, 'card', 'g1000001-0002-4000-a000-000000000002', 'completed', 'order_RzpTest0002', 'pay_RzpTest0002', NULL, '2026-05-01 16:48:34', NULL, '2026-05-01 20:21:34'),
('k1000001-0001-4000-a000-000000000001', 'a1b2c3d4-0001-4000-a000-000000000001', 's1000001-0001-4000-a000-000000000001', NULL, NULL, 'PAY-20260501-0001', 390.50, 0.00, 0.00, 390.50, 'upi', 'g1000001-0001-4000-a000-000000000001', 'completed', 'order_RzpTest0001', 'pay_RzpTest0001', NULL, '2026-05-01 19:19:34', NULL, '2026-05-01 20:21:34');

-- --------------------------------------------------------

--
-- Table structure for table `payment_methods`
--

CREATE TABLE `payment_methods` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `user_id` char(36) NOT NULL,
  `method_type` enum('card','upi','net_banking') NOT NULL,
  `provider` varchar(50) NOT NULL,
  `token` text NOT NULL,
  `last_four` varchar(4) DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payment_methods`
--

INSERT INTO `payment_methods` (`id`, `user_id`, `method_type`, `provider`, `token`, `last_four`, `is_default`, `is_active`, `created_at`) VALUES
('g1000001-0001-4000-a000-000000000001', 'a1b2c3d4-0001-4000-a000-000000000001', 'upi', 'gpay', 'rzp_tok_test_aarav_gpay_001', NULL, 1, 1, '2026-05-01 20:21:34'),
('g1000001-0002-4000-a000-000000000002', 'a1b2c3d4-0002-4000-a000-000000000002', 'card', 'visa', 'rzp_tok_test_priya_visa_001', '4242', 1, 1, '2026-05-01 20:21:34'),
('g1000001-0002-4000-a000-000000000003', 'a1b2c3d4-0002-4000-a000-000000000002', 'upi', 'phonepe', 'rzp_tok_test_priya_ppe_001', NULL, 0, 1, '2026-05-01 20:21:34');

-- --------------------------------------------------------

--
-- Table structure for table `promo_codes`
--

CREATE TABLE `promo_codes` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `code` varchar(30) NOT NULL,
  `description` text DEFAULT NULL,
  `discount_type` enum('percentage','flat') NOT NULL,
  `discount_value` decimal(12,2) NOT NULL CHECK (`discount_value` > 0),
  `max_discount` decimal(12,2) DEFAULT NULL,
  `min_order_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `max_uses_total` int(11) DEFAULT NULL,
  `max_uses_per_user` int(11) NOT NULL DEFAULT 1,
  `current_uses` int(11) NOT NULL DEFAULT 0,
  `applicable_to` enum('ride','food','parcel','all') NOT NULL DEFAULT 'all',
  `applicable_vehicle_type_id` char(36) DEFAULT NULL,
  `applicable_city` varchar(100) DEFAULT NULL,
  `valid_from` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `valid_to` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ;

--
-- Dumping data for table `promo_codes`
--

INSERT INTO `promo_codes` (`id`, `code`, `description`, `discount_type`, `discount_value`, `max_discount`, `min_order_amount`, `max_uses_total`, `max_uses_per_user`, `current_uses`, `applicable_to`, `applicable_vehicle_type_id`, `applicable_city`, `valid_from`, `valid_to`, `is_active`, `created_at`) VALUES
('j1000001-0001-4000-a000-000000000001', 'WELCOME50', 'Welcome 50% off first ride (max ₹100)', 'percentage', 50.00, 100.00, 0.00, NULL, 1, 0, 'ride', NULL, NULL, '2026-04-01 20:21:34', '2026-07-30 20:21:34', 1, '2026-05-01 20:21:34'),
('j1000001-0002-4000-a000-000000000002', 'FLAT30', 'Flat ₹30 off any ride', 'flat', 30.00, NULL, 100.00, 1000, 3, 0, 'ride', NULL, NULL, '2026-04-24 20:21:34', '2026-05-31 20:21:34', 1, '2026-05-01 20:21:34'),
('j1000001-0003-4000-a000-000000000003', 'TESTALL100', 'Dev testing: ₹100 off everything', 'flat', 100.00, NULL, 0.00, NULL, 999, 0, 'all', NULL, NULL, '2026-04-30 20:21:34', '2027-05-01 20:21:34', 1, '2026-05-01 20:21:34');

-- --------------------------------------------------------

--
-- Table structure for table `promo_usages`
--

CREATE TABLE `promo_usages` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `promo_id` char(36) NOT NULL,
  `user_id` char(36) NOT NULL,
  `ride_id` char(36) DEFAULT NULL,
  `order_id` char(36) DEFAULT NULL,
  `parcel_id` char(36) DEFAULT NULL,
  `discount_applied` decimal(12,2) NOT NULL,
  `used_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `promo_usages`
--

INSERT INTO `promo_usages` (`id`, `promo_id`, `user_id`, `ride_id`, `order_id`, `parcel_id`, `discount_applied`, `used_at`) VALUES
('5985d5bf-459b-11f1-9547-e09d31f6397e', 'j1000001-0001-4000-a000-000000000001', 'a1b2c3d4-0002-4000-a000-000000000002', 's1000001-0002-4000-a000-000000000002', NULL, NULL, 57.50, '2026-05-01 20:21:34');

-- --------------------------------------------------------

--
-- Table structure for table `ratings`
--

CREATE TABLE `ratings` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `ride_id` char(36) DEFAULT NULL,
  `order_id` char(36) DEFAULT NULL,
  `parcel_id` char(36) DEFAULT NULL,
  `from_user_id` char(36) NOT NULL,
  `to_user_id` char(36) NOT NULL,
  `score` int(11) NOT NULL CHECK (`score` >= 1 and `score` <= 5),
  `review_text` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ;

--
-- Dumping data for table `ratings`
--

INSERT INTO `ratings` (`id`, `ride_id`, `order_id`, `parcel_id`, `from_user_id`, `to_user_id`, `score`, `review_text`, `created_at`) VALUES
('u1000001-0001-4000-a000-000000000001', 's1000001-0001-4000-a000-000000000001', NULL, NULL, 'a1b2c3d4-0001-4000-a000-000000000001', 'a1b2c3d4-0010-4000-a000-000000000010', 5, 'Excellent ride! Very smooth driving.', '2026-05-01 20:21:34'),
('u1000001-0002-4000-a000-000000000002', 's1000001-0001-4000-a000-000000000001', NULL, NULL, 'a1b2c3d4-0010-4000-a000-000000000010', 'a1b2c3d4-0001-4000-a000-000000000001', 4, NULL, '2026-05-01 20:21:34'),
('u1000001-0003-4000-a000-000000000003', 's1000001-0002-4000-a000-000000000002', NULL, NULL, 'a1b2c3d4-0002-4000-a000-000000000002', 'a1b2c3d4-0011-4000-a000-000000000011', 4, NULL, '2026-05-01 20:21:35');

-- --------------------------------------------------------

--
-- Table structure for table `rating_tags`
--

CREATE TABLE `rating_tags` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `tag_name` varchar(100) NOT NULL,
  `applicable_to` enum('rider_to_driver','driver_to_rider','customer_to_restaurant') NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `rating_tags`
--

INSERT INTO `rating_tags` (`id`, `tag_name`, `applicable_to`, `is_active`) VALUES
('t1000001-0001-4000-a000-000000000001', 'clean_car', 'rider_to_driver', 1),
('t1000001-0002-4000-a000-000000000002', 'polite', 'rider_to_driver', 1),
('t1000001-0003-4000-a000-000000000003', 'skilled_driver', 'rider_to_driver', 1),
('t1000001-0004-4000-a000-000000000004', 'fast_pickup', 'rider_to_driver', 1),
('t1000001-0005-4000-a000-000000000005', 'rash_driving', 'rider_to_driver', 1),
('t1000001-0006-4000-a000-000000000006', 'bad_route', 'rider_to_driver', 1),
('t1000001-0007-4000-a000-000000000007', 'polite_rider', 'driver_to_rider', 1),
('t1000001-0008-4000-a000-000000000008', 'messy_rider', 'driver_to_rider', 1),
('t1000001-0009-4000-a000-000000000009', 'late_pickup', 'driver_to_rider', 1);

-- --------------------------------------------------------

--
-- Table structure for table `rating_tag_maps`
--

CREATE TABLE `rating_tag_maps` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `rating_id` char(36) NOT NULL,
  `tag_id` char(36) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `rating_tag_maps`
--

INSERT INTO `rating_tag_maps` (`id`, `rating_id`, `tag_id`) VALUES
('598c38cd-459b-11f1-9547-e09d31f6397e', 'u1000001-0001-4000-a000-000000000001', 't1000001-0001-4000-a000-000000000001'),
('598c3d61-459b-11f1-9547-e09d31f6397e', 'u1000001-0001-4000-a000-000000000001', 't1000001-0002-4000-a000-000000000002'),
('598f1205-459b-11f1-9547-e09d31f6397e', 'u1000001-0002-4000-a000-000000000002', 't1000001-0007-4000-a000-000000000007');

-- --------------------------------------------------------

--
-- Table structure for table `rental_packages`
--

CREATE TABLE `rental_packages` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `vehicle_type_id` char(36) NOT NULL,
  `name` varchar(100) NOT NULL,
  `hours` int(11) NOT NULL CHECK (`hours` > 0),
  `kms_included` int(11) NOT NULL CHECK (`kms_included` > 0),
  `package_fare` float NOT NULL CHECK (`package_fare` > 0),
  `extra_km_rate` float NOT NULL CHECK (`extra_km_rate` >= 0),
  `extra_min_rate` float NOT NULL CHECK (`extra_min_rate` >= 0),
  `city` varchar(100) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `rental_packages`
--

INSERT INTO `rental_packages` (`id`, `vehicle_type_id`, `name`, `hours`, `kms_included`, `package_fare`, `extra_km_rate`, `extra_min_rate`, `city`, `is_active`, `created_at`) VALUES
('5969c28d-459b-11f1-9547-e09d31f6397e', 'd1000001-0003-4000-a000-000000000003', '2hr / 20km', 2, 20, 500, 14, 2, 'Bangalore', 1, '2026-05-01 20:21:34'),
('5969c64a-459b-11f1-9547-e09d31f6397e', 'd1000001-0003-4000-a000-000000000003', '4hr / 40km', 4, 40, 900, 14, 2, 'Bangalore', 1, '2026-05-01 20:21:34'),
('5969c6f4-459b-11f1-9547-e09d31f6397e', 'd1000001-0003-4000-a000-000000000003', '8hr / 80km', 8, 80, 1600, 14, 2, 'Bangalore', 1, '2026-05-01 20:21:34'),
('5969c766-459b-11f1-9547-e09d31f6397e', 'd1000001-0004-4000-a000-000000000004', '4hr / 40km', 4, 40, 1200, 18, 3, 'Bangalore', 1, '2026-05-01 20:21:34'),
('5969c7c9-459b-11f1-9547-e09d31f6397e', 'd1000001-0004-4000-a000-000000000004', '8hr / 80km', 8, 80, 2200, 18, 3, 'Bangalore', 1, '2026-05-01 20:21:34');

-- --------------------------------------------------------

--
-- Table structure for table `rider_profiles`
--

CREATE TABLE `rider_profiles` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `user_id` char(36) NOT NULL,
  `home_address` text DEFAULT NULL,
  `home_lat` float DEFAULT NULL,
  `home_lng` float DEFAULT NULL,
  `work_address` text DEFAULT NULL,
  `work_lat` float DEFAULT NULL,
  `work_lng` float DEFAULT NULL,
  `preferred_payment` enum('card','wallet','cash','upi') NOT NULL DEFAULT 'cash',
  `is_premium` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `rider_profiles`
--

INSERT INTO `rider_profiles` (`id`, `user_id`, `home_address`, `home_lat`, `home_lng`, `work_address`, `work_lat`, `work_lng`, `preferred_payment`, `is_premium`, `is_active`, `created_at`, `updated_at`) VALUES
('b1000001-0001-4000-a000-000000000001', 'a1b2c3d4-0001-4000-a000-000000000001', '80 Feet Road, Koramangala, Bangalore 560034', 12.9352, 77.6245, 'ITPL Main Road, Whitefield, Bangalore 560066', 12.9698, 77.75, 'upi', 0, 1, '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('b1000001-0002-4000-a000-000000000002', 'a1b2c3d4-0002-4000-a000-000000000002', '100 Feet Road, Indiranagar, Bangalore 560038', 12.9784, 77.6408, 'MG Road, Bangalore 560001', 12.9756, 77.6065, 'card', 0, 1, '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('b1000001-0003-4000-a000-000000000003', 'a1b2c3d4-0003-4000-a000-000000000003', '27th Main, HSR Layout, Bangalore 560102', 12.9116, 77.6389, 'Electronic City Phase 1, Bangalore 560100', 12.844, 77.663, 'cash', 0, 1, '2026-05-01 20:21:34', '2026-05-01 20:21:34');

-- --------------------------------------------------------

--
-- Table structure for table `rides`
--

CREATE TABLE `rides` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `request_id` char(36) NOT NULL,
  `driver_id` char(36) NOT NULL,
  `vehicle_id` char(36) NOT NULL,
  `carpool_id` char(36) DEFAULT NULL,
  `ride_number` varchar(30) NOT NULL,
  `status` enum('accepted','driver_arriving','arrived','in_progress','completed','cancelled') NOT NULL DEFAULT 'accepted',
  `estimated_fare` float NOT NULL,
  `actual_fare` float DEFAULT NULL,
  `base_fare` float NOT NULL,
  `distance_km` float DEFAULT NULL,
  `per_km_charged` float NOT NULL,
  `per_min_charged` float NOT NULL,
  `duration_minutes` int(11) DEFAULT NULL,
  `surge_multiplier` float NOT NULL DEFAULT 1,
  `platform_commission_pct` float NOT NULL DEFAULT 20,
  `platform_commission_amt` float DEFAULT NULL,
  `driver_earning` float DEFAULT NULL,
  `toll_charges` float NOT NULL DEFAULT 0,
  `waiting_charges` float NOT NULL DEFAULT 0,
  `otp_code` varchar(4) NOT NULL,
  `cancelled_by` enum('rider','driver','system') DEFAULT NULL,
  `cancellation_reason` text DEFAULT NULL,
  `cancellation_fee` float NOT NULL DEFAULT 0,
  `is_split_fare` tinyint(1) NOT NULL DEFAULT 0,
  `accepted_at` timestamp NULL DEFAULT NULL,
  `driver_arrived_at` timestamp NULL DEFAULT NULL,
  `pickup_at` timestamp NULL DEFAULT NULL,
  `dropoff_at` timestamp NULL DEFAULT NULL,
  `cancelled_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `rides`
--

INSERT INTO `rides` (`id`, `request_id`, `driver_id`, `vehicle_id`, `carpool_id`, `ride_number`, `status`, `estimated_fare`, `actual_fare`, `base_fare`, `distance_km`, `per_km_charged`, `per_min_charged`, `duration_minutes`, `surge_multiplier`, `platform_commission_pct`, `platform_commission_amt`, `driver_earning`, `toll_charges`, `waiting_charges`, `otp_code`, `cancelled_by`, `cancellation_reason`, `cancellation_fee`, `is_split_fare`, `accepted_at`, `driver_arrived_at`, `pickup_at`, `dropoff_at`, `cancelled_at`, `created_at`) VALUES
('s1000001-0001-4000-a000-000000000001', 'r1000001-0001-4000-a000-000000000001', 'c1000001-0010-4000-a000-000000000010', 'e1000001-0010-4000-a000-000000000010', NULL, 'RD-20260501-ABCD', 'completed', 378, 390.5, 70, 19.2, 16, 2.5, 45, 1.3, 20, 78.1, 312.4, 0, 0, '4829', NULL, NULL, 0, 0, '2026-05-01 18:21:34', '2026-05-01 18:31:34', '2026-05-01 18:33:34', '2026-05-01 19:18:34', NULL, '2026-05-01 18:21:34'),
('s1000001-0002-4000-a000-000000000002', 'r1000001-0002-4000-a000-000000000002', 'c1000001-0011-4000-a000-000000000011', 'e1000001-0011-4000-a000-000000000011', NULL, 'RD-20260501-EFGH', 'completed', 120, 115, 50, 4, 14, 2, 16, 1, 20, 23, 92, 0, 0, '7713', NULL, NULL, 0, 0, '2026-05-01 16:21:34', '2026-05-01 16:29:34', '2026-05-01 16:31:34', '2026-05-01 16:47:34', NULL, '2026-05-01 16:21:34'),
('s1000001-0003-4000-a000-000000000003', 'r1000001-0004-4000-a000-000000000004', 'c1000001-0010-4000-a000-000000000010', 'e1000001-0010-4000-a000-000000000010', NULL, 'RD-20260501-IJKL', 'in_progress', 850, NULL, 70, NULL, 16, 2.5, NULL, 1, 20, NULL, NULL, 0, 0, '3156', NULL, NULL, 0, 0, '2026-05-01 20:01:35', '2026-05-01 20:09:35', '2026-05-01 20:11:35', NULL, NULL, '2026-05-01 20:01:35');

-- --------------------------------------------------------

--
-- Table structure for table `ride_insurances`
--

CREATE TABLE `ride_insurances` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `ride_id` char(36) NOT NULL,
  `policy_number` varchar(50) NOT NULL,
  `provider` varchar(100) NOT NULL,
  `coverage_amount` decimal(12,2) NOT NULL,
  `status` enum('active','claimed','expired') NOT NULL DEFAULT 'active',
  `valid_from` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `valid_to` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ride_location_logs`
--

CREATE TABLE `ride_location_logs` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `ride_id` char(36) NOT NULL,
  `driver_id` char(36) NOT NULL,
  `lat` float NOT NULL,
  `lng` float NOT NULL,
  `speed` float DEFAULT NULL,
  `bearing` float DEFAULT NULL,
  `recorded_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ride_location_logs`
--

INSERT INTO `ride_location_logs` (`id`, `ride_id`, `driver_id`, `lat`, `lng`, `speed`, `bearing`, `recorded_at`) VALUES
('59777aea-459b-11f1-9547-e09d31f6397e', 's1000001-0001-4000-a000-000000000001', 'c1000001-0010-4000-a000-000000000010', 12.9352, 77.6245, 0, 90, '2026-05-01 18:33:34'),
('597780c5-459b-11f1-9547-e09d31f6397e', 's1000001-0001-4000-a000-000000000001', 'c1000001-0010-4000-a000-000000000010', 12.94, 77.635, 35.5, 85, '2026-05-01 18:41:34'),
('5977821a-459b-11f1-9547-e09d31f6397e', 's1000001-0001-4000-a000-000000000001', 'c1000001-0010-4000-a000-000000000010', 12.95, 77.66, 42, 80, '2026-05-01 18:51:34'),
('5977834c-459b-11f1-9547-e09d31f6397e', 's1000001-0001-4000-a000-000000000001', 'c1000001-0010-4000-a000-000000000010', 12.96, 77.7, 48, 78, '2026-05-01 19:06:34'),
('5977e3f0-459b-11f1-9547-e09d31f6397e', 's1000001-0001-4000-a000-000000000001', 'c1000001-0010-4000-a000-000000000010', 12.9698, 77.75, 0, 0, '2026-05-01 19:18:34');

-- --------------------------------------------------------

--
-- Table structure for table `ride_requests`
--

CREATE TABLE `ride_requests` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `rider_id` char(36) NOT NULL,
  `vehicle_type_id` char(36) NOT NULL,
  `pickup_lat` float NOT NULL,
  `pickup_lng` float NOT NULL,
  `pickup_address` text NOT NULL,
  `dropoff_lat` float NOT NULL,
  `dropoff_lng` float NOT NULL,
  `dropoff_address` text NOT NULL,
  `ride_type` enum('standard','premium','pool','rental','outstation') NOT NULL DEFAULT 'standard',
  `seats_requested` int(11) NOT NULL DEFAULT 1 CHECK (`seats_requested` > 0),
  `estimated_fare` float NOT NULL CHECK (`estimated_fare` > 0),
  `estimated_distance_km` float NOT NULL CHECK (`estimated_distance_km` > 0),
  `estimated_duration_min` int(11) NOT NULL CHECK (`estimated_duration_min` > 0),
  `surge_multiplier` float NOT NULL DEFAULT 1,
  `status` enum('pending','searching','matched','cancelled','expired','no_drivers') NOT NULL DEFAULT 'pending',
  `is_scheduled` tinyint(1) NOT NULL DEFAULT 0,
  `scheduled_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NOT NULL DEFAULT (current_timestamp() + interval 5 minute),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ride_requests`
--

INSERT INTO `ride_requests` (`id`, `rider_id`, `vehicle_type_id`, `pickup_lat`, `pickup_lng`, `pickup_address`, `dropoff_lat`, `dropoff_lng`, `dropoff_address`, `ride_type`, `seats_requested`, `estimated_fare`, `estimated_distance_km`, `estimated_duration_min`, `surge_multiplier`, `status`, `is_scheduled`, `scheduled_at`, `expires_at`, `created_at`) VALUES
('r1000001-0001-4000-a000-000000000001', 'b1000001-0001-4000-a000-000000000001', 'd1000001-0003-4000-a000-000000000003', 12.9352, 77.6245, '80 Feet Road, Koramangala, Bangalore 560034', 12.9698, 77.75, 'ITPL Main Road, Whitefield, Bangalore 560066', 'standard', 1, 378, 18.5, 42, 1.3, 'matched', 0, NULL, '2026-05-01 20:26:34', '2026-05-01 20:21:34'),
('r1000001-0002-4000-a000-000000000002', 'b1000001-0002-4000-a000-000000000002', 'd1000001-0002-4000-a000-000000000002', 12.9784, 77.6408, '100 Feet Road, Indiranagar', 12.9756, 77.6065, 'MG Road, Bangalore', 'standard', 1, 120, 4.2, 18, 1, 'matched', 0, NULL, '2026-05-01 20:26:34', '2026-05-01 20:21:34'),
('r1000001-0003-4000-a000-000000000003', 'b1000001-0003-4000-a000-000000000003', 'd1000001-0001-4000-a000-000000000001', 12.9116, 77.6389, '27th Main, HSR Layout', 12.844, 77.663, 'Electronic City Phase 1', 'standard', 1, 145, 9.5, 28, 1, 'cancelled', 0, NULL, '2026-05-01 20:26:35', '2026-05-01 20:21:35'),
('r1000001-0004-4000-a000-000000000004', 'b1000001-0002-4000-a000-000000000002', 'd1000001-0003-4000-a000-000000000003', 12.9784, 77.6408, '100 Feet Road, Indiranagar', 13.1989, 77.7068, 'Kempegowda International Airport', 'standard', 1, 850, 38, 65, 1, 'matched', 0, NULL, '2026-05-01 20:26:35', '2026-05-01 20:21:35');

-- --------------------------------------------------------

--
-- Table structure for table `ride_riders`
--

CREATE TABLE `ride_riders` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `ride_id` char(36) NOT NULL,
  `rider_id` char(36) NOT NULL,
  `pickup_lat` float NOT NULL,
  `pickup_lng` float NOT NULL,
  `pickup_address` text NOT NULL,
  `dropoff_lat` float NOT NULL,
  `dropoff_lng` float NOT NULL,
  `dropoff_address` text NOT NULL,
  `fare_share` float NOT NULL CHECK (`fare_share` >= 0),
  `status` enum('waiting','picked_up','dropped_off','cancelled') NOT NULL DEFAULT 'waiting',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ride_riders`
--

INSERT INTO `ride_riders` (`id`, `ride_id`, `rider_id`, `pickup_lat`, `pickup_lng`, `pickup_address`, `dropoff_lat`, `dropoff_lng`, `dropoff_address`, `fare_share`, `status`, `created_at`) VALUES
('5975291a-459b-11f1-9547-e09d31f6397e', 's1000001-0001-4000-a000-000000000001', 'b1000001-0001-4000-a000-000000000001', 12.9352, 77.6245, '80 Feet Road, Koramangala', 12.9698, 77.75, 'ITPL Main Road, Whitefield', 390.5, 'dropped_off', '2026-05-01 20:21:34'),
('5983f508-459b-11f1-9547-e09d31f6397e', 's1000001-0002-4000-a000-000000000002', 'b1000001-0002-4000-a000-000000000002', 12.9784, 77.6408, '100 Feet Road, Indiranagar', 12.9756, 77.6065, 'MG Road, Bangalore', 115, 'dropped_off', '2026-05-01 20:21:34'),
('599f19da-459b-11f1-9547-e09d31f6397e', 's1000001-0003-4000-a000-000000000003', 'b1000001-0002-4000-a000-000000000002', 12.9784, 77.6408, '100 Feet Road, Indiranagar', 13.1989, 77.7068, 'Kempegowda International Airport', 850, 'picked_up', '2026-05-01 20:21:35');

-- --------------------------------------------------------

--
-- Table structure for table `ride_routes`
--

CREATE TABLE `ride_routes` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `ride_id` char(36) NOT NULL,
  `polyline_encoded` text DEFAULT NULL,
  `distance_km` float NOT NULL,
  `estimated_duration_min` int(11) NOT NULL,
  `is_actual` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ride_routes`
--

INSERT INTO `ride_routes` (`id`, `ride_id`, `polyline_encoded`, `distance_km`, `estimated_duration_min`, `is_actual`, `created_at`) VALUES
('59763354-459b-11f1-9547-e09d31f6397e', 's1000001-0001-4000-a000-000000000001', 'mfnmAxqjsM_estimated_koramangala_whitefield', 18.5, 42, 0, '2026-05-01 20:21:34'),
('597636c0-459b-11f1-9547-e09d31f6397e', 's1000001-0001-4000-a000-000000000001', 'mfnmAxqjsM_actual_koramangala_whitefield', 19.2, 45, 1, '2026-05-01 20:21:34'),
('5984e32c-459b-11f1-9547-e09d31f6397e', 's1000001-0002-4000-a000-000000000002', 'indiranagar_to_mg_estimated', 4.2, 18, 0, '2026-05-01 20:21:34'),
('5984e4a6-459b-11f1-9547-e09d31f6397e', 's1000001-0002-4000-a000-000000000002', 'indiranagar_to_mg_actual', 4, 16, 1, '2026-05-01 20:21:34');

-- --------------------------------------------------------

--
-- Table structure for table `ride_stops`
--

CREATE TABLE `ride_stops` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `ride_id` char(36) NOT NULL,
  `stop_order` int(11) NOT NULL CHECK (`stop_order` > 0),
  `lat` float NOT NULL,
  `lng` float NOT NULL,
  `address` text NOT NULL,
  `status` enum('pending','arrived','completed','skipped') NOT NULL DEFAULT 'pending',
  `eta` timestamp NULL DEFAULT NULL,
  `arrived_at` timestamp NULL DEFAULT NULL,
  `departed_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ride_stops`
--

INSERT INTO `ride_stops` (`id`, `ride_id`, `stop_order`, `lat`, `lng`, `address`, `status`, `eta`, `arrived_at`, `departed_at`) VALUES
('59739db5-459b-11f1-9547-e09d31f6397e', 's1000001-0001-4000-a000-000000000001', 1, 12.9352, 77.6245, '80 Feet Road, Koramangala', 'completed', NULL, '2026-05-01 18:31:34', '2026-05-01 18:33:34'),
('5973a1d4-459b-11f1-9547-e09d31f6397e', 's1000001-0001-4000-a000-000000000001', 2, 12.9698, 77.75, 'ITPL Main Road, Whitefield', 'completed', NULL, '2026-05-01 19:18:34', '2026-05-01 19:18:34'),
('5982b426-459b-11f1-9547-e09d31f6397e', 's1000001-0002-4000-a000-000000000002', 1, 12.9784, 77.6408, '100 Feet Road, Indiranagar', 'completed', NULL, '2026-05-01 16:29:34', '2026-05-01 16:31:34'),
('5982b671-459b-11f1-9547-e09d31f6397e', 's1000001-0002-4000-a000-000000000002', 2, 12.9756, 77.6065, 'MG Road, Bangalore', 'completed', NULL, '2026-05-01 16:47:34', '2026-05-01 16:47:34'),
('599df9b9-459b-11f1-9547-e09d31f6397e', 's1000001-0003-4000-a000-000000000003', 1, 12.9784, 77.6408, '100 Feet Road, Indiranagar', 'completed', NULL, NULL, NULL),
('599e0774-459b-11f1-9547-e09d31f6397e', 's1000001-0003-4000-a000-000000000003', 2, 13.1989, 77.7068, 'Kempegowda International Airport', 'pending', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sos_alerts`
--

CREATE TABLE `sos_alerts` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `user_id` char(36) NOT NULL,
  `ride_id` char(36) DEFAULT NULL,
  `lat` float NOT NULL,
  `lng` float NOT NULL,
  `status` enum('triggered','acknowledged','responded','resolved','false_alarm') NOT NULL DEFAULT 'triggered',
  `notes` text DEFAULT NULL,
  `resolved_by` char(36) DEFAULT NULL,
  `triggered_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `resolved_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `split_fare_invites`
--

CREATE TABLE `split_fare_invites` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `ride_id` char(36) NOT NULL,
  `inviter_id` char(36) NOT NULL,
  `invitee_id` char(36) DEFAULT NULL,
  `invitee_phone` varchar(20) NOT NULL,
  `share_amount` float NOT NULL CHECK (`share_amount` > 0),
  `status` enum('pending','accepted','declined','expired') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `responded_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `support_categories`
--

CREATE TABLE `support_categories` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `parent_category_id` char(36) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `support_categories`
--

INSERT INTO `support_categories` (`id`, `name`, `description`, `parent_category_id`, `sort_order`, `is_active`) VALUES
('v1000001-0001-4000-a000-000000000001', 'fare_dispute', 'Issues with ride fare, toll charges, surge pricing', NULL, 1, 1),
('v1000001-0002-4000-a000-000000000002', 'safety', 'Safety concerns, SOS follow-up', NULL, 2, 1),
('v1000001-0003-4000-a000-000000000003', 'lost_item', 'Items left in vehicle', NULL, 3, 1),
('v1000001-0004-4000-a000-000000000004', 'driver_behavior', 'Rude behavior, rash driving', NULL, 4, 1),
('v1000001-0005-4000-a000-000000000005', 'payment_issue', 'Failed payment, refund request', NULL, 5, 1),
('v1000001-0006-4000-a000-000000000006', 'app_issue', 'App crashes, bugs, feature requests', NULL, 6, 1);

-- --------------------------------------------------------

--
-- Table structure for table `support_messages`
--

CREATE TABLE `support_messages` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `ticket_id` char(36) NOT NULL,
  `sender_id` char(36) NOT NULL,
  `content` text NOT NULL,
  `attachment_url` text DEFAULT NULL,
  `is_internal_note` tinyint(1) NOT NULL DEFAULT 0,
  `sent_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `support_messages`
--

INSERT INTO `support_messages` (`id`, `ticket_id`, `sender_id`, `content`, `attachment_url`, `is_internal_note`, `sent_at`) VALUES
('59975ccd-459b-11f1-9547-e09d31f6397e', 'w1000001-0001-4000-a000-000000000001', 'a1b2c3d4-0001-4000-a000-000000000001', 'Hi, I noticed the toll at ORR junction was not included in my fare. Can you please check?', NULL, 0, '2026-05-01 20:21:35'),
('59975f25-459b-11f1-9547-e09d31f6397e', 'w1000001-0001-4000-a000-000000000001', 'a1b2c3d4-0099-4000-a000-000000000099', 'Hi Aarav, we are looking into this. Toll charges will be adjusted within 24 hours. Thank you for your patience.', NULL, 0, '2026-05-01 20:21:35');

-- --------------------------------------------------------

--
-- Table structure for table `support_tickets`
--

CREATE TABLE `support_tickets` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `user_id` char(36) NOT NULL,
  `category_id` char(36) NOT NULL,
  `ride_id` char(36) DEFAULT NULL,
  `order_id` char(36) DEFAULT NULL,
  `parcel_id` char(36) DEFAULT NULL,
  `ticket_number` varchar(30) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `priority` enum('low','medium','high','urgent') NOT NULL DEFAULT 'medium',
  `status` enum('open','in_progress','awaiting_user','resolved','closed','reopened') NOT NULL DEFAULT 'open',
  `assigned_to` char(36) DEFAULT NULL,
  `resolved_at` timestamp NULL DEFAULT NULL,
  `closed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `support_tickets`
--

INSERT INTO `support_tickets` (`id`, `user_id`, `category_id`, `ride_id`, `order_id`, `parcel_id`, `ticket_number`, `subject`, `description`, `priority`, `status`, `assigned_to`, `resolved_at`, `closed_at`, `created_at`, `updated_at`) VALUES
('w1000001-0001-4000-a000-000000000001', 'a1b2c3d4-0001-4000-a000-000000000001', 'v1000001-0001-4000-a000-000000000001', 's1000001-0001-4000-a000-000000000001', NULL, NULL, 'TKT-20260501-0001', 'Toll charges not reflected correctly', 'I was charged ₹390.50 but the toll of ₹35 on Outer Ring Road was not added. Please check.', 'medium', 'open', NULL, NULL, NULL, '2026-05-01 20:21:35', '2026-05-01 20:21:35');

-- --------------------------------------------------------

--
-- Table structure for table `surge_zones`
--

CREATE TABLE `surge_zones` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `city` varchar(100) NOT NULL,
  `zone_name` varchar(100) NOT NULL,
  `geo_boundary` text DEFAULT NULL,
  `surge_multiplier` float NOT NULL CHECK (`surge_multiplier` >= 1.0),
  `active_from` timestamp NOT NULL DEFAULT current_timestamp(),
  `active_to` timestamp NOT NULL DEFAULT (current_timestamp() + interval 2 hour),
  `reason` varchar(50) NOT NULL DEFAULT 'high_demand',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `surge_zones`
--

INSERT INTO `surge_zones` (`id`, `city`, `zone_name`, `geo_boundary`, `surge_multiplier`, `active_from`, `active_to`, `reason`, `created_at`) VALUES
('i1000001-0001-4000-a000-000000000001', 'Bangalore', 'Koramangala', NULL, 1.3, '2026-05-01 20:21:34', '2026-05-01 22:21:34', 'high_demand', '2026-05-01 20:21:34'),
('i1000001-0002-4000-a000-000000000002', 'Bangalore', 'MG Road / CBD', NULL, 1.5, '2026-05-02 13:21:34', '2026-05-02 17:21:34', 'event', '2026-05-01 20:21:34');

-- --------------------------------------------------------

--
-- Table structure for table `system_configs`
--

CREATE TABLE `system_configs` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `config_key` varchar(100) NOT NULL,
  `config_value` text NOT NULL,
  `description` text DEFAULT NULL,
  `group_name` varchar(50) NOT NULL DEFAULT 'general',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `system_configs`
--

INSERT INTO `system_configs` (`id`, `config_key`, `config_value`, `description`, `group_name`, `updated_at`) VALUES
('5960e6f5-459b-11f1-9547-e09d31f6397e', 'ride_timeout_seconds', '300', 'Time before unmatched ride request expires', 'ride', '2026-05-01 20:21:34'),
('59610f2c-459b-11f1-9547-e09d31f6397e', 'max_surge_multiplier', '3.0', 'Maximum allowed surge multiplier', 'ride', '2026-05-01 20:21:34'),
('59611076-459b-11f1-9547-e09d31f6397e', 'platform_commission_pct', '20', 'Default platform commission percentage', 'payment', '2026-05-01 20:21:34'),
('596110e7-459b-11f1-9547-e09d31f6397e', 'min_wallet_topup', '100', 'Minimum wallet top-up amount in INR', 'payment', '2026-05-01 20:21:34'),
('5961115f-459b-11f1-9547-e09d31f6397e', 'max_wallet_balance', '50000', 'Maximum wallet balance in INR', 'payment', '2026-05-01 20:21:34'),
('596111cb-459b-11f1-9547-e09d31f6397e', 'driver_matching_radius_km', '5', 'Search radius for nearby drivers (km)', 'ride', '2026-05-01 20:21:34'),
('59611223-459b-11f1-9547-e09d31f6397e', 'driver_ping_timeout_sec', '15', 'Seconds to wait for driver to accept', 'ride', '2026-05-01 20:21:34'),
('5961127a-459b-11f1-9547-e09d31f6397e', 'max_ride_stops', '3', 'Maximum intermediate stops per ride', 'ride', '2026-05-01 20:21:34'),
('596112dc-459b-11f1-9547-e09d31f6397e', 'cancellation_fee_rider', '50', 'Default rider cancellation fee in INR', 'ride', '2026-05-01 20:21:34'),
('596113dc-459b-11f1-9547-e09d31f6397e', 'cancellation_fee_driver', '100', 'Default driver cancellation fee in INR', 'ride', '2026-05-01 20:21:34'),
('59611476-459b-11f1-9547-e09d31f6397e', 'sos_auto_alert_contacts', 'true', 'Auto-notify emergency contacts on SOS', 'safety', '2026-05-01 20:21:34'),
('596114df-459b-11f1-9547-e09d31f6397e', 'referral_bonus_referrer', '100', 'Referral bonus for referrer in INR', 'general', '2026-05-01 20:21:34'),
('5961153f-459b-11f1-9547-e09d31f6397e', 'referral_bonus_referee', '50', 'Referral bonus for new user in INR', 'general', '2026-05-01 20:21:34'),
('596115a0-459b-11f1-9547-e09d31f6397e', 'otp_expiry_seconds', '300', 'OTP expiry time', 'general', '2026-05-01 20:21:34'),
('59611605-459b-11f1-9547-e09d31f6397e', 'max_otp_attempts', '5', 'Max OTP verification attempts', 'general', '2026-05-01 20:21:34'),
('59611670-459b-11f1-9547-e09d31f6397e', 'support_auto_assign', 'false', 'Auto-assign tickets to available agents', 'general', '2026-05-01 20:21:34');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  `country_code` varchar(5) NOT NULL DEFAULT '+91',
  `profile_pic_url` text DEFAULT NULL,
  `role` enum('rider','driver','restaurant_owner','admin') NOT NULL DEFAULT 'rider',
  `app_type` enum('customer','partner') NOT NULL DEFAULT 'customer',
  `is_email_verified` tinyint(1) NOT NULL DEFAULT 0,
  `is_phone_verified` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `avg_rating` float NOT NULL DEFAULT 0,
  `telegram_chat_id` bigint(20) DEFAULT NULL,
  `preferred_language` varchar(5) NOT NULL DEFAULT 'en',
  `preferred_currency` varchar(5) NOT NULL DEFAULT 'INR',
  `timezone` varchar(50) NOT NULL DEFAULT 'Asia/Kolkata',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `country_code`, `profile_pic_url`, `role`, `app_type`, `is_email_verified`, `is_phone_verified`, `is_active`, `is_deleted`, `avg_rating`, `telegram_chat_id`, `preferred_language`, `preferred_currency`, `timezone`, `deleted_at`, `created_at`, `updated_at`) VALUES
('a1b2c3d4-0001-4000-a000-000000000001', 'Aarav', 'Sharma', 'aarav@test.com', '+919876543210', '+91', NULL, 'rider', 'customer', 0, 1, 1, 0, 4, 100001, 'en', 'INR', 'Asia/Kolkata', NULL, '2026-05-01 20:21:34', '2026-05-01 20:21:35'),
('a1b2c3d4-0002-4000-a000-000000000002', 'Priya', 'Patel', 'priya@test.com', '+919876543211', '+91', NULL, 'rider', 'customer', 0, 1, 1, 0, 0, 100002, 'en', 'INR', 'Asia/Kolkata', NULL, '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('a1b2c3d4-0003-4000-a000-000000000003', 'Rahul', 'Verma', NULL, '+919876543212', '+91', NULL, 'rider', 'customer', 0, 1, 1, 0, 0, 100003, 'en', 'INR', 'Asia/Kolkata', NULL, '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('a1b2c3d4-0010-4000-a000-000000000010', 'Vikram', 'Singh', 'vikram@test.com', '+919876543220', '+91', NULL, 'driver', 'partner', 0, 1, 1, 0, 5, 200001, 'en', 'INR', 'Asia/Kolkata', NULL, '2026-05-01 20:21:34', '2026-05-01 20:21:35'),
('a1b2c3d4-0011-4000-a000-000000000011', 'Suresh', 'Kumar', NULL, '+919876543221', '+91', NULL, 'driver', 'partner', 0, 1, 1, 0, 4, 200002, 'en', 'INR', 'Asia/Kolkata', NULL, '2026-05-01 20:21:34', '2026-05-01 20:21:35'),
('a1b2c3d4-0012-4000-a000-000000000012', 'Manoj', 'Yadav', 'manoj@test.com', '+919876543222', '+91', NULL, 'driver', 'partner', 0, 1, 1, 0, 0, 200003, 'en', 'INR', 'Asia/Kolkata', NULL, '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('a1b2c3d4-0099-4000-a000-000000000099', 'Karthik', 'Admin', 'admin@rideapp.com', '+919876543200', '+91', NULL, 'admin', 'partner', 0, 1, 1, 0, 0, 300001, 'en', 'INR', 'Asia/Kolkata', NULL, '2026-05-01 20:21:34', '2026-05-01 20:21:34');

-- --------------------------------------------------------

--
-- Table structure for table `user_sessions`
--

CREATE TABLE `user_sessions` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `user_id` char(36) NOT NULL,
  `device_token` text DEFAULT NULL,
  `device_type` enum('ios','android','web') NOT NULL,
  `device_model` varchar(100) DEFAULT NULL,
  `app_version` varchar(20) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `refresh_token` text NOT NULL,
  `expires_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_sessions`
--

INSERT INTO `user_sessions` (`id`, `user_id`, `device_token`, `device_type`, `device_model`, `app_version`, `ip_address`, `refresh_token`, `expires_at`, `is_active`, `created_at`) VALUES
('a2000001-0001-4000-a000-000000000001', 'a1b2c3d4-0001-4000-a000-000000000001', NULL, 'android', 'Samsung Galaxy S24', '1.0.0', '103.21.58.100', 'hashed_refresh_aarav_session_001', '2026-05-31 20:21:34', 1, '2026-05-01 20:21:34'),
('a2000001-0002-4000-a000-000000000002', 'a1b2c3d4-0002-4000-a000-000000000002', NULL, 'ios', 'iPhone 15 Pro', '1.0.0', '103.21.58.101', 'hashed_refresh_priya_session_001', '2026-05-31 20:21:34', 1, '2026-05-01 20:21:34'),
('a2000001-0010-4000-a000-000000000010', 'a1b2c3d4-0010-4000-a000-000000000010', NULL, 'android', 'Samsung Galaxy A54', '1.0.0', '103.21.58.200', 'hashed_refresh_vikram_session_001', '2026-05-31 20:21:34', 1, '2026-05-01 20:21:34'),
('a2000001-0011-4000-a000-000000000011', 'a1b2c3d4-0011-4000-a000-000000000011', NULL, 'android', 'Redmi Note 13', '1.0.0', '103.21.58.201', 'hashed_refresh_suresh_session_001', '2026-05-31 20:21:34', 1, '2026-05-01 20:21:34'),
('a2000001-0099-4000-a000-000000000099', 'a1b2c3d4-0099-4000-a000-000000000099', NULL, 'web', NULL, '1.0.0', '103.21.58.50', 'hashed_refresh_admin_session_001', '2026-05-08 20:21:34', 1, '2026-05-01 20:21:34');

-- --------------------------------------------------------

--
-- Table structure for table `vehicles`
--

CREATE TABLE `vehicles` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `driver_id` char(36) NOT NULL,
  `vehicle_type_id` char(36) NOT NULL,
  `make` varchar(50) NOT NULL,
  `model` varchar(50) NOT NULL,
  `year` int(11) NOT NULL CHECK (`year` >= 2000 and `year` <= 2030),
  `color` varchar(30) NOT NULL,
  `license_plate` varchar(20) NOT NULL,
  `seat_capacity` int(11) NOT NULL CHECK (`seat_capacity` > 0),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_current` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `vehicles`
--

INSERT INTO `vehicles` (`id`, `driver_id`, `vehicle_type_id`, `make`, `model`, `year`, `color`, `license_plate`, `seat_capacity`, `is_active`, `is_current`, `created_at`, `updated_at`) VALUES
('e1000001-0010-4000-a000-000000000010', 'c1000001-0010-4000-a000-000000000010', 'd1000001-0003-4000-a000-000000000003', 'Maruti', 'Dzire', 2023, 'White', 'KA01AB1234', 4, 1, 1, '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('e1000001-0011-4000-a000-000000000011', 'c1000001-0011-4000-a000-000000000011', 'd1000001-0002-4000-a000-000000000002', 'Maruti', 'Swift', 2022, 'Red', 'KA02CD5678', 4, 1, 1, '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('e1000001-0012-4000-a000-000000000012', 'c1000001-0012-4000-a000-000000000012', 'd1000001-0001-4000-a000-000000000001', 'Bajaj', 'RE Compact', 2021, 'Green', 'KA03EF9999', 3, 1, 1, '2026-05-01 20:21:34', '2026-05-01 20:21:34');

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_types`
--

CREATE TABLE `vehicle_types` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `name` varchar(50) NOT NULL,
  `display_name` varchar(100) NOT NULL,
  `icon_url` text DEFAULT NULL,
  `default_seat_capacity` int(11) NOT NULL CHECK (`default_seat_capacity` > 0),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `vehicle_types`
--

INSERT INTO `vehicle_types` (`id`, `name`, `display_name`, `icon_url`, `default_seat_capacity`, `is_active`, `created_at`) VALUES
('d1000001-0001-4000-a000-000000000001', 'auto', 'Auto Rickshaw', NULL, 3, 1, '2026-05-01 20:21:34'),
('d1000001-0002-4000-a000-000000000002', 'hatchback', 'Mini (Hatchback)', NULL, 4, 1, '2026-05-01 20:21:34'),
('d1000001-0003-4000-a000-000000000003', 'sedan', 'Sedan', NULL, 4, 1, '2026-05-01 20:21:34'),
('d1000001-0004-4000-a000-000000000004', 'suv', 'SUV / XL', NULL, 6, 1, '2026-05-01 20:21:34'),
('d1000001-0005-4000-a000-000000000005', 'bike', 'Bike', NULL, 1, 1, '2026-05-01 20:21:34'),
('d1000001-0006-4000-a000-000000000006', 'luxury', 'Luxury / Premium', NULL, 4, 1, '2026-05-01 20:21:34');

-- --------------------------------------------------------

--
-- Table structure for table `wallets`
--

CREATE TABLE `wallets` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `user_id` char(36) NOT NULL,
  `balance` decimal(12,2) NOT NULL DEFAULT 0.00 CHECK (`balance` >= 0),
  `currency` varchar(5) NOT NULL DEFAULT 'INR',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wallets`
--

INSERT INTO `wallets` (`id`, `user_id`, `balance`, `currency`, `is_active`, `updated_at`, `created_at`) VALUES
('f1000001-0001-4000-a000-000000000001', 'a1b2c3d4-0001-4000-a000-000000000001', 500.00, 'INR', 1, '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('f1000001-0002-4000-a000-000000000002', 'a1b2c3d4-0002-4000-a000-000000000002', 1200.00, 'INR', 1, '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('f1000001-0003-4000-a000-000000000003', 'a1b2c3d4-0003-4000-a000-000000000003', 0.00, 'INR', 1, '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('f1000001-0010-4000-a000-000000000010', 'a1b2c3d4-0010-4000-a000-000000000010', 3500.00, 'INR', 1, '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('f1000001-0011-4000-a000-000000000011', 'a1b2c3d4-0011-4000-a000-000000000011', 2100.00, 'INR', 1, '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('f1000001-0012-4000-a000-000000000012', 'a1b2c3d4-0012-4000-a000-000000000012', 0.00, 'INR', 1, '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('f1000001-0099-4000-a000-000000000099', 'a1b2c3d4-0099-4000-a000-000000000099', 0.00, 'INR', 1, '2026-05-01 20:21:34', '2026-05-01 20:21:34');

-- --------------------------------------------------------

--
-- Table structure for table `wallet_transactions`
--

CREATE TABLE `wallet_transactions` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `wallet_id` char(36) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `type` enum('credit','debit') NOT NULL,
  `source` enum('ride_payment','refund','cashback','referral_bonus','top_up','withdrawal','food_payment','parcel_payment') NOT NULL,
  `description` text NOT NULL,
  `reference_id` char(36) DEFAULT NULL,
  `balance_after` decimal(12,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wallet_transactions`
--

INSERT INTO `wallet_transactions` (`id`, `wallet_id`, `amount`, `type`, `source`, `description`, `reference_id`, `balance_after`, `created_at`) VALUES
('59599954-459b-11f1-9547-e09d31f6397e', 'f1000001-0001-4000-a000-000000000001', 1000.00, 'credit', 'top_up', 'Wallet top-up via UPI', NULL, 1000.00, '2026-04-21 20:21:34'),
('5959cc00-459b-11f1-9547-e09d31f6397e', 'f1000001-0001-4000-a000-000000000001', 500.00, 'debit', 'ride_payment', 'Ride payment #RD-20260420-ABCD', NULL, 500.00, '2026-04-26 20:21:34'),
('5959cdc3-459b-11f1-9547-e09d31f6397e', 'f1000001-0002-4000-a000-000000000002', 2000.00, 'credit', 'top_up', 'Wallet top-up via card', NULL, 2000.00, '2026-04-16 20:21:34'),
('5959cec3-459b-11f1-9547-e09d31f6397e', 'f1000001-0002-4000-a000-000000000002', 200.00, 'credit', 'cashback', 'First ride cashback', NULL, 2200.00, '2026-04-17 20:21:34'),
('5959d015-459b-11f1-9547-e09d31f6397e', 'f1000001-0002-4000-a000-000000000002', 1000.00, 'debit', 'ride_payment', 'Ride payment', NULL, 1200.00, '2026-04-24 20:21:34');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `driver_documents`
--
ALTER TABLE `driver_documents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `verified_by` (`verified_by`),
  ADD KEY `idx_driver_docs` (`driver_id`);

--
-- Indexes for table `driver_earnings`
--
ALTER TABLE `driver_earnings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ride_id` (`ride_id`),
  ADD KEY `idx_earnings_driver` (`driver_id`,`status`);

--
-- Indexes for table `driver_payouts`
--
ALTER TABLE `driver_payouts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_payouts_driver` (`driver_id`);

--
-- Indexes for table `driver_profiles`
--
ALTER TABLE `driver_profiles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`),
  ADD UNIQUE KEY `license_number` (`license_number`);

--
-- Indexes for table `emergency_contacts`
--
ALTER TABLE `emergency_contacts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_emergency_user` (`user_id`);

--
-- Indexes for table `fare_rules`
--
ALTER TABLE `fare_rules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vehicle_type_id` (`vehicle_type_id`),
  ADD KEY `idx_fare_rules_city` (`city`,`vehicle_type_id`);

--
-- Indexes for table `favorite_locations`
--
ALTER TABLE `favorite_locations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_fav_loc_user` (`user_id`);

--
-- Indexes for table `live_location_shares`
--
ALTER TABLE `live_location_shares`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ride_id` (`ride_id`),
  ADD KEY `rider_id` (`rider_id`),
  ADD KEY `emergency_contact_id` (`emergency_contact_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `payment_number` (`payment_number`),
  ADD KEY `payment_method_id` (`payment_method_id`),
  ADD KEY `idx_payments_user` (`user_id`),
  ADD KEY `idx_payments_ride` (`ride_id`),
  ADD KEY `idx_payments_status` (`status`,`created_at`);

--
-- Indexes for table `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_payment_methods_user` (`user_id`);

--
-- Indexes for table `promo_codes`
--
ALTER TABLE `promo_codes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`),
  ADD KEY `applicable_vehicle_type_id` (`applicable_vehicle_type_id`);

--
-- Indexes for table `promo_usages`
--
ALTER TABLE `promo_usages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ride_id` (`ride_id`),
  ADD KEY `idx_promo_usage_promo` (`promo_id`),
  ADD KEY `idx_promo_usage_user` (`user_id`);

--
-- Indexes for table `ratings`
--
ALTER TABLE `ratings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ride_id` (`ride_id`),
  ADD KEY `from_user_id` (`from_user_id`),
  ADD KEY `idx_ratings_to_user` (`to_user_id`);

--
-- Indexes for table `rating_tags`
--
ALTER TABLE `rating_tags`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tag_name` (`tag_name`);

--
-- Indexes for table `rating_tag_maps`
--
ALTER TABLE `rating_tag_maps`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_rating_tag` (`rating_id`,`tag_id`),
  ADD KEY `tag_id` (`tag_id`),
  ADD KEY `idx_rating_tag_map_rating` (`rating_id`);

--
-- Indexes for table `rental_packages`
--
ALTER TABLE `rental_packages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vehicle_type_id` (`vehicle_type_id`);

--
-- Indexes for table `rider_profiles`
--
ALTER TABLE `rider_profiles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `rides`
--
ALTER TABLE `rides`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `request_id` (`request_id`),
  ADD UNIQUE KEY `ride_number` (`ride_number`),
  ADD KEY `vehicle_id` (`vehicle_id`),
  ADD KEY `idx_rides_driver_status` (`driver_id`,`status`),
  ADD KEY `idx_rides_active` (`status`);

--
-- Indexes for table `ride_insurances`
--
ALTER TABLE `ride_insurances`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ride_id` (`ride_id`);

--
-- Indexes for table `ride_location_logs`
--
ALTER TABLE `ride_location_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `driver_id` (`driver_id`),
  ADD KEY `idx_location_log_ride` (`ride_id`,`recorded_at`);

--
-- Indexes for table `ride_requests`
--
ALTER TABLE `ride_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vehicle_type_id` (`vehicle_type_id`),
  ADD KEY `idx_ride_requests_rider` (`rider_id`),
  ADD KEY `idx_ride_requests_status` (`status`,`created_at`);

--
-- Indexes for table `ride_riders`
--
ALTER TABLE `ride_riders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `rider_id` (`rider_id`),
  ADD KEY `idx_ride_riders_ride` (`ride_id`);

--
-- Indexes for table `ride_routes`
--
ALTER TABLE `ride_routes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ride_id` (`ride_id`);

--
-- Indexes for table `ride_stops`
--
ALTER TABLE `ride_stops`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_ride_stops_ride` (`ride_id`);

--
-- Indexes for table `sos_alerts`
--
ALTER TABLE `sos_alerts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `ride_id` (`ride_id`),
  ADD KEY `resolved_by` (`resolved_by`);

--
-- Indexes for table `split_fare_invites`
--
ALTER TABLE `split_fare_invites`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ride_id` (`ride_id`),
  ADD KEY `inviter_id` (`inviter_id`),
  ADD KEY `invitee_id` (`invitee_id`);

--
-- Indexes for table `support_categories`
--
ALTER TABLE `support_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `parent_category_id` (`parent_category_id`);

--
-- Indexes for table `support_messages`
--
ALTER TABLE `support_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sender_id` (`sender_id`),
  ADD KEY `idx_support_msgs_ticket` (`ticket_id`);

--
-- Indexes for table `support_tickets`
--
ALTER TABLE `support_tickets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ticket_number` (`ticket_number`),
  ADD KEY `category_id` (`category_id`),
  ADD KEY `ride_id` (`ride_id`),
  ADD KEY `assigned_to` (`assigned_to`),
  ADD KEY `idx_tickets_user` (`user_id`),
  ADD KEY `idx_tickets_status` (`status`,`priority`);

--
-- Indexes for table `surge_zones`
--
ALTER TABLE `surge_zones`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_configs`
--
ALTER TABLE `system_configs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `config_key` (`config_key`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `phone` (`phone`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_users_phone` (`phone`),
  ADD KEY `idx_users_telegram` (`telegram_chat_id`),
  ADD KEY `idx_users_role` (`role`);

--
-- Indexes for table `user_sessions`
--
ALTER TABLE `user_sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_sessions_user` (`user_id`),
  ADD KEY `idx_sessions_active` (`user_id`,`is_active`);

--
-- Indexes for table `vehicles`
--
ALTER TABLE `vehicles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `license_plate` (`license_plate`),
  ADD KEY `vehicle_type_id` (`vehicle_type_id`),
  ADD KEY `idx_vehicles_driver` (`driver_id`);

--
-- Indexes for table `vehicle_types`
--
ALTER TABLE `vehicle_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `wallets`
--
ALTER TABLE `wallets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `wallet_transactions`
--
ALTER TABLE `wallet_transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_wallet_txn_wallet` (`wallet_id`,`created_at`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `driver_documents`
--
ALTER TABLE `driver_documents`
  ADD CONSTRAINT `driver_documents_ibfk_1` FOREIGN KEY (`driver_id`) REFERENCES `driver_profiles` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `driver_documents_ibfk_2` FOREIGN KEY (`verified_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `driver_earnings`
--
ALTER TABLE `driver_earnings`
  ADD CONSTRAINT `driver_earnings_ibfk_1` FOREIGN KEY (`driver_id`) REFERENCES `driver_profiles` (`id`),
  ADD CONSTRAINT `driver_earnings_ibfk_2` FOREIGN KEY (`ride_id`) REFERENCES `rides` (`id`);

--
-- Constraints for table `driver_payouts`
--
ALTER TABLE `driver_payouts`
  ADD CONSTRAINT `driver_payouts_ibfk_1` FOREIGN KEY (`driver_id`) REFERENCES `driver_profiles` (`id`);

--
-- Constraints for table `driver_profiles`
--
ALTER TABLE `driver_profiles`
  ADD CONSTRAINT `driver_profiles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `emergency_contacts`
--
ALTER TABLE `emergency_contacts`
  ADD CONSTRAINT `emergency_contacts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `fare_rules`
--
ALTER TABLE `fare_rules`
  ADD CONSTRAINT `fare_rules_ibfk_1` FOREIGN KEY (`vehicle_type_id`) REFERENCES `vehicle_types` (`id`);

--
-- Constraints for table `favorite_locations`
--
ALTER TABLE `favorite_locations`
  ADD CONSTRAINT `favorite_locations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `live_location_shares`
--
ALTER TABLE `live_location_shares`
  ADD CONSTRAINT `live_location_shares_ibfk_1` FOREIGN KEY (`ride_id`) REFERENCES `rides` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `live_location_shares_ibfk_2` FOREIGN KEY (`rider_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `live_location_shares_ibfk_3` FOREIGN KEY (`emergency_contact_id`) REFERENCES `emergency_contacts` (`id`);

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `payments_ibfk_2` FOREIGN KEY (`ride_id`) REFERENCES `rides` (`id`),
  ADD CONSTRAINT `payments_ibfk_3` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods` (`id`);

--
-- Constraints for table `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD CONSTRAINT `payment_methods_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `promo_codes`
--
ALTER TABLE `promo_codes`
  ADD CONSTRAINT `promo_codes_ibfk_1` FOREIGN KEY (`applicable_vehicle_type_id`) REFERENCES `vehicle_types` (`id`);

--
-- Constraints for table `promo_usages`
--
ALTER TABLE `promo_usages`
  ADD CONSTRAINT `promo_usages_ibfk_1` FOREIGN KEY (`promo_id`) REFERENCES `promo_codes` (`id`),
  ADD CONSTRAINT `promo_usages_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `promo_usages_ibfk_3` FOREIGN KEY (`ride_id`) REFERENCES `rides` (`id`);

--
-- Constraints for table `ratings`
--
ALTER TABLE `ratings`
  ADD CONSTRAINT `ratings_ibfk_1` FOREIGN KEY (`ride_id`) REFERENCES `rides` (`id`),
  ADD CONSTRAINT `ratings_ibfk_2` FOREIGN KEY (`from_user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `ratings_ibfk_3` FOREIGN KEY (`to_user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `rating_tag_maps`
--
ALTER TABLE `rating_tag_maps`
  ADD CONSTRAINT `rating_tag_maps_ibfk_1` FOREIGN KEY (`rating_id`) REFERENCES `ratings` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `rating_tag_maps_ibfk_2` FOREIGN KEY (`tag_id`) REFERENCES `rating_tags` (`id`);

--
-- Constraints for table `rental_packages`
--
ALTER TABLE `rental_packages`
  ADD CONSTRAINT `rental_packages_ibfk_1` FOREIGN KEY (`vehicle_type_id`) REFERENCES `vehicle_types` (`id`);

--
-- Constraints for table `rider_profiles`
--
ALTER TABLE `rider_profiles`
  ADD CONSTRAINT `rider_profiles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `rides`
--
ALTER TABLE `rides`
  ADD CONSTRAINT `rides_ibfk_1` FOREIGN KEY (`request_id`) REFERENCES `ride_requests` (`id`),
  ADD CONSTRAINT `rides_ibfk_2` FOREIGN KEY (`driver_id`) REFERENCES `driver_profiles` (`id`),
  ADD CONSTRAINT `rides_ibfk_3` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicles` (`id`);

--
-- Constraints for table `ride_insurances`
--
ALTER TABLE `ride_insurances`
  ADD CONSTRAINT `ride_insurances_ibfk_1` FOREIGN KEY (`ride_id`) REFERENCES `rides` (`id`);

--
-- Constraints for table `ride_location_logs`
--
ALTER TABLE `ride_location_logs`
  ADD CONSTRAINT `ride_location_logs_ibfk_1` FOREIGN KEY (`ride_id`) REFERENCES `rides` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ride_location_logs_ibfk_2` FOREIGN KEY (`driver_id`) REFERENCES `driver_profiles` (`id`);

--
-- Constraints for table `ride_requests`
--
ALTER TABLE `ride_requests`
  ADD CONSTRAINT `ride_requests_ibfk_1` FOREIGN KEY (`rider_id`) REFERENCES `rider_profiles` (`id`),
  ADD CONSTRAINT `ride_requests_ibfk_2` FOREIGN KEY (`vehicle_type_id`) REFERENCES `vehicle_types` (`id`);

--
-- Constraints for table `ride_riders`
--
ALTER TABLE `ride_riders`
  ADD CONSTRAINT `ride_riders_ibfk_1` FOREIGN KEY (`ride_id`) REFERENCES `rides` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ride_riders_ibfk_2` FOREIGN KEY (`rider_id`) REFERENCES `rider_profiles` (`id`);

--
-- Constraints for table `ride_routes`
--
ALTER TABLE `ride_routes`
  ADD CONSTRAINT `ride_routes_ibfk_1` FOREIGN KEY (`ride_id`) REFERENCES `rides` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `ride_stops`
--
ALTER TABLE `ride_stops`
  ADD CONSTRAINT `ride_stops_ibfk_1` FOREIGN KEY (`ride_id`) REFERENCES `rides` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `sos_alerts`
--
ALTER TABLE `sos_alerts`
  ADD CONSTRAINT `sos_alerts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `sos_alerts_ibfk_2` FOREIGN KEY (`ride_id`) REFERENCES `rides` (`id`),
  ADD CONSTRAINT `sos_alerts_ibfk_3` FOREIGN KEY (`resolved_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `split_fare_invites`
--
ALTER TABLE `split_fare_invites`
  ADD CONSTRAINT `split_fare_invites_ibfk_1` FOREIGN KEY (`ride_id`) REFERENCES `rides` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `split_fare_invites_ibfk_2` FOREIGN KEY (`inviter_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `split_fare_invites_ibfk_3` FOREIGN KEY (`invitee_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `support_categories`
--
ALTER TABLE `support_categories`
  ADD CONSTRAINT `support_categories_ibfk_1` FOREIGN KEY (`parent_category_id`) REFERENCES `support_categories` (`id`);

--
-- Constraints for table `support_messages`
--
ALTER TABLE `support_messages`
  ADD CONSTRAINT `support_messages_ibfk_1` FOREIGN KEY (`ticket_id`) REFERENCES `support_tickets` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `support_messages_ibfk_2` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `support_tickets`
--
ALTER TABLE `support_tickets`
  ADD CONSTRAINT `support_tickets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `support_tickets_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `support_categories` (`id`),
  ADD CONSTRAINT `support_tickets_ibfk_3` FOREIGN KEY (`ride_id`) REFERENCES `rides` (`id`),
  ADD CONSTRAINT `support_tickets_ibfk_4` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`);

--
-- Constraints for table `user_sessions`
--
ALTER TABLE `user_sessions`
  ADD CONSTRAINT `user_sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `vehicles`
--
ALTER TABLE `vehicles`
  ADD CONSTRAINT `vehicles_ibfk_1` FOREIGN KEY (`driver_id`) REFERENCES `driver_profiles` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `vehicles_ibfk_2` FOREIGN KEY (`vehicle_type_id`) REFERENCES `vehicle_types` (`id`);

--
-- Constraints for table `wallets`
--
ALTER TABLE `wallets`
  ADD CONSTRAINT `wallets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `wallet_transactions`
--
ALTER TABLE `wallet_transactions`
  ADD CONSTRAINT `wallet_transactions_ibfk_1` FOREIGN KEY (`wallet_id`) REFERENCES `wallets` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
