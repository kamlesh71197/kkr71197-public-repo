const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
    res.status(200).json({
        message: 'student get route is working'
    })
})

router.post('/', (req, res,next) => {
    res.status(200).json({
        message: 'student post route is working',
        id:1500,
        name:'Abhishek'
    })
})


module.exports = router;
