require('dotenv').config();
const express = require('express');
const app = express();
const pool = require('./db');
const jwt = require('jsonwebtoken');
const auth = require('./middleware/auth');
const bcrypt = require('bcrypt');
const bodyParser = require("body-parser");
const axios = require("axios");
const JWT_SECRET = process.env.JWT_SECRET || 'supersecret';
const TOKEN = "7645835735:AAHV0lccH-prn0xMomszx0asKJ-zVKEZBOs";
const CHAT_ID = "7645835735";

app.use(express.json());

// Test DB connection
async function checkDB() {
  try {
    const { rows } = await pool.query('SELECT NOW()');
    console.log('DB Connected at:', rows[0].now);
  } catch (err) {
    console.error('DB Error:', err);
  }
}

checkDB();

// Routes
app.get('/', async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT NOW()');
    res.json({ time: rows[0].now });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/users', async (req, res) => {
  try {
    const { rows } = await pool.query(
      'SELECT * FROM users ORDER BY created_at DESC'
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});





app.get('/api/v1/auth/get-profile', async (req, res) => {
   const { phone } = req.body;
  try {
     const { rows } = await pool.query(
      `SELECT * FROM users WHERE phone = $1 AND is_deleted = false`,
      [phone]
    );

     if (rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }


     res.json({
      success: true,
      data: rows
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/auth/login', async (req, res) => {
  const { email, password, device_token, device_type } = req.body;

  try {
    // 1. Validate input
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password required' });
    }

    // 2. Get user
    const { rows } = await pool.query(
      `SELECT * FROM users WHERE email = $1 AND is_deleted = false`,
      [email]
    );

    if (rows.length === 0) {
      return res.status(400).json({ error: 'Invalid credentials' });
    }

    const user = rows[0];

    // 3. Check password
    const isMatch = await bcrypt.compare(password, user.password);

    if (!isMatch) {
      return res.status(400).json({ error: 'Invalid credentials' });
    }

    // 4. Generate tokens
    const accessToken = jwt.sign(
      { userId: user.id },
      process.env.ACCESS_TOKEN_SECRET,
      { expiresIn: '15m' }
    );

    const refreshToken = jwt.sign(
      { userId: user.id },
        process.env.REFRESH_TOKEN_SECRET,
      { expiresIn: '7d' }
    );

    // 5. OPTIONAL: remove old session for same device
    await pool.query(
      `UPDATE user_sessions
       SET is_active = false
       WHERE user_id = $1 AND device_token = $2`,
      [user.id, device_token]
    );

    // 6. Store new session
    await pool.query(
      `INSERT INTO user_sessions 
       (user_id, device_token, device_type, refresh_token, expires_at, is_active)
       VALUES ($1, $2, $3, $4, NOW() + INTERVAL '7 days', true)`,
      [user.id, device_token, device_type, refreshToken]
    );

    // 7. Response (never send password!)
    res.json({
      accessToken,
      refreshToken,
      user: {
        id: user.id,
        email: user.email,
        first_name: user.first_name,
        role: user.role
      }
    });

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/v1/auth/signup', async (req, res) => {
  const {
    first_name,
    last_name,
    email,
    password,
    phone,
    country_code
  } = req.body;

  try {
    // 1. Validate input
    if (!email || !password || !phone) {
      return res.status(400).json({
        error: 'Email, password and phone are required'
      });
    }

    // 2. Check if user already exists (email OR phone)
    const existingUser = await pool.query(
      `SELECT email, phone FROM users WHERE email = $1 OR phone = $2`,
      [email, phone]
    );

    if (existingUser.rows.length > 0) {
      const user = existingUser.rows[0];

      if (user.email === email) {
        return res.status(400).json({ error: 'Email already exists' });
      }

      if (user.phone === phone) {
        return res.status(400).json({ error: 'Phone already exists' });
      }
    }

    // 3. Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // 4. Create user
    const { rows } = await pool.query(
      `INSERT INTO users 
       (first_name, last_name, email, password, phone, country_code, is_active)
       VALUES ($1, $2, $3, $4, $5, $6, true)
       RETURNING id, email, first_name, role`,
      [first_name, last_name, email, hashedPassword, phone, country_code]
    );

    const data = rows[0];

    // 5. Generate tokens
    const accessToken = jwt.sign(
      { userId: data.id },
      process.env.ACCESS_TOKEN_SECRET,
      { expiresIn: '15m' }
    );

    const refreshToken = jwt.sign(
      { userId: data.id },
      process.env.REFRESH_TOKEN_SECRET,
      { expiresIn: '7d' }
    );

    // 6. Store session
    await pool.query(
      `INSERT INTO user_sessions
       (user_id, device_token, device_type, refresh_token, expires_at, is_active)
       VALUES ($1, $2, $3, $4, NOW() + INTERVAL '7 days', true)`,
      [
        data.id,
        req.body.device_token || null,
        req.body.device_type || 'web',
        refreshToken
      ]
    );

    // 7. Response
    res.status(201).json({
      success: true,
      message: 'User registered successfully',
      data,
      accessToken,
      refreshToken
    });

  } catch (err) {
    if (err.code === '23505') {
      return res.status(400).json({
        error: 'Email or phone already exists'
      });
    }

    res.status(500).json({ error: err.message });
  }
});

app.post('/api/v1/auth/send-otp', async (req, res) => {
  const { phone, device_type = 'web' } = req.body;

  try {
    // Validate phone
    if (!phone) {
      return res.status(400).json({
        success: false,
        error: 'Phone is required'
      });
    }


    // Check user exists
    const user = await pool.query(
      `SELECT id 
       FROM users 
       WHERE phone = $1 
       AND is_deleted = false`,
      [phone]
    );
let userId;
    // If user does not exist → insert new user
    if (user.rows.length === 0) {
      const newUser = await pool.query(
        `INSERT INTO users (phone)
         VALUES ($1)
         RETURNING id`,
        [phone]
      );
     userId = newUser.rows[0].id;
    } else {
      userId = user.rows[0].id;
    }

   

    // Get updated user details
    const userdetails = await pool.query(
      `SELECT *
       FROM users
       WHERE phone = $1`,
      [phone]
    );

  

 // Generate JWT Token



    const token = jwt.sign(
      {
        user_id: userId,
        phone: phone
      },
      process.env.JWT_SECRET
    );


    res.json({
      success: true,
      data: userdetails.rows[0],
       token,
      message: 'OTP sent successfully'
    });

  } catch (err) {
    console.error(err);

    res.status(500).json({
      success: false,
      error: err.message
    });
  }
});

app.post('/api/v1/auth/verify-otp', async (req, res) => {
  const { phone, otp, device_type = 'web', device_token = null } = req.body;

  try {
    if (!phone || !otp) {
      return res.status(400).json({ error: 'Phone and OTP required' });
    }

    const result = await pool.query(
      `SELECT id, first_name, email, role 
       FROM users 
       WHERE phone = $1 
       AND otp = $2 
       AND otp_expiry > NOW()
       AND is_deleted = false`,
      [phone, otp]
    );

    if (result.rows.length === 0) {
      return res.status(400).json({ error: 'Invalid or expired OTP' });
    }

    const data = result.rows[0];

    // clear OTP
    await pool.query(
      `UPDATE users 
       SET otp = NULL, otp_expiry = NULL, is_phone_verified = true
       WHERE id = $1`,
      [data.id]
    );

    // JWT
    const accessToken = jwt.sign(
      { userId: data.id, role: data.role },
      process.env.ACCESS_TOKEN_SECRET,
      { expiresIn: '15m' }
    );

    const refreshToken = jwt.sign(
      { userId: data.id },
      process.env.REFRESH_TOKEN_SECRET,
      { expiresIn: '7d' }
    );

    // session insert (FIXED device_type issue)
    await pool.query(
      `INSERT INTO user_sessions 
       (user_id, device_token, device_type, refresh_token, expires_at, is_active)
       VALUES ($1, $2, $3, $4, NOW() + INTERVAL '7 days', true)`,
      [
        data.id,
        device_token,
        device_type,
        refreshToken
      ]
    );

    res.json({
      success: true,
      message: 'Login successful',
      data,
      accessToken,
      refreshToken
    });

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});



app.put('/api/v1/auth/update-profile', auth, async (req, res) => {
  const { first_name, last_name, email, phone } = req.body;

  try {
    const id = req.user.user_id; 

    await pool.query(
      `UPDATE users
       SET 
         first_name = $1,
         last_name  = $2,
         email      = $3,
         phone      = $4,
         updated_at = NOW()
       WHERE id = $5
       AND is_deleted = false`,
      [
        first_name || null,
        last_name || null,
        email || null,
        phone,
        id
      ]
    );

    const { rows } = await pool.query(
      `SELECT * FROM users WHERE id = $1`,
      [id]
    );

    res.json({
      success: true,
      data: rows[0],
      message: 'Your Profile updated successfully'
    });

  } catch (err) {
    res.status(500).json({
      success: false,
      error: err.message
    });
  }
});


app.post('/api/v1/auth/refresh-token', async (req, res) => {
  const { refreshToken } = req.body;

  try {
    if (!refreshToken) {
      return res.status(400).json({ error: 'Refresh token required' });
    }

    const session = await pool.query(
      `SELECT * FROM user_sessions 
       WHERE refresh_token = $1 AND is_active = true`,
      [refreshToken]
    );

    if (session.rows.length === 0) {
      return res.status(403).json({ error: 'Invalid refresh token' });
    }

    const decoded = jwt.verify(
      refreshToken,
      process.env.REFRESH_TOKEN_SECRET
    );

    const accessToken = jwt.sign(
      { userId: decoded.userId },
      process.env.ACCESS_TOKEN_SECRET,
      { expiresIn: '15m' }
    );

    res.json({ accessToken });

  } catch (err) {
    res.status(403).json({ error: 'Token expired or invalid' });
  }
});

app.post('/api/v1/auth/logout', async (req, res) => {
  const { refreshToken } = req.body;

  try {
    await pool.query(
      `UPDATE user_sessions 
       SET is_active = false 
       WHERE refresh_token = $1`,
      [refreshToken]
    );

    res.json({
        success: true,
     message: 'Logged out successfully' });

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});


app.delete('/api/v1/auth/account', async (req, res) => {
  const userId = req.user?.userId;

  try {
    await pool.query(
      `UPDATE users 
       SET is_deleted = true, deleted_at = NOW()
       WHERE id = $1`,
      [userId]
    );

    await pool.query(
      `UPDATE user_sessions 
       SET is_active = false 
       WHERE user_id = $1`,
      [userId]
    );

    res.json({ message: 'Account deleted successfully' });

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});


app.post("/send-message", async (req, res) => {
  try {
    const message = req.body.message || "Hello!";

    const url = `https://api.telegram.org/bot7645835735:AAHV0lccH-prn0xMomszx0asKJ-zVKEZBOs/getMe`;

    const response = await axios.post(
      url,
      {
        chat_id: CHAT_ID,
        text: message,
      },
      {
        timeout: 5000, // ⏱ 5 seconds timeout
      }
    );

    res.json(response.data);

  } catch (err) {
    res.status(500).json({
      error: err.code === "ECONNABORTED"
        ? "Request timed out (network issue)"
        : err.response?.data || err.message,
    });
  }
});

// Start server
app.listen(3000, () => {
  console.log('Server running on port 3000');
});

// Graceful shutdown
process.on('SIGINT', async () => {
  console.log('Shutting down...');
  await pool.end();
  process.exit(0);
});
