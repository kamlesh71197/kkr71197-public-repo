-- phpMyAdmin SQL Dump (CORRECTED)
-- Original version: 5.2.1
-- Fixes applied:
--   1. Removed DEFAULT uuid() — generate UUIDs at application layer (MySQL 5.x compat)
--   2. Added ENGINE=InnoDB to promo_codes and ratings
--   3. Fixed promo_codes.valid_from (removed ON UPDATE current_timestamp)
--   4. Fixed expires_at / valid_to zero-date defaults → NULL
--   5. Fixed user_sessions.expires_at ON UPDATE (removed)
--   6. Fixed ride_insurances.valid_from ON UPDATE (removed)
--   7. Changed FLOAT to DECIMAL(10,2) for all monetary fare columns
--   8. Changed FLOAT to DECIMAL(10,7) for all lat/lng columns
--   9. Added CHECK (amount > 0) to wallet_transactions
--  10. Added UNIQUE KEY on (driver_id, doc_type) in driver_documents
--  11. Added index on surge_zones (city, active_from, active_to)
--  12. Added created_at to system_configs
--  13. Added deactivated_at / deactivated_by audit columns to promo_codes
-- NOTE: UUIDs must now be generated in your application before INSERT.

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

-- --------------------------------------------------------
-- Database: `rideapp_dev`
-- --------------------------------------------------------

-- --------------------------------------------------------
-- Table: users
-- --------------------------------------------------------
CREATE TABLE `users` (
  `id` char(36) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  `country_code` varchar(5) NOT NULL DEFAULT '+91',
  `profile_pic_url` text DEFAULT NULL,
  `role` enum('rider','driver','restaurant_owner','admin') NOT NULL DEFAULT 'rider',
  `app_type` enum('customer','partner') NOT NULL DEFAULT 'customer',
  `is_email_verified` tinyint(1) NOT NULL DEFAULT 0,
  `is_phone_verified` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `avg_rating` decimal(3,2) NOT NULL DEFAULT 0.00,
  `telegram_chat_id` bigint(20) DEFAULT NULL,
  `preferred_language` varchar(5) NOT NULL DEFAULT 'en',
  `preferred_currency` varchar(5) NOT NULL DEFAULT 'INR',
  `timezone` varchar(50) NOT NULL DEFAULT 'Asia/Kolkata',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `phone` (`phone`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_users_phone` (`phone`),
  KEY `idx_users_telegram` (`telegram_chat_id`),
  KEY `idx_users_role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `country_code`, `profile_pic_url`, `role`, `app_type`, `is_email_verified`, `is_phone_verified`, `is_active`, `is_deleted`, `avg_rating`, `telegram_chat_id`, `preferred_language`, `preferred_currency`, `timezone`, `deleted_at`, `created_at`, `updated_at`) VALUES
('a1b2c3d4-0001-4000-a000-000000000001', 'Aarav', 'Sharma', 'aarav@test.com', '+919876543210', '+91', NULL, 'rider', 'customer', 0, 1, 1, 0, 4.00, 100001, 'en', 'INR', 'Asia/Kolkata', NULL, '2026-05-01 20:21:34', '2026-05-01 20:21:35'),
('a1b2c3d4-0002-4000-a000-000000000002', 'Priya', 'Patel', 'priya@test.com', '+919876543211', '+91', NULL, 'rider', 'customer', 0, 1, 1, 0, 0.00, 100002, 'en', 'INR', 'Asia/Kolkata', NULL, '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('a1b2c3d4-0003-4000-a000-000000000003', 'Rahul', 'Verma', NULL, '+919876543212', '+91', NULL, 'rider', 'customer', 0, 1, 1, 0, 0.00, 100003, 'en', 'INR', 'Asia/Kolkata', NULL, '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('a1b2c3d4-0010-4000-a000-000000000010', 'Vikram', 'Singh', 'vikram@test.com', '+919876543220', '+91', NULL, 'driver', 'partner', 0, 1, 1, 0, 5.00, 200001, 'en', 'INR', 'Asia/Kolkata', NULL, '2026-05-01 20:21:34', '2026-05-01 20:21:35'),
('a1b2c3d4-0011-4000-a000-000000000011', 'Suresh', 'Kumar', NULL, '+919876543221', '+91', NULL, 'driver', 'partner', 0, 1, 1, 0, 4.00, 200002, 'en', 'INR', 'Asia/Kolkata', NULL, '2026-05-01 20:21:34', '2026-05-01 20:21:35'),
('a1b2c3d4-0012-4000-a000-000000000012', 'Manoj', 'Yadav', 'manoj@test.com', '+919876543222', '+91', NULL, 'driver', 'partner', 0, 1, 1, 0, 0.00, 200003, 'en', 'INR', 'Asia/Kolkata', NULL, '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('a1b2c3d4-0099-4000-a000-000000000099', 'Karthik', 'Admin', 'admin@rideapp.com', '+919876543200', '+91', NULL, 'admin', 'partner', 0, 1, 1, 0, 0.00, 300001, 'en', 'INR', 'Asia/Kolkata', NULL, '2026-05-01 20:21:34', '2026-05-01 20:21:34');

-- --------------------------------------------------------
-- Table: user_sessions
-- FIX: Removed ON UPDATE from expires_at (was resetting expiry on every row update)
-- FIX: refresh_token note — hash tokens at application layer before storing
-- --------------------------------------------------------
CREATE TABLE `user_sessions` (
  `id` char(36) NOT NULL,
  `user_id` char(36) NOT NULL,
  `device_token` text DEFAULT NULL,
  `device_type` enum('ios','android','web') NOT NULL,
  `device_model` varchar(100) DEFAULT NULL,
  `app_version` varchar(20) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `refresh_token` text NOT NULL,
  `expires_at` timestamp NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_sessions_user` (`user_id`),
  KEY `idx_sessions_active` (`user_id`,`is_active`),
  CONSTRAINT `user_sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `user_sessions` (`id`, `user_id`, `device_token`, `device_type`, `device_model`, `app_version`, `ip_address`, `refresh_token`, `expires_at`, `is_active`, `created_at`) VALUES
('a2000001-0001-4000-a000-000000000001', 'a1b2c3d4-0001-4000-a000-000000000001', NULL, 'android', 'Samsung Galaxy S24', '1.0.0', '103.21.58.100', 'hashed_refresh_aarav_session_001', '2026-05-31 20:21:34', 1, '2026-05-01 20:21:34'),
('a2000001-0002-4000-a000-000000000002', 'a1b2c3d4-0002-4000-a000-000000000002', NULL, 'ios', 'iPhone 15 Pro', '1.0.0', '103.21.58.101', 'hashed_refresh_priya_session_001', '2026-05-31 20:21:34', 1, '2026-05-01 20:21:34'),
('a2000001-0010-4000-a000-000000000010', 'a1b2c3d4-0010-4000-a000-000000000010', NULL, 'android', 'Samsung Galaxy A54', '1.0.0', '103.21.58.200', 'hashed_refresh_vikram_session_001', '2026-05-31 20:21:34', 1, '2026-05-01 20:21:34'),
('a2000001-0011-4000-a000-000000000011', 'a1b2c3d4-0011-4000-a000-000000000011', NULL, 'android', 'Redmi Note 13', '1.0.0', '103.21.58.201', 'hashed_refresh_suresh_session_001', '2026-05-31 20:21:34', 1, '2026-05-01 20:21:34'),
('a2000001-0099-4000-a000-000000000099', 'a1b2c3d4-0099-4000-a000-000000000099', NULL, 'web', NULL, '1.0.0', '103.21.58.50', 'hashed_refresh_admin_session_001', '2026-05-08 20:21:34', 1, '2026-05-01 20:21:34');

-- --------------------------------------------------------
-- Table: vehicle_types
-- --------------------------------------------------------
CREATE TABLE `vehicle_types` (
  `id` char(36) NOT NULL,
  `name` varchar(50) NOT NULL,
  `display_name` varchar(100) NOT NULL,
  `icon_url` text DEFAULT NULL,
  `default_seat_capacity` int(11) NOT NULL CHECK (`default_seat_capacity` > 0),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `vehicle_types` (`id`, `name`, `display_name`, `icon_url`, `default_seat_capacity`, `is_active`, `created_at`) VALUES
('d1000001-0001-4000-a000-000000000001', 'auto', 'Auto Rickshaw', NULL, 3, 1, '2026-05-01 20:21:34'),
('d1000001-0002-4000-a000-000000000002', 'hatchback', 'Mini (Hatchback)', NULL, 4, 1, '2026-05-01 20:21:34'),
('d1000001-0003-4000-a000-000000000003', 'sedan', 'Sedan', NULL, 4, 1, '2026-05-01 20:21:34'),
('d1000001-0004-4000-a000-000000000004', 'suv', 'SUV / XL', NULL, 6, 1, '2026-05-01 20:21:34'),
('d1000001-0005-4000-a000-000000000005', 'bike', 'Bike', NULL, 1, 1, '2026-05-01 20:21:34'),
('d1000001-0006-4000-a000-000000000006', 'luxury', 'Luxury / Premium', NULL, 4, 1, '2026-05-01 20:21:34');

-- --------------------------------------------------------
-- Table: driver_profiles
-- FIX: lat/lng changed from FLOAT to DECIMAL(10,7)
-- NOTE: bank_account_number should be encrypted at application layer before storing
-- --------------------------------------------------------
CREATE TABLE `driver_profiles` (
  `id` char(36) NOT NULL,
  `user_id` char(36) NOT NULL,
  `license_number` varchar(50) NOT NULL,
  `license_expiry` date NOT NULL,
  `is_available` tinyint(1) NOT NULL DEFAULT 0,
  `verification_status` enum('pending','documents_submitted','under_review','approved','rejected','suspended') NOT NULL DEFAULT 'pending',
  `current_lat` decimal(10,7) DEFAULT NULL,
  `current_lng` decimal(10,7) DEFAULT NULL,
  `status` enum('online','offline','on_ride','on_delivery') NOT NULL DEFAULT 'offline',
  `payout_frequency` enum('daily','weekly') NOT NULL DEFAULT 'weekly',
  `bank_account_number` text DEFAULT NULL,
  `bank_ifsc` varchar(20) DEFAULT NULL,
  `bank_name` varchar(100) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `last_location_update` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `license_number` (`license_number`),
  CONSTRAINT `driver_profiles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `driver_profiles` (`id`, `user_id`, `license_number`, `license_expiry`, `is_available`, `verification_status`, `current_lat`, `current_lng`, `status`, `payout_frequency`, `bank_account_number`, `bank_ifsc`, `bank_name`, `is_active`, `last_location_update`, `created_at`, `updated_at`) VALUES
('c1000001-0010-4000-a000-000000000010', 'a1b2c3d4-0010-4000-a000-000000000010', 'KA01-2020-0012345', '2028-12-31', 0, 'approved', 12.9400000, 77.6200000, 'on_ride', 'weekly', 'XXXX1234', 'SBIN0001234', 'SBI', 1, NULL, '2026-05-01 20:21:34', '2026-05-01 20:21:35'),
('c1000001-0011-4000-a000-000000000011', 'a1b2c3d4-0011-4000-a000-000000000011', 'KA02-2021-0067890', '2029-06-30', 1, 'approved', 12.9750000, 77.6400000, 'online', 'daily', 'XXXX5678', 'HDFC0002345', 'HDFC Bank', 1, NULL, '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('c1000001-0012-4000-a000-000000000012', 'a1b2c3d4-0012-4000-a000-000000000012', 'KA03-2019-0099999', '2027-03-15', 0, 'pending', NULL, NULL, 'offline', 'weekly', NULL, NULL, NULL, 1, NULL, '2026-05-01 20:21:34', '2026-05-01 20:21:34');

-- --------------------------------------------------------
-- Table: driver_documents
-- FIX: Added UNIQUE KEY on (driver_id, doc_type) to prevent duplicate doc types
-- --------------------------------------------------------
CREATE TABLE `driver_documents` (
  `id` char(36) NOT NULL,
  `driver_id` char(36) NOT NULL,
  `doc_type` enum('driving_license','vehicle_insurance','vehicle_registration','background_check','identity_proof','address_proof','vehicle_photo') NOT NULL,
  `document_url` text NOT NULL,
  `status` enum('pending','under_review','approved','rejected','expired') NOT NULL DEFAULT 'pending',
  `rejection_reason` text DEFAULT NULL,
  `verified_by` char(36) DEFAULT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `verified_at` timestamp NULL DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_driver_doc` (`driver_id`,`doc_type`),
  KEY `verified_by` (`verified_by`),
  KEY `idx_driver_docs` (`driver_id`),
  CONSTRAINT `driver_documents_ibfk_1` FOREIGN KEY (`driver_id`) REFERENCES `driver_profiles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `driver_documents_ibfk_2` FOREIGN KEY (`verified_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `driver_documents` (`id`, `driver_id`, `doc_type`, `document_url`, `status`, `rejection_reason`, `verified_by`, `uploaded_at`, `verified_at`, `expiry_date`) VALUES
('5955d11a-459b-11f1-9547-e09d31f6397e', 'c1000001-0010-4000-a000-000000000010', 'driving_license', 'https://r2.rideapp.dev/docs/vikram_dl.pdf', 'approved', NULL, 'a1b2c3d4-0099-4000-a000-000000000099', '2026-04-01 20:21:34', '2026-04-02 20:21:34', NULL),
('595603c6-459b-11f1-9547-e09d31f6397e', 'c1000001-0010-4000-a000-000000000010', 'vehicle_registration', 'https://r2.rideapp.dev/docs/vikram_rc.pdf', 'approved', NULL, 'a1b2c3d4-0099-4000-a000-000000000099', '2026-04-01 20:21:34', '2026-04-02 20:21:34', NULL),
('59560522-459b-11f1-9547-e09d31f6397e', 'c1000001-0010-4000-a000-000000000010', 'vehicle_insurance', 'https://r2.rideapp.dev/docs/vikram_ins.pdf', 'approved', NULL, 'a1b2c3d4-0099-4000-a000-000000000099', '2026-04-01 20:21:34', '2026-04-02 20:21:34', NULL),
('595606a8-459b-11f1-9547-e09d31f6397e', 'c1000001-0011-4000-a000-000000000011', 'driving_license', 'https://r2.rideapp.dev/docs/suresh_dl.pdf', 'approved', NULL, 'a1b2c3d4-0099-4000-a000-000000000099', '2026-04-11 20:21:34', '2026-04-12 20:21:34', NULL),
('5956084b-459b-11f1-9547-e09d31f6397e', 'c1000001-0011-4000-a000-000000000011', 'vehicle_registration', 'https://r2.rideapp.dev/docs/suresh_rc.pdf', 'approved', NULL, 'a1b2c3d4-0099-4000-a000-000000000099', '2026-04-11 20:21:34', '2026-04-12 20:21:34', NULL),
('5956092a-459b-11f1-9547-e09d31f6397e', 'c1000001-0012-4000-a000-000000000012', 'driving_license', 'https://r2.rideapp.dev/docs/manoj_dl.pdf', 'pending', NULL, NULL, '2026-04-29 20:21:34', NULL, NULL),
('595609b9-459b-11f1-9547-e09d31f6397e', 'c1000001-0012-4000-a000-000000000012', 'identity_proof', 'https://r2.rideapp.dev/docs/manoj_aadhaar.pdf', 'pending', NULL, NULL, '2026-04-29 20:21:34', NULL, NULL);

-- --------------------------------------------------------
-- Table: driver_earnings
-- FIX: Monetary columns changed from FLOAT to DECIMAL(12,2)
-- --------------------------------------------------------
CREATE TABLE `driver_earnings` (
  `id` char(36) NOT NULL,
  `driver_id` char(36) NOT NULL,
  `ride_id` char(36) DEFAULT NULL,
  `order_id` char(36) DEFAULT NULL,
  `parcel_id` char(36) DEFAULT NULL,
  `gross_amount` decimal(12,2) NOT NULL,
  `commission_deducted` decimal(12,2) NOT NULL,
  `incentive_bonus` decimal(12,2) NOT NULL DEFAULT 0.00,
  `tip` decimal(12,2) NOT NULL DEFAULT 0.00,
  `net_earning` decimal(12,2) NOT NULL,
  `status` enum('pending','paid') NOT NULL DEFAULT 'pending',
  `earned_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `paid_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ride_id` (`ride_id`),
  KEY `idx_earnings_driver` (`driver_id`,`status`),
  CONSTRAINT `driver_earnings_ibfk_1` FOREIGN KEY (`driver_id`) REFERENCES `driver_profiles` (`id`),
  CONSTRAINT `driver_earnings_ibfk_2` FOREIGN KEY (`ride_id`) REFERENCES `rides` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `driver_earnings` (`id`, `driver_id`, `ride_id`, `order_id`, `parcel_id`, `gross_amount`, `commission_deducted`, `incentive_bonus`, `tip`, `net_earning`, `status`, `earned_at`, `paid_at`) VALUES
('597b5596-459b-11f1-9547-e09d31f6397e', 'c1000001-0010-4000-a000-000000000010', 's1000001-0001-4000-a000-000000000001', NULL, NULL, 390.50, 78.10, 0.00, 0.00, 312.40, 'pending', '2026-05-01 19:19:34', NULL),
('59884cd9-459b-11f1-9547-e09d31f6397e', 'c1000001-0011-4000-a000-000000000011', 's1000001-0002-4000-a000-000000000002', NULL, NULL, 115.00, 23.00, 0.00, 0.00, 92.00, 'pending', '2026-05-01 16:48:34', NULL);

-- --------------------------------------------------------
-- Table: driver_payouts
-- --------------------------------------------------------
CREATE TABLE `driver_payouts` (
  `id` char(36) NOT NULL,
  `driver_id` char(36) NOT NULL,
  `amount` decimal(12,2) NOT NULL CHECK (`amount` > 0),
  `status` enum('pending','processing','completed','failed') NOT NULL DEFAULT 'pending',
  `frequency` enum('daily','weekly') NOT NULL,
  `period_start` date NOT NULL,
  `period_end` date NOT NULL,
  `bank_reference` text DEFAULT NULL,
  `processed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_payouts_driver` (`driver_id`),
  CONSTRAINT `driver_payouts_ibfk_1` FOREIGN KEY (`driver_id`) REFERENCES `driver_profiles` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: vehicles
-- --------------------------------------------------------
CREATE TABLE `vehicles` (
  `id` char(36) NOT NULL,
  `driver_id` char(36) NOT NULL,
  `vehicle_type_id` char(36) NOT NULL,
  `make` varchar(50) NOT NULL,
  `model` varchar(50) NOT NULL,
  `year` int(11) NOT NULL CHECK (`year` >= 2000 AND `year` <= 2030),
  `color` varchar(30) NOT NULL,
  `license_plate` varchar(20) NOT NULL,
  `seat_capacity` int(11) NOT NULL CHECK (`seat_capacity` > 0),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_current` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `license_plate` (`license_plate`),
  KEY `vehicle_type_id` (`vehicle_type_id`),
  KEY `idx_vehicles_driver` (`driver_id`),
  CONSTRAINT `vehicles_ibfk_1` FOREIGN KEY (`driver_id`) REFERENCES `driver_profiles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `vehicles_ibfk_2` FOREIGN KEY (`vehicle_type_id`) REFERENCES `vehicle_types` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `vehicles` (`id`, `driver_id`, `vehicle_type_id`, `make`, `model`, `year`, `color`, `license_plate`, `seat_capacity`, `is_active`, `is_current`, `created_at`, `updated_at`) VALUES
('e1000001-0010-4000-a000-000000000010', 'c1000001-0010-4000-a000-000000000010', 'd1000001-0003-4000-a000-000000000003', 'Maruti', 'Dzire', 2023, 'White', 'KA01AB1234', 4, 1, 1, '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('e1000001-0011-4000-a000-000000000011', 'c1000001-0011-4000-a000-000000000011', 'd1000001-0002-4000-a000-000000000002', 'Maruti', 'Swift', 2022, 'Red', 'KA02CD5678', 4, 1, 1, '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('e1000001-0012-4000-a000-000000000012', 'c1000001-0012-4000-a000-000000000012', 'd1000001-0001-4000-a000-000000000001', 'Bajaj', 'RE Compact', 2021, 'Green', 'KA03EF9999', 3, 1, 1, '2026-05-01 20:21:34', '2026-05-01 20:21:34');

-- --------------------------------------------------------
-- Table: rider_profiles
-- FIX: lat/lng changed from FLOAT to DECIMAL(10,7)
-- --------------------------------------------------------
CREATE TABLE `rider_profiles` (
  `id` char(36) NOT NULL,
  `user_id` char(36) NOT NULL,
  `home_address` text DEFAULT NULL,
  `home_lat` decimal(10,7) DEFAULT NULL,
  `home_lng` decimal(10,7) DEFAULT NULL,
  `work_address` text DEFAULT NULL,
  `work_lat` decimal(10,7) DEFAULT NULL,
  `work_lng` decimal(10,7) DEFAULT NULL,
  `preferred_payment` enum('card','wallet','cash','upi') NOT NULL DEFAULT 'cash',
  `is_premium` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `rider_profiles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `rider_profiles` (`id`, `user_id`, `home_address`, `home_lat`, `home_lng`, `work_address`, `work_lat`, `work_lng`, `preferred_payment`, `is_premium`, `is_active`, `created_at`, `updated_at`) VALUES
('b1000001-0001-4000-a000-000000000001', 'a1b2c3d4-0001-4000-a000-000000000001', '80 Feet Road, Koramangala, Bangalore 560034', 12.9352000, 77.6245000, 'ITPL Main Road, Whitefield, Bangalore 560066', 12.9698000, 77.7500000, 'upi', 0, 1, '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('b1000001-0002-4000-a000-000000000002', 'a1b2c3d4-0002-4000-a000-000000000002', '100 Feet Road, Indiranagar, Bangalore 560038', 12.9784000, 77.6408000, 'MG Road, Bangalore 560001', 12.9756000, 77.6065000, 'card', 0, 1, '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('b1000001-0003-4000-a000-000000000003', 'a1b2c3d4-0003-4000-a000-000000000003', '27th Main, HSR Layout, Bangalore 560102', 12.9116000, 77.6389000, 'Electronic City Phase 1, Bangalore 560100', 12.8440000, 77.6630000, 'cash', 0, 1, '2026-05-01 20:21:34', '2026-05-01 20:21:34');

-- --------------------------------------------------------
-- Table: fare_rules
-- FIX: Monetary fare columns changed from FLOAT to DECIMAL(10,2)
-- --------------------------------------------------------
CREATE TABLE `fare_rules` (
  `id` char(36) NOT NULL,
  `vehicle_type_id` char(36) NOT NULL,
  `city` varchar(100) NOT NULL,
  `zone` varchar(100) DEFAULT NULL,
  `base_fare` decimal(10,2) NOT NULL CHECK (`base_fare` >= 0),
  `per_km_rate` decimal(10,2) NOT NULL CHECK (`per_km_rate` >= 0),
  `per_min_rate` decimal(10,2) NOT NULL CHECK (`per_min_rate` >= 0),
  `min_fare` decimal(10,2) NOT NULL CHECK (`min_fare` >= 0),
  `booking_fee` decimal(10,2) NOT NULL DEFAULT 0.00,
  `cancellation_fee` decimal(10,2) NOT NULL CHECK (`cancellation_fee` >= 0),
  `waiting_charge_per_min` decimal(10,2) NOT NULL DEFAULT 0.00,
  `night_surcharge_pct` decimal(5,2) NOT NULL DEFAULT 0.00,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `effective_from` timestamp NOT NULL DEFAULT current_timestamp(),
  `effective_to` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `vehicle_type_id` (`vehicle_type_id`),
  KEY `idx_fare_rules_city` (`city`,`vehicle_type_id`),
  CONSTRAINT `fare_rules_ibfk_1` FOREIGN KEY (`vehicle_type_id`) REFERENCES `vehicle_types` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `fare_rules` (`id`, `vehicle_type_id`, `city`, `zone`, `base_fare`, `per_km_rate`, `per_min_rate`, `min_fare`, `booking_fee`, `cancellation_fee`, `waiting_charge_per_min`, `night_surcharge_pct`, `is_active`, `effective_from`, `effective_to`) VALUES
('h1000001-0001-4000-a000-000000000001', 'd1000001-0001-4000-a000-000000000001', 'Bangalore', NULL, 30.00, 12.00, 1.50, 50.00, 5.00, 25.00, 1.00, 10.00, 1, '2026-05-01 20:21:34', NULL),
('h1000001-0002-4000-a000-000000000002', 'd1000001-0002-4000-a000-000000000002', 'Bangalore', NULL, 50.00, 14.00, 2.00, 80.00, 10.00, 50.00, 1.50, 15.00, 1, '2026-05-01 20:21:34', NULL),
('h1000001-0003-4000-a000-000000000003', 'd1000001-0003-4000-a000-000000000003', 'Bangalore', NULL, 70.00, 16.00, 2.50, 100.00, 10.00, 50.00, 2.00, 15.00, 1, '2026-05-01 20:21:34', NULL),
('h1000001-0004-4000-a000-000000000004', 'd1000001-0004-4000-a000-000000000004', 'Bangalore', NULL, 100.00, 20.00, 3.00, 150.00, 15.00, 75.00, 2.50, 15.00, 1, '2026-05-01 20:21:34', NULL),
('h1000001-0005-4000-a000-000000000005', 'd1000001-0005-4000-a000-000000000005', 'Bangalore', NULL, 20.00, 8.00, 1.00, 30.00, 0.00, 15.00, 0.50, 5.00, 1, '2026-05-01 20:21:34', NULL),
('h1000001-0006-4000-a000-000000000006', 'd1000001-0006-4000-a000-000000000006', 'Bangalore', NULL, 150.00, 25.00, 4.00, 250.00, 20.00, 100.00, 3.00, 20.00, 1, '2026-05-01 20:21:34', NULL);

-- --------------------------------------------------------
-- Table: rental_packages
-- FIX: Monetary columns changed from FLOAT to DECIMAL(10,2)
-- --------------------------------------------------------
CREATE TABLE `rental_packages` (
  `id` char(36) NOT NULL,
  `vehicle_type_id` char(36) NOT NULL,
  `name` varchar(100) NOT NULL,
  `hours` int(11) NOT NULL CHECK (`hours` > 0),
  `kms_included` int(11) NOT NULL CHECK (`kms_included` > 0),
  `package_fare` decimal(10,2) NOT NULL CHECK (`package_fare` > 0),
  `extra_km_rate` decimal(10,2) NOT NULL CHECK (`extra_km_rate` >= 0),
  `extra_min_rate` decimal(10,2) NOT NULL CHECK (`extra_min_rate` >= 0),
  `city` varchar(100) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `vehicle_type_id` (`vehicle_type_id`),
  CONSTRAINT `rental_packages_ibfk_1` FOREIGN KEY (`vehicle_type_id`) REFERENCES `vehicle_types` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `rental_packages` (`id`, `vehicle_type_id`, `name`, `hours`, `kms_included`, `package_fare`, `extra_km_rate`, `extra_min_rate`, `city`, `is_active`, `created_at`) VALUES
('5969c28d-459b-11f1-9547-e09d31f6397e', 'd1000001-0003-4000-a000-000000000003', '2hr / 20km', 2, 20, 500.00, 14.00, 2.00, 'Bangalore', 1, '2026-05-01 20:21:34'),
('5969c64a-459b-11f1-9547-e09d31f6397e', 'd1000001-0003-4000-a000-000000000003', '4hr / 40km', 4, 40, 900.00, 14.00, 2.00, 'Bangalore', 1, '2026-05-01 20:21:34'),
('5969c6f4-459b-11f1-9547-e09d31f6397e', 'd1000001-0003-4000-a000-000000000003', '8hr / 80km', 8, 80, 1600.00, 14.00, 2.00, 'Bangalore', 1, '2026-05-01 20:21:34'),
('5969c766-459b-11f1-9547-e09d31f6397e', 'd1000001-0004-4000-a000-000000000004', '4hr / 40km', 4, 40, 1200.00, 18.00, 3.00, 'Bangalore', 1, '2026-05-01 20:21:34'),
('5969c7c9-459b-11f1-9547-e09d31f6397e', 'd1000001-0004-4000-a000-000000000004', '8hr / 80km', 8, 80, 2200.00, 18.00, 3.00, 'Bangalore', 1, '2026-05-01 20:21:34');

-- --------------------------------------------------------
-- Table: ride_requests
-- FIX: lat/lng changed from FLOAT to DECIMAL(10,7)
-- FIX: estimated_fare changed from FLOAT to DECIMAL(10,2)
-- --------------------------------------------------------
CREATE TABLE `ride_requests` (
  `id` char(36) NOT NULL,
  `rider_id` char(36) NOT NULL,
  `vehicle_type_id` char(36) NOT NULL,
  `pickup_lat` decimal(10,7) NOT NULL,
  `pickup_lng` decimal(10,7) NOT NULL,
  `pickup_address` text NOT NULL,
  `dropoff_lat` decimal(10,7) NOT NULL,
  `dropoff_lng` decimal(10,7) NOT NULL,
  `dropoff_address` text NOT NULL,
  `ride_type` enum('standard','premium','pool','rental','outstation') NOT NULL DEFAULT 'standard',
  `seats_requested` int(11) NOT NULL DEFAULT 1 CHECK (`seats_requested` > 0),
  `estimated_fare` decimal(10,2) NOT NULL CHECK (`estimated_fare` > 0),
  `estimated_distance_km` decimal(8,3) NOT NULL CHECK (`estimated_distance_km` > 0),
  `estimated_duration_min` int(11) NOT NULL CHECK (`estimated_duration_min` > 0),
  `surge_multiplier` decimal(4,2) NOT NULL DEFAULT 1.00,
  `status` enum('pending','searching','matched','cancelled','expired','no_drivers') NOT NULL DEFAULT 'pending',
  `is_scheduled` tinyint(1) NOT NULL DEFAULT 0,
  `scheduled_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NOT NULL DEFAULT (current_timestamp() + interval 5 minute),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `vehicle_type_id` (`vehicle_type_id`),
  KEY `idx_ride_requests_rider` (`rider_id`),
  KEY `idx_ride_requests_status` (`status`,`created_at`),
  CONSTRAINT `ride_requests_ibfk_1` FOREIGN KEY (`rider_id`) REFERENCES `rider_profiles` (`id`),
  CONSTRAINT `ride_requests_ibfk_2` FOREIGN KEY (`vehicle_type_id`) REFERENCES `vehicle_types` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `ride_requests` (`id`, `rider_id`, `vehicle_type_id`, `pickup_lat`, `pickup_lng`, `pickup_address`, `dropoff_lat`, `dropoff_lng`, `dropoff_address`, `ride_type`, `seats_requested`, `estimated_fare`, `estimated_distance_km`, `estimated_duration_min`, `surge_multiplier`, `status`, `is_scheduled`, `scheduled_at`, `expires_at`, `created_at`) VALUES
('r1000001-0001-4000-a000-000000000001', 'b1000001-0001-4000-a000-000000000001', 'd1000001-0003-4000-a000-000000000003', 12.9352000, 77.6245000, '80 Feet Road, Koramangala, Bangalore 560034', 12.9698000, 77.7500000, 'ITPL Main Road, Whitefield, Bangalore 560066', 'standard', 1, 378.00, 18.500, 42, 1.30, 'matched', 0, NULL, '2026-05-01 20:26:34', '2026-05-01 20:21:34'),
('r1000001-0002-4000-a000-000000000002', 'b1000001-0002-4000-a000-000000000002', 'd1000001-0002-4000-a000-000000000002', 12.9784000, 77.6408000, '100 Feet Road, Indiranagar', 12.9756000, 77.6065000, 'MG Road, Bangalore', 'standard', 1, 120.00, 4.200, 18, 1.00, 'matched', 0, NULL, '2026-05-01 20:26:34', '2026-05-01 20:21:34'),
('r1000001-0003-4000-a000-000000000003', 'b1000001-0003-4000-a000-000000000003', 'd1000001-0001-4000-a000-000000000001', 12.9116000, 77.6389000, '27th Main, HSR Layout', 12.8440000, 77.6630000, 'Electronic City Phase 1', 'standard', 1, 145.00, 9.500, 28, 1.00, 'cancelled', 0, NULL, '2026-05-01 20:26:35', '2026-05-01 20:21:35'),
('r1000001-0004-4000-a000-000000000004', 'b1000001-0002-4000-a000-000000000002', 'd1000001-0003-4000-a000-000000000003', 12.9784000, 77.6408000, '100 Feet Road, Indiranagar', 13.1989000, 77.7068000, 'Kempegowda International Airport', 'standard', 1, 850.00, 38.000, 65, 1.00, 'matched', 0, NULL, '2026-05-01 20:26:35', '2026-05-01 20:21:35');

-- --------------------------------------------------------
-- Table: rides
-- FIX: All monetary/fare FLOAT columns changed to DECIMAL(10,2)
-- --------------------------------------------------------
CREATE TABLE `rides` (
  `id` char(36) NOT NULL,
  `request_id` char(36) NOT NULL,
  `driver_id` char(36) NOT NULL,
  `vehicle_id` char(36) NOT NULL,
  `carpool_id` char(36) DEFAULT NULL,
  `ride_number` varchar(30) NOT NULL,
  `status` enum('accepted','driver_arriving','arrived','in_progress','completed','cancelled') NOT NULL DEFAULT 'accepted',
  `estimated_fare` decimal(10,2) NOT NULL,
  `actual_fare` decimal(10,2) DEFAULT NULL,
  `base_fare` decimal(10,2) NOT NULL,
  `distance_km` decimal(8,3) DEFAULT NULL,
  `per_km_charged` decimal(10,2) NOT NULL,
  `per_min_charged` decimal(10,2) NOT NULL,
  `duration_minutes` int(11) DEFAULT NULL,
  `surge_multiplier` decimal(4,2) NOT NULL DEFAULT 1.00,
  `platform_commission_pct` decimal(5,2) NOT NULL DEFAULT 20.00,
  `platform_commission_amt` decimal(10,2) DEFAULT NULL,
  `driver_earning` decimal(10,2) DEFAULT NULL,
  `toll_charges` decimal(10,2) NOT NULL DEFAULT 0.00,
  `waiting_charges` decimal(10,2) NOT NULL DEFAULT 0.00,
  `otp_code` varchar(4) NOT NULL,
  `cancelled_by` enum('rider','driver','system') DEFAULT NULL,
  `cancellation_reason` text DEFAULT NULL,
  `cancellation_fee` decimal(10,2) NOT NULL DEFAULT 0.00,
  `is_split_fare` tinyint(1) NOT NULL DEFAULT 0,
  `accepted_at` timestamp NULL DEFAULT NULL,
  `driver_arrived_at` timestamp NULL DEFAULT NULL,
  `pickup_at` timestamp NULL DEFAULT NULL,
  `dropoff_at` timestamp NULL DEFAULT NULL,
  `cancelled_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `request_id` (`request_id`),
  UNIQUE KEY `ride_number` (`ride_number`),
  KEY `vehicle_id` (`vehicle_id`),
  KEY `idx_rides_driver_status` (`driver_id`,`status`),
  KEY `idx_rides_active` (`status`),
  CONSTRAINT `rides_ibfk_1` FOREIGN KEY (`request_id`) REFERENCES `ride_requests` (`id`),
  CONSTRAINT `rides_ibfk_2` FOREIGN KEY (`driver_id`) REFERENCES `driver_profiles` (`id`),
  CONSTRAINT `rides_ibfk_3` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicles` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `rides` (`id`, `request_id`, `driver_id`, `vehicle_id`, `carpool_id`, `ride_number`, `status`, `estimated_fare`, `actual_fare`, `base_fare`, `distance_km`, `per_km_charged`, `per_min_charged`, `duration_minutes`, `surge_multiplier`, `platform_commission_pct`, `platform_commission_amt`, `driver_earning`, `toll_charges`, `waiting_charges`, `otp_code`, `cancelled_by`, `cancellation_reason`, `cancellation_fee`, `is_split_fare`, `accepted_at`, `driver_arrived_at`, `pickup_at`, `dropoff_at`, `cancelled_at`, `created_at`) VALUES
('s1000001-0001-4000-a000-000000000001', 'r1000001-0001-4000-a000-000000000001', 'c1000001-0010-4000-a000-000000000010', 'e1000001-0010-4000-a000-000000000010', NULL, 'RD-20260501-ABCD', 'completed', 378.00, 390.50, 70.00, 19.200, 16.00, 2.50, 45, 1.30, 20.00, 78.10, 312.40, 0.00, 0.00, '4829', NULL, NULL, 0.00, 0, '2026-05-01 18:21:34', '2026-05-01 18:31:34', '2026-05-01 18:33:34', '2026-05-01 19:18:34', NULL, '2026-05-01 18:21:34'),
('s1000001-0002-4000-a000-000000000002', 'r1000001-0002-4000-a000-000000000002', 'c1000001-0011-4000-a000-000000000011', 'e1000001-0011-4000-a000-000000000011', NULL, 'RD-20260501-EFGH', 'completed', 120.00, 115.00, 50.00, 4.000, 14.00, 2.00, 16, 1.00, 20.00, 23.00, 92.00, 0.00, 0.00, '7713', NULL, NULL, 0.00, 0, '2026-05-01 16:21:34', '2026-05-01 16:29:34', '2026-05-01 16:31:34', '2026-05-01 16:47:34', NULL, '2026-05-01 16:21:34'),
('s1000001-0003-4000-a000-000000000003', 'r1000001-0004-4000-a000-000000000004', 'c1000001-0010-4000-a000-000000000010', 'e1000001-0010-4000-a000-000000000010', NULL, 'RD-20260501-IJKL', 'in_progress', 850.00, NULL, 70.00, NULL, 16.00, 2.50, NULL, 1.00, 20.00, NULL, NULL, 0.00, 0.00, '3156', NULL, NULL, 0.00, 0, '2026-05-01 20:01:35', '2026-05-01 20:09:35', '2026-05-01 20:11:35', NULL, NULL, '2026-05-01 20:01:35');

-- --------------------------------------------------------
-- Table: ride_insurances
-- FIX: Removed ON UPDATE from valid_from; valid_to changed from zero-date to NULL
-- --------------------------------------------------------
CREATE TABLE `ride_insurances` (
  `id` char(36) NOT NULL,
  `ride_id` char(36) NOT NULL,
  `policy_number` varchar(50) NOT NULL,
  `provider` varchar(100) NOT NULL,
  `coverage_amount` decimal(12,2) NOT NULL,
  `status` enum('active','claimed','expired') NOT NULL DEFAULT 'active',
  `valid_from` timestamp NOT NULL DEFAULT current_timestamp(),
  `valid_to` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ride_id` (`ride_id`),
  CONSTRAINT `ride_insurances_ibfk_1` FOREIGN KEY (`ride_id`) REFERENCES `rides` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: ride_location_logs
-- FIX: lat/lng changed from FLOAT to DECIMAL(10,7)
-- --------------------------------------------------------
CREATE TABLE `ride_location_logs` (
  `id` char(36) NOT NULL,
  `ride_id` char(36) NOT NULL,
  `driver_id` char(36) NOT NULL,
  `lat` decimal(10,7) NOT NULL,
  `lng` decimal(10,7) NOT NULL,
  `speed` decimal(6,2) DEFAULT NULL,
  `bearing` decimal(6,2) DEFAULT NULL,
  `recorded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `driver_id` (`driver_id`),
  KEY `idx_location_log_ride` (`ride_id`,`recorded_at`),
  CONSTRAINT `ride_location_logs_ibfk_1` FOREIGN KEY (`ride_id`) REFERENCES `rides` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ride_location_logs_ibfk_2` FOREIGN KEY (`driver_id`) REFERENCES `driver_profiles` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `ride_location_logs` (`id`, `ride_id`, `driver_id`, `lat`, `lng`, `speed`, `bearing`, `recorded_at`) VALUES
('59777aea-459b-11f1-9547-e09d31f6397e', 's1000001-0001-4000-a000-000000000001', 'c1000001-0010-4000-a000-000000000010', 12.9352000, 77.6245000, 0.00, 90.00, '2026-05-01 18:33:34'),
('597780c5-459b-11f1-9547-e09d31f6397e', 's1000001-0001-4000-a000-000000000001', 'c1000001-0010-4000-a000-000000000010', 12.9400000, 77.6350000, 35.50, 85.00, '2026-05-01 18:41:34'),
('5977821a-459b-11f1-9547-e09d31f6397e', 's1000001-0001-4000-a000-000000000001', 'c1000001-0010-4000-a000-000000000010', 12.9500000, 77.6600000, 42.00, 80.00, '2026-05-01 18:51:34'),
('5977834c-459b-11f1-9547-e09d31f6397e', 's1000001-0001-4000-a000-000000000001', 'c1000001-0010-4000-a000-000000000010', 12.9600000, 77.7000000, 48.00, 78.00, '2026-05-01 19:06:34'),
('5977e3f0-459b-11f1-9547-e09d31f6397e', 's1000001-0001-4000-a000-000000000001', 'c1000001-0010-4000-a000-000000000010', 12.9698000, 77.7500000, 0.00, 0.00, '2026-05-01 19:18:34');

-- --------------------------------------------------------
-- Table: ride_riders
-- FIX: lat/lng changed from FLOAT to DECIMAL(10,7); fare_share to DECIMAL(10,2)
-- --------------------------------------------------------
CREATE TABLE `ride_riders` (
  `id` char(36) NOT NULL,
  `ride_id` char(36) NOT NULL,
  `rider_id` char(36) NOT NULL,
  `pickup_lat` decimal(10,7) NOT NULL,
  `pickup_lng` decimal(10,7) NOT NULL,
  `pickup_address` text NOT NULL,
  `dropoff_lat` decimal(10,7) NOT NULL,
  `dropoff_lng` decimal(10,7) NOT NULL,
  `dropoff_address` text NOT NULL,
  `fare_share` decimal(10,2) NOT NULL CHECK (`fare_share` >= 0),
  `status` enum('waiting','picked_up','dropped_off','cancelled') NOT NULL DEFAULT 'waiting',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `rider_id` (`rider_id`),
  KEY `idx_ride_riders_ride` (`ride_id`),
  CONSTRAINT `ride_riders_ibfk_1` FOREIGN KEY (`ride_id`) REFERENCES `rides` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ride_riders_ibfk_2` FOREIGN KEY (`rider_id`) REFERENCES `rider_profiles` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `ride_riders` (`id`, `ride_id`, `rider_id`, `pickup_lat`, `pickup_lng`, `pickup_address`, `dropoff_lat`, `dropoff_lng`, `dropoff_address`, `fare_share`, `status`, `created_at`) VALUES
('5975291a-459b-11f1-9547-e09d31f6397e', 's1000001-0001-4000-a000-000000000001', 'b1000001-0001-4000-a000-000000000001', 12.9352000, 77.6245000, '80 Feet Road, Koramangala', 12.9698000, 77.7500000, 'ITPL Main Road, Whitefield', 390.50, 'dropped_off', '2026-05-01 20:21:34'),
('5983f508-459b-11f1-9547-e09d31f6397e', 's1000001-0002-4000-a000-000000000002', 'b1000001-0002-4000-a000-000000000002', 12.9784000, 77.6408000, '100 Feet Road, Indiranagar', 12.9756000, 77.6065000, 'MG Road, Bangalore', 115.00, 'dropped_off', '2026-05-01 20:21:34'),
('599f19da-459b-11f1-9547-e09d31f6397e', 's1000001-0003-4000-a000-000000000003', 'b1000001-0002-4000-a000-000000000002', 12.9784000, 77.6408000, '100 Feet Road, Indiranagar', 13.1989000, 77.7068000, 'Kempegowda International Airport', 850.00, 'picked_up', '2026-05-01 20:21:35');

-- --------------------------------------------------------
-- Table: ride_routes
-- --------------------------------------------------------
CREATE TABLE `ride_routes` (
  `id` char(36) NOT NULL,
  `ride_id` char(36) NOT NULL,
  `polyline_encoded` text DEFAULT NULL,
  `distance_km` decimal(8,3) NOT NULL,
  `estimated_duration_min` int(11) NOT NULL,
  `is_actual` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ride_id` (`ride_id`),
  CONSTRAINT `ride_routes_ibfk_1` FOREIGN KEY (`ride_id`) REFERENCES `rides` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `ride_routes` (`id`, `ride_id`, `polyline_encoded`, `distance_km`, `estimated_duration_min`, `is_actual`, `created_at`) VALUES
('59763354-459b-11f1-9547-e09d31f6397e', 's1000001-0001-4000-a000-000000000001', 'mfnmAxqjsM_estimated_koramangala_whitefield', 18.500, 42, 0, '2026-05-01 20:21:34'),
('597636c0-459b-11f1-9547-e09d31f6397e', 's1000001-0001-4000-a000-000000000001', 'mfnmAxqjsM_actual_koramangala_whitefield', 19.200, 45, 1, '2026-05-01 20:21:34'),
('5984e32c-459b-11f1-9547-e09d31f6397e', 's1000001-0002-4000-a000-000000000002', 'indiranagar_to_mg_estimated', 4.200, 18, 0, '2026-05-01 20:21:34'),
('5984e4a6-459b-11f1-9547-e09d31f6397e', 's1000001-0002-4000-a000-000000000002', 'indiranagar_to_mg_actual', 4.000, 16, 1, '2026-05-01 20:21:34');

-- --------------------------------------------------------
-- Table: ride_stops
-- FIX: lat/lng changed from FLOAT to DECIMAL(10,7)
-- --------------------------------------------------------
CREATE TABLE `ride_stops` (
  `id` char(36) NOT NULL,
  `ride_id` char(36) NOT NULL,
  `stop_order` int(11) NOT NULL CHECK (`stop_order` > 0),
  `lat` decimal(10,7) NOT NULL,
  `lng` decimal(10,7) NOT NULL,
  `address` text NOT NULL,
  `status` enum('pending','arrived','completed','skipped') NOT NULL DEFAULT 'pending',
  `eta` timestamp NULL DEFAULT NULL,
  `arrived_at` timestamp NULL DEFAULT NULL,
  `departed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ride_stops_ride` (`ride_id`),
  CONSTRAINT `ride_stops_ibfk_1` FOREIGN KEY (`ride_id`) REFERENCES `rides` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `ride_stops` (`id`, `ride_id`, `stop_order`, `lat`, `lng`, `address`, `status`, `eta`, `arrived_at`, `departed_at`) VALUES
('59739db5-459b-11f1-9547-e09d31f6397e', 's1000001-0001-4000-a000-000000000001', 1, 12.9352000, 77.6245000, '80 Feet Road, Koramangala', 'completed', NULL, '2026-05-01 18:31:34', '2026-05-01 18:33:34'),
('5973a1d4-459b-11f1-9547-e09d31f6397e', 's1000001-0001-4000-a000-000000000001', 2, 12.9698000, 77.7500000, 'ITPL Main Road, Whitefield', 'completed', NULL, '2026-05-01 19:18:34', '2026-05-01 19:18:34'),
('5982b426-459b-11f1-9547-e09d31f6397e', 's1000001-0002-4000-a000-000000000002', 1, 12.9784000, 77.6408000, '100 Feet Road, Indiranagar', 'completed', NULL, '2026-05-01 16:29:34', '2026-05-01 16:31:34'),
('5982b671-459b-11f1-9547-e09d31f6397e', 's1000001-0002-4000-a000-000000000002', 2, 12.9756000, 77.6065000, 'MG Road, Bangalore', 'completed', NULL, '2026-05-01 16:47:34', '2026-05-01 16:47:34'),
('599df9b9-459b-11f1-9547-e09d31f6397e', 's1000001-0003-4000-a000-000000000003', 1, 12.9784000, 77.6408000, '100 Feet Road, Indiranagar', 'completed', NULL, NULL, NULL),
('599e0774-459b-11f1-9547-e09d31f6397e', 's1000001-0003-4000-a000-000000000003', 2, 13.1989000, 77.7068000, 'Kempegowda International Airport', 'pending', NULL, NULL, NULL);

-- --------------------------------------------------------
-- Table: payments
-- --------------------------------------------------------
CREATE TABLE `payments` (
  `id` char(36) NOT NULL,
  `user_id` char(36) NOT NULL,
  `ride_id` char(36) DEFAULT NULL,
  `order_id` char(36) DEFAULT NULL,
  `parcel_id` char(36) DEFAULT NULL,
  `payment_number` varchar(30) NOT NULL,
  `amount` decimal(12,2) NOT NULL CHECK (`amount` > 0),
  `discount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `tax` decimal(12,2) NOT NULL DEFAULT 0.00,
  `final_amount` decimal(12,2) NOT NULL CHECK (`final_amount` >= 0),
  `method` enum('card','wallet','cash','upi','net_banking') NOT NULL,
  `payment_method_id` char(36) DEFAULT NULL,
  `status` enum('pending','processing','completed','failed','refunded','partially_refunded') NOT NULL DEFAULT 'pending',
  `gateway_order_id` text DEFAULT NULL,
  `gateway_payment_id` text DEFAULT NULL,
  `gateway_signature` text DEFAULT NULL,
  `paid_at` timestamp NULL DEFAULT NULL,
  `refunded_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `payment_number` (`payment_number`),
  KEY `payment_method_id` (`payment_method_id`),
  KEY `idx_payments_user` (`user_id`),
  KEY `idx_payments_ride` (`ride_id`),
  KEY `idx_payments_status` (`status`,`created_at`),
  CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `payments_ibfk_2` FOREIGN KEY (`ride_id`) REFERENCES `rides` (`id`),
  CONSTRAINT `payments_ibfk_3` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `payments` (`id`, `user_id`, `ride_id`, `order_id`, `parcel_id`, `payment_number`, `amount`, `discount`, `tax`, `final_amount`, `method`, `payment_method_id`, `status`, `gateway_order_id`, `gateway_payment_id`, `gateway_signature`, `paid_at`, `refunded_at`, `created_at`) VALUES
('5986e305-459b-11f1-9547-e09d31f6397e', 'a1b2c3d4-0002-4000-a000-000000000002', 's1000001-0002-4000-a000-000000000002', NULL, NULL, 'PAY-20260501-0002', 115.00, 57.50, 0.00, 57.50, 'card', 'g1000001-0002-4000-a000-000000000002', 'completed', 'order_RzpTest0002', 'pay_RzpTest0002', NULL, '2026-05-01 16:48:34', NULL, '2026-05-01 20:21:34'),
('k1000001-0001-4000-a000-000000000001', 'a1b2c3d4-0001-4000-a000-000000000001', 's1000001-0001-4000-a000-000000000001', NULL, NULL, 'PAY-20260501-0001', 390.50, 0.00, 0.00, 390.50, 'upi', 'g1000001-0001-4000-a000-000000000001', 'completed', 'order_RzpTest0001', 'pay_RzpTest0001', NULL, '2026-05-01 19:19:34', NULL, '2026-05-01 20:21:34');

-- --------------------------------------------------------
-- Table: payment_methods
-- --------------------------------------------------------
CREATE TABLE `payment_methods` (
  `id` char(36) NOT NULL,
  `user_id` char(36) NOT NULL,
  `method_type` enum('card','upi','net_banking') NOT NULL,
  `provider` varchar(50) NOT NULL,
  `token` text NOT NULL,
  `last_four` varchar(4) DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_payment_methods_user` (`user_id`),
  CONSTRAINT `payment_methods_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `payment_methods` (`id`, `user_id`, `method_type`, `provider`, `token`, `last_four`, `is_default`, `is_active`, `created_at`) VALUES
('g1000001-0001-4000-a000-000000000001', 'a1b2c3d4-0001-4000-a000-000000000001', 'upi', 'gpay', 'rzp_tok_test_aarav_gpay_001', NULL, 1, 1, '2026-05-01 20:21:34'),
('g1000001-0002-4000-a000-000000000002', 'a1b2c3d4-0002-4000-a000-000000000002', 'card', 'visa', 'rzp_tok_test_priya_visa_001', '4242', 1, 1, '2026-05-01 20:21:34'),
('g1000001-0002-4000-a000-000000000003', 'a1b2c3d4-0002-4000-a000-000000000002', 'upi', 'phonepe', 'rzp_tok_test_priya_ppe_001', NULL, 0, 1, '2026-05-01 20:21:34');

-- --------------------------------------------------------
-- Table: wallets
-- --------------------------------------------------------
CREATE TABLE `wallets` (
  `id` char(36) NOT NULL,
  `user_id` char(36) NOT NULL,
  `balance` decimal(12,2) NOT NULL DEFAULT 0.00 CHECK (`balance` >= 0),
  `currency` varchar(5) NOT NULL DEFAULT 'INR',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `wallets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wallets` (`id`, `user_id`, `balance`, `currency`, `is_active`, `updated_at`, `created_at`) VALUES
('f1000001-0001-4000-a000-000000000001', 'a1b2c3d4-0001-4000-a000-000000000001', 500.00, 'INR', 1, '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('f1000001-0002-4000-a000-000000000002', 'a1b2c3d4-0002-4000-a000-000000000002', 1200.00, 'INR', 1, '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('f1000001-0003-4000-a000-000000000003', 'a1b2c3d4-0003-4000-a000-000000000003', 0.00, 'INR', 1, '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('f1000001-0010-4000-a000-000000000010', 'a1b2c3d4-0010-4000-a000-000000000010', 3500.00, 'INR', 1, '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('f1000001-0011-4000-a000-000000000011', 'a1b2c3d4-0011-4000-a000-000000000011', 2100.00, 'INR', 1, '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('f1000001-0012-4000-a000-000000000012', 'a1b2c3d4-0012-4000-a000-000000000012', 0.00, 'INR', 1, '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('f1000001-0099-4000-a000-000000000099', 'a1b2c3d4-0099-4000-a000-000000000099', 0.00, 'INR', 1, '2026-05-01 20:21:34', '2026-05-01 20:21:34');

-- --------------------------------------------------------
-- Table: wallet_transactions
-- FIX: Added CHECK (amount > 0) — direction is encoded in type enum
-- --------------------------------------------------------
CREATE TABLE `wallet_transactions` (
  `id` char(36) NOT NULL,
  `wallet_id` char(36) NOT NULL,
  `amount` decimal(12,2) NOT NULL CHECK (`amount` > 0),
  `type` enum('credit','debit') NOT NULL,
  `source` enum('ride_payment','refund','cashback','referral_bonus','top_up','withdrawal','food_payment','parcel_payment') NOT NULL,
  `description` text NOT NULL,
  `reference_id` char(36) DEFAULT NULL,
  `balance_after` decimal(12,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_wallet_txn_wallet` (`wallet_id`,`created_at`),
  CONSTRAINT `wallet_transactions_ibfk_1` FOREIGN KEY (`wallet_id`) REFERENCES `wallets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wallet_transactions` (`id`, `wallet_id`, `amount`, `type`, `source`, `description`, `reference_id`, `balance_after`, `created_at`) VALUES
('59599954-459b-11f1-9547-e09d31f6397e', 'f1000001-0001-4000-a000-000000000001', 1000.00, 'credit', 'top_up', 'Wallet top-up via UPI', NULL, 1000.00, '2026-04-21 20:21:34'),
('5959cc00-459b-11f1-9547-e09d31f6397e', 'f1000001-0001-4000-a000-000000000001', 500.00, 'debit', 'ride_payment', 'Ride payment #RD-20260420-ABCD', NULL, 500.00, '2026-04-26 20:21:34'),
('5959cdc3-459b-11f1-9547-e09d31f6397e', 'f1000001-0002-4000-a000-000000000002', 2000.00, 'credit', 'top_up', 'Wallet top-up via card', NULL, 2000.00, '2026-04-16 20:21:34'),
('5959cec3-459b-11f1-9547-e09d31f6397e', 'f1000001-0002-4000-a000-000000000002', 200.00, 'credit', 'cashback', 'First ride cashback', NULL, 2200.00, '2026-04-17 20:21:34'),
('5959d015-459b-11f1-9547-e09d31f6397e', 'f1000001-0002-4000-a000-000000000002', 1000.00, 'debit', 'ride_payment', 'Ride payment', NULL, 1200.00, '2026-04-24 20:21:34');

-- --------------------------------------------------------
-- Table: promo_codes
-- FIX: valid_from — removed ON UPDATE; now a plain default
-- FIX: valid_to — changed from zero-date to NULL DEFAULT NULL
-- FIX: Added ENGINE=InnoDB
-- FIX: Added deactivated_at / deactivated_by for audit trail
-- --------------------------------------------------------
CREATE TABLE `promo_codes` (
  `id` char(36) NOT NULL,
  `code` varchar(30) NOT NULL,
  `description` text DEFAULT NULL,
  `discount_type` enum('percentage','flat') NOT NULL,
  `discount_value` decimal(12,2) NOT NULL CHECK (`discount_value` > 0),
  `max_discount` decimal(12,2) DEFAULT NULL,
  `min_order_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `max_uses_total` int(11) DEFAULT NULL,
  `max_uses_per_user` int(11) NOT NULL DEFAULT 1,
  `current_uses` int(11) NOT NULL DEFAULT 0,
  `applicable_to` enum('ride','food','parcel','all') NOT NULL DEFAULT 'all',
  `applicable_vehicle_type_id` char(36) DEFAULT NULL,
  `applicable_city` varchar(100) DEFAULT NULL,
  `valid_from` timestamp NOT NULL DEFAULT current_timestamp(),
  `valid_to` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `deactivated_at` timestamp NULL DEFAULT NULL,
  `deactivated_by` char(36) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `applicable_vehicle_type_id` (`applicable_vehicle_type_id`),
  CONSTRAINT `promo_codes_ibfk_1` FOREIGN KEY (`applicable_vehicle_type_id`) REFERENCES `vehicle_types` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `promo_codes` (`id`, `code`, `description`, `discount_type`, `discount_value`, `max_discount`, `min_order_amount`, `max_uses_total`, `max_uses_per_user`, `current_uses`, `applicable_to`, `applicable_vehicle_type_id`, `applicable_city`, `valid_from`, `valid_to`, `is_active`, `deactivated_at`, `deactivated_by`, `created_at`) VALUES
('j1000001-0001-4000-a000-000000000001', 'WELCOME50', 'Welcome 50% off first ride (max ₹100)', 'percentage', 50.00, 100.00, 0.00, NULL, 1, 0, 'ride', NULL, NULL, '2026-04-01 20:21:34', '2026-07-30 20:21:34', 1, NULL, NULL, '2026-05-01 20:21:34'),
('j1000001-0002-4000-a000-000000000002', 'FLAT30', 'Flat ₹30 off any ride', 'flat', 30.00, NULL, 100.00, 1000, 3, 0, 'ride', NULL, NULL, '2026-04-24 20:21:34', '2026-05-31 20:21:34', 1, NULL, NULL, '2026-05-01 20:21:34'),
('j1000001-0003-4000-a000-000000000003', 'TESTALL100', 'Dev testing: ₹100 off everything', 'flat', 100.00, NULL, 0.00, NULL, 999, 0, 'all', NULL, NULL, '2026-04-30 20:21:34', '2027-05-01 20:21:34', 1, NULL, NULL, '2026-05-01 20:21:34');

-- --------------------------------------------------------
-- Table: promo_usages
-- --------------------------------------------------------
CREATE TABLE `promo_usages` (
  `id` char(36) NOT NULL,
  `promo_id` char(36) NOT NULL,
  `user_id` char(36) NOT NULL,
  `ride_id` char(36) DEFAULT NULL,
  `order_id` char(36) DEFAULT NULL,
  `parcel_id` char(36) DEFAULT NULL,
  `discount_applied` decimal(12,2) NOT NULL,
  `used_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ride_id` (`ride_id`),
  KEY `idx_promo_usage_promo` (`promo_id`),
  KEY `idx_promo_usage_user` (`user_id`),
  CONSTRAINT `promo_usages_ibfk_1` FOREIGN KEY (`promo_id`) REFERENCES `promo_codes` (`id`),
  CONSTRAINT `promo_usages_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `promo_usages_ibfk_3` FOREIGN KEY (`ride_id`) REFERENCES `rides` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `promo_usages` (`id`, `promo_id`, `user_id`, `ride_id`, `order_id`, `parcel_id`, `discount_applied`, `used_at`) VALUES
('5985d5bf-459b-11f1-9547-e09d31f6397e', 'j1000001-0001-4000-a000-000000000001', 'a1b2c3d4-0002-4000-a000-000000000002', 's1000001-0002-4000-a000-000000000002', NULL, NULL, 57.50, '2026-05-01 20:21:34');

-- --------------------------------------------------------
-- Table: ratings
-- FIX: Added ENGINE=InnoDB
-- --------------------------------------------------------
CREATE TABLE `ratings` (
  `id` char(36) NOT NULL,
  `ride_id` char(36) DEFAULT NULL,
  `order_id` char(36) DEFAULT NULL,
  `parcel_id` char(36) DEFAULT NULL,
  `from_user_id` char(36) NOT NULL,
  `to_user_id` char(36) NOT NULL,
  `score` int(11) NOT NULL CHECK (`score` >= 1 AND `score` <= 5),
  `review_text` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ride_id` (`ride_id`),
  KEY `from_user_id` (`from_user_id`),
  KEY `idx_ratings_to_user` (`to_user_id`),
  CONSTRAINT `ratings_ibfk_1` FOREIGN KEY (`ride_id`) REFERENCES `rides` (`id`),
  CONSTRAINT `ratings_ibfk_2` FOREIGN KEY (`from_user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `ratings_ibfk_3` FOREIGN KEY (`to_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `ratings` (`id`, `ride_id`, `order_id`, `parcel_id`, `from_user_id`, `to_user_id`, `score`, `review_text`, `created_at`) VALUES
('u1000001-0001-4000-a000-000000000001', 's1000001-0001-4000-a000-000000000001', NULL, NULL, 'a1b2c3d4-0001-4000-a000-000000000001', 'a1b2c3d4-0010-4000-a000-000000000010', 5, 'Excellent ride! Very smooth driving.', '2026-05-01 20:21:34'),
('u1000001-0002-4000-a000-000000000002', 's1000001-0001-4000-a000-000000000001', NULL, NULL, 'a1b2c3d4-0010-4000-a000-000000000010', 'a1b2c3d4-0001-4000-a000-000000000001', 4, NULL, '2026-05-01 20:21:34'),
('u1000001-0003-4000-a000-000000000003', 's1000001-0002-4000-a000-000000000002', NULL, NULL, 'a1b2c3d4-0002-4000-a000-000000000002', 'a1b2c3d4-0011-4000-a000-000000000011', 4, NULL, '2026-05-01 20:21:35');

-- --------------------------------------------------------
-- Table: rating_tags
-- --------------------------------------------------------
CREATE TABLE `rating_tags` (
  `id` char(36) NOT NULL,
  `tag_name` varchar(100) NOT NULL,
  `applicable_to` enum('rider_to_driver','driver_to_rider','customer_to_restaurant') NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tag_name` (`tag_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `rating_tags` (`id`, `tag_name`, `applicable_to`, `is_active`) VALUES
('t1000001-0001-4000-a000-000000000001', 'clean_car', 'rider_to_driver', 1),
('t1000001-0002-4000-a000-000000000002', 'polite', 'rider_to_driver', 1),
('t1000001-0003-4000-a000-000000000003', 'skilled_driver', 'rider_to_driver', 1),
('t1000001-0004-4000-a000-000000000004', 'fast_pickup', 'rider_to_driver', 1),
('t1000001-0005-4000-a000-000000000005', 'rash_driving', 'rider_to_driver', 1),
('t1000001-0006-4000-a000-000000000006', 'bad_route', 'rider_to_driver', 1),
('t1000001-0007-4000-a000-000000000007', 'polite_rider', 'driver_to_rider', 1),
('t1000001-0008-4000-a000-000000000008', 'messy_rider', 'driver_to_rider', 1),
('t1000001-0009-4000-a000-000000000009', 'late_pickup', 'driver_to_rider', 1);

-- --------------------------------------------------------
-- Table: rating_tag_maps
-- --------------------------------------------------------
CREATE TABLE `rating_tag_maps` (
  `id` char(36) NOT NULL,
  `rating_id` char(36) NOT NULL,
  `tag_id` char(36) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_rating_tag` (`rating_id`,`tag_id`),
  KEY `tag_id` (`tag_id`),
  KEY `idx_rating_tag_map_rating` (`rating_id`),
  CONSTRAINT `rating_tag_maps_ibfk_1` FOREIGN KEY (`rating_id`) REFERENCES `ratings` (`id`) ON DELETE CASCADE,
  CONSTRAINT `rating_tag_maps_ibfk_2` FOREIGN KEY (`tag_id`) REFERENCES `rating_tags` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `rating_tag_maps` (`id`, `rating_id`, `tag_id`) VALUES
('598c38cd-459b-11f1-9547-e09d31f6397e', 'u1000001-0001-4000-a000-000000000001', 't1000001-0001-4000-a000-000000000001'),
('598c3d61-459b-11f1-9547-e09d31f6397e', 'u1000001-0001-4000-a000-000000000001', 't1000001-0002-4000-a000-000000000002'),
('598f1205-459b-11f1-9547-e09d31f6397e', 'u1000001-0002-4000-a000-000000000002', 't1000001-0007-4000-a000-000000000007');

-- --------------------------------------------------------
-- Table: emergency_contacts
-- --------------------------------------------------------
CREATE TABLE `emergency_contacts` (
  `id` char(36) NOT NULL,
  `user_id` char(36) NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `relationship` varchar(50) DEFAULT NULL,
  `is_primary` tinyint(1) NOT NULL DEFAULT 0,
  `notify_on_ride` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_emergency_user` (`user_id`),
  CONSTRAINT `emergency_contacts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `emergency_contacts` (`id`, `user_id`, `name`, `phone`, `relationship`, `is_primary`, `notify_on_ride`, `created_at`) VALUES
('595f2913-459b-11f1-9547-e09d31f6397e', 'a1b2c3d4-0001-4000-a000-000000000001', 'Sunita Sharma', '+919876543250', 'Mother', 1, 1, '2026-05-01 20:21:34'),
('595f4fd4-459b-11f1-9547-e09d31f6397e', 'a1b2c3d4-0001-4000-a000-000000000001', 'Rohit Sharma', '+919876543251', 'Brother', 0, 0, '2026-05-01 20:21:34'),
('595f50da-459b-11f1-9547-e09d31f6397e', 'a1b2c3d4-0002-4000-a000-000000000002', 'Amit Patel', '+919876543260', 'Father', 1, 1, '2026-05-01 20:21:34'),
('595f5152-459b-11f1-9547-e09d31f6397e', 'a1b2c3d4-0003-4000-a000-000000000003', 'Neha Verma', '+919876543270', 'Wife', 1, 1, '2026-05-01 20:21:34');

-- --------------------------------------------------------
-- Table: favorite_locations
-- FIX: lat/lng changed from FLOAT to DECIMAL(10,7)
-- --------------------------------------------------------
CREATE TABLE `favorite_locations` (
  `id` char(36) NOT NULL,
  `user_id` char(36) NOT NULL,
  `label` varchar(50) NOT NULL,
  `lat` decimal(10,7) NOT NULL,
  `lng` decimal(10,7) NOT NULL,
  `address` text NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_fav_loc_user` (`user_id`),
  CONSTRAINT `favorite_locations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `favorite_locations` (`id`, `user_id`, `label`, `lat`, `lng`, `address`, `sort_order`, `created_at`) VALUES
('595d8823-459b-11f1-9547-e09d31f6397e', 'a1b2c3d4-0001-4000-a000-000000000001', 'home', 12.9352000, 77.6245000, '80 Feet Road, Koramangala, Bangalore 560034', 0, '2026-05-01 20:21:34'),
('595db01c-459b-11f1-9547-e09d31f6397e', 'a1b2c3d4-0001-4000-a000-000000000001', 'work', 12.9698000, 77.7500000, 'ITPL Main Road, Whitefield, Bangalore 560066', 0, '2026-05-01 20:21:34'),
('595db173-459b-11f1-9547-e09d31f6397e', 'a1b2c3d4-0001-4000-a000-000000000001', 'gym', 12.9299000, 77.5838000, 'Cult Fitness, 4th Block, Jayanagar', 0, '2026-05-01 20:21:34'),
('595db231-459b-11f1-9547-e09d31f6397e', 'a1b2c3d4-0002-4000-a000-000000000002', 'home', 12.9784000, 77.6408000, '100 Feet Road, Indiranagar, Bangalore 560038', 0, '2026-05-01 20:21:34'),
('595db2d8-459b-11f1-9547-e09d31f6397e', 'a1b2c3d4-0002-4000-a000-000000000002', 'work', 12.9756000, 77.6065000, 'WeWork MG Road, Bangalore 560001', 0, '2026-05-01 20:21:34');

-- --------------------------------------------------------
-- Table: live_location_shares
-- FIX: expires_at changed from zero-date default to NULL DEFAULT NULL
-- --------------------------------------------------------
CREATE TABLE `live_location_shares` (
  `id` char(36) NOT NULL,
  `ride_id` char(36) NOT NULL,
  `rider_id` char(36) NOT NULL,
  `emergency_contact_id` char(36) NOT NULL,
  `share_token` text NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `shared_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ride_id` (`ride_id`),
  KEY `rider_id` (`rider_id`),
  KEY `emergency_contact_id` (`emergency_contact_id`),
  CONSTRAINT `live_location_shares_ibfk_1` FOREIGN KEY (`ride_id`) REFERENCES `rides` (`id`) ON DELETE CASCADE,
  CONSTRAINT `live_location_shares_ibfk_2` FOREIGN KEY (`rider_id`) REFERENCES `users` (`id`),
  CONSTRAINT `live_location_shares_ibfk_3` FOREIGN KEY (`emergency_contact_id`) REFERENCES `emergency_contacts` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `live_location_shares` (`id`, `ride_id`, `rider_id`, `emergency_contact_id`, `share_token`, `is_active`, `shared_at`, `expires_at`) VALUES
('59a0a2e4-459b-11f1-9547-e09d31f6397e', 's1000001-0003-4000-a000-000000000003', 'a1b2c3d4-0002-4000-a000-000000000002', '595f50da-459b-11f1-9547-e09d31f6397e', 'trk_priya_airport_20260501', 1, '2026-05-01 20:21:35', '2026-05-01 22:21:35');

-- --------------------------------------------------------
-- Table: sos_alerts
-- FIX: lat/lng changed from FLOAT to DECIMAL(10,7)
-- --------------------------------------------------------
CREATE TABLE `sos_alerts` (
  `id` char(36) NOT NULL,
  `user_id` char(36) NOT NULL,
  `ride_id` char(36) DEFAULT NULL,
  `lat` decimal(10,7) NOT NULL,
  `lng` decimal(10,7) NOT NULL,
  `status` enum('triggered','acknowledged','responded','resolved','false_alarm') NOT NULL DEFAULT 'triggered',
  `notes` text DEFAULT NULL,
  `resolved_by` char(36) DEFAULT NULL,
  `triggered_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `resolved_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `ride_id` (`ride_id`),
  KEY `resolved_by` (`resolved_by`),
  CONSTRAINT `sos_alerts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `sos_alerts_ibfk_2` FOREIGN KEY (`ride_id`) REFERENCES `rides` (`id`),
  CONSTRAINT `sos_alerts_ibfk_3` FOREIGN KEY (`resolved_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: split_fare_invites
-- FIX: share_amount changed from FLOAT to DECIMAL(10,2)
-- --------------------------------------------------------
CREATE TABLE `split_fare_invites` (
  `id` char(36) NOT NULL,
  `ride_id` char(36) NOT NULL,
  `inviter_id` char(36) NOT NULL,
  `invitee_id` char(36) DEFAULT NULL,
  `invitee_phone` varchar(20) NOT NULL,
  `share_amount` decimal(10,2) NOT NULL CHECK (`share_amount` > 0),
  `status` enum('pending','accepted','declined','expired') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `responded_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ride_id` (`ride_id`),
  KEY `inviter_id` (`inviter_id`),
  KEY `invitee_id` (`invitee_id`),
  CONSTRAINT `split_fare_invites_ibfk_1` FOREIGN KEY (`ride_id`) REFERENCES `rides` (`id`) ON DELETE CASCADE,
  CONSTRAINT `split_fare_invites_ibfk_2` FOREIGN KEY (`inviter_id`) REFERENCES `users` (`id`),
  CONSTRAINT `split_fare_invites_ibfk_3` FOREIGN KEY (`invitee_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: surge_zones
-- FIX: lat/lng removed (no location columns here); added index on city + time range
-- --------------------------------------------------------
CREATE TABLE `surge_zones` (
  `id` char(36) NOT NULL,
  `city` varchar(100) NOT NULL,
  `zone_name` varchar(100) NOT NULL,
  `geo_boundary` text DEFAULT NULL,
  `surge_multiplier` decimal(4,2) NOT NULL CHECK (`surge_multiplier` >= 1.0),
  `active_from` timestamp NOT NULL DEFAULT current_timestamp(),
  `active_to` timestamp NOT NULL DEFAULT (current_timestamp() + interval 2 hour),
  `reason` varchar(50) NOT NULL DEFAULT 'high_demand',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_surge_active` (`city`,`active_from`,`active_to`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `surge_zones` (`id`, `city`, `zone_name`, `geo_boundary`, `surge_multiplier`, `active_from`, `active_to`, `reason`, `created_at`) VALUES
('i1000001-0001-4000-a000-000000000001', 'Bangalore', 'Koramangala', NULL, 1.30, '2026-05-01 20:21:34', '2026-05-01 22:21:34', 'high_demand', '2026-05-01 20:21:34'),
('i1000001-0002-4000-a000-000000000002', 'Bangalore', 'MG Road / CBD', NULL, 1.50, '2026-05-02 13:21:34', '2026-05-02 17:21:34', 'event', '2026-05-01 20:21:34');

-- --------------------------------------------------------
-- Table: support_categories
-- --------------------------------------------------------
CREATE TABLE `support_categories` (
  `id` char(36) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `parent_category_id` char(36) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `parent_category_id` (`parent_category_id`),
  CONSTRAINT `support_categories_ibfk_1` FOREIGN KEY (`parent_category_id`) REFERENCES `support_categories` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `support_categories` (`id`, `name`, `description`, `parent_category_id`, `sort_order`, `is_active`) VALUES
('v1000001-0001-4000-a000-000000000001', 'fare_dispute', 'Issues with ride fare, toll charges, surge pricing', NULL, 1, 1),
('v1000001-0002-4000-a000-000000000002', 'safety', 'Safety concerns, SOS follow-up', NULL, 2, 1),
('v1000001-0003-4000-a000-000000000003', 'lost_item', 'Items left in vehicle', NULL, 3, 1),
('v1000001-0004-4000-a000-000000000004', 'driver_behavior', 'Rude behavior, rash driving', NULL, 4, 1),
('v1000001-0005-4000-a000-000000000005', 'payment_issue', 'Failed payment, refund request', NULL, 5, 1),
('v1000001-0006-4000-a000-000000000006', 'app_issue', 'App crashes, bugs, feature requests', NULL, 6, 1);

-- --------------------------------------------------------
-- Table: support_tickets
-- --------------------------------------------------------
CREATE TABLE `support_tickets` (
  `id` char(36) NOT NULL,
  `user_id` char(36) NOT NULL,
  `category_id` char(36) NOT NULL,
  `ride_id` char(36) DEFAULT NULL,
  `order_id` char(36) DEFAULT NULL,
  `parcel_id` char(36) DEFAULT NULL,
  `ticket_number` varchar(30) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `priority` enum('low','medium','high','urgent') NOT NULL DEFAULT 'medium',
  `status` enum('open','in_progress','awaiting_user','resolved','closed','reopened') NOT NULL DEFAULT 'open',
  `assigned_to` char(36) DEFAULT NULL,
  `resolved_at` timestamp NULL DEFAULT NULL,
  `closed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ticket_number` (`ticket_number`),
  KEY `category_id` (`category_id`),
  KEY `ride_id` (`ride_id`),
  KEY `assigned_to` (`assigned_to`),
  KEY `idx_tickets_user` (`user_id`),
  KEY `idx_tickets_status` (`status`,`priority`),
  CONSTRAINT `support_tickets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `support_tickets_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `support_categories` (`id`),
  CONSTRAINT `support_tickets_ibfk_3` FOREIGN KEY (`ride_id`) REFERENCES `rides` (`id`),
  CONSTRAINT `support_tickets_ibfk_4` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `support_tickets` (`id`, `user_id`, `category_id`, `ride_id`, `order_id`, `parcel_id`, `ticket_number`, `subject`, `description`, `priority`, `status`, `assigned_to`, `resolved_at`, `closed_at`, `created_at`, `updated_at`) VALUES
('w1000001-0001-4000-a000-000000000001', 'a1b2c3d4-0001-4000-a000-000000000001', 'v1000001-0001-4000-a000-000000000001', 's1000001-0001-4000-a000-000000000001', NULL, NULL, 'TKT-20260501-0001', 'Toll charges not reflected correctly', 'I was charged ₹390.50 but the toll of ₹35 on Outer Ring Road was not added. Please check.', 'medium', 'open', NULL, NULL, NULL, '2026-05-01 20:21:35', '2026-05-01 20:21:35');

-- --------------------------------------------------------
-- Table: support_messages
-- --------------------------------------------------------
CREATE TABLE `support_messages` (
  `id` char(36) NOT NULL,
  `ticket_id` char(36) NOT NULL,
  `sender_id` char(36) NOT NULL,
  `content` text NOT NULL,
  `attachment_url` text DEFAULT NULL,
  `is_internal_note` tinyint(1) NOT NULL DEFAULT 0,
  `sent_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `sender_id` (`sender_id`),
  KEY `idx_support_msgs_ticket` (`ticket_id`),
  CONSTRAINT `support_messages_ibfk_1` FOREIGN KEY (`ticket_id`) REFERENCES `support_tickets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `support_messages_ibfk_2` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `support_messages` (`id`, `ticket_id`, `sender_id`, `content`, `attachment_url`, `is_internal_note`, `sent_at`) VALUES
('59975ccd-459b-11f1-9547-e09d31f6397e', 'w1000001-0001-4000-a000-000000000001', 'a1b2c3d4-0001-4000-a000-000000000001', 'Hi, I noticed the toll at ORR junction was not included in my fare. Can you please check?', NULL, 0, '2026-05-01 20:21:35'),
('59975f25-459b-11f1-9547-e09d31f6397e', 'w1000001-0001-4000-a000-000000000001', 'a1b2c3d4-0099-4000-a000-000000000099', 'Hi Aarav, we are looking into this. Toll charges will be adjusted within 24 hours. Thank you for your patience.', NULL, 0, '2026-05-01 20:21:35');

-- --------------------------------------------------------
-- Table: system_configs
-- FIX: Added created_at column for audit trail
-- --------------------------------------------------------
CREATE TABLE `system_configs` (
  `id` char(36) NOT NULL,
  `config_key` varchar(100) NOT NULL,
  `config_value` text NOT NULL,
  `description` text DEFAULT NULL,
  `group_name` varchar(50) NOT NULL DEFAULT 'general',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `config_key` (`config_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `system_configs` (`id`, `config_key`, `config_value`, `description`, `group_name`, `created_at`, `updated_at`) VALUES
('5960e6f5-459b-11f1-9547-e09d31f6397e', 'ride_timeout_seconds', '300', 'Time before unmatched ride request expires', 'ride', '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('59610f2c-459b-11f1-9547-e09d31f6397e', 'max_surge_multiplier', '3.0', 'Maximum allowed surge multiplier', 'ride', '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('59611076-459b-11f1-9547-e09d31f6397e', 'platform_commission_pct', '20', 'Default platform commission percentage', 'payment', '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('596110e7-459b-11f1-9547-e09d31f6397e', 'min_wallet_topup', '100', 'Minimum wallet top-up amount in INR', 'payment', '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('5961115f-459b-11f1-9547-e09d31f6397e', 'max_wallet_balance', '50000', 'Maximum wallet balance in INR', 'payment', '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('596111cb-459b-11f1-9547-e09d31f6397e', 'driver_matching_radius_km', '5', 'Search radius for nearby drivers (km)', 'ride', '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('59611223-459b-11f1-9547-e09d31f6397e', 'driver_ping_timeout_sec', '15', 'Seconds to wait for driver to accept', 'ride', '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('5961127a-459b-11f1-9547-e09d31f6397e', 'max_ride_stops', '3', 'Maximum intermediate stops per ride', 'ride', '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('596112dc-459b-11f1-9547-e09d31f6397e', 'cancellation_fee_rider', '50', 'Default rider cancellation fee in INR', 'ride', '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('596113dc-459b-11f1-9547-e09d31f6397e', 'cancellation_fee_driver', '100', 'Default driver cancellation fee in INR', 'ride', '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('59611476-459b-11f1-9547-e09d31f6397e', 'sos_auto_alert_contacts', 'true', 'Auto-notify emergency contacts on SOS', 'safety', '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('596114df-459b-11f1-9547-e09d31f6397e', 'referral_bonus_referrer', '100', 'Referral bonus for referrer in INR', 'general', '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('5961153f-459b-11f1-9547-e09d31f6397e', 'referral_bonus_referee', '50', 'Referral bonus for new user in INR', 'general', '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('596115a0-459b-11f1-9547-e09d31f6397e', 'otp_expiry_seconds', '300', 'OTP expiry time', 'general', '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('59611605-459b-11f1-9547-e09d31f6397e', 'max_otp_attempts', '5', 'Max OTP verification attempts', 'general', '2026-05-01 20:21:34', '2026-05-01 20:21:34'),
('59611670-459b-11f1-9547-e09d31f6397e', 'support_auto_assign', 'false', 'Auto-assign tickets to available agents', 'general', '2026-05-01 20:21:34', '2026-05-01 20:21:34');

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
